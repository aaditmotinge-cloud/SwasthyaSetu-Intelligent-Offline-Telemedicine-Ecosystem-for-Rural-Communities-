import React, { createContext, useContext, useState, useEffect } from 'react';
import type {
  Patient,
  Consultation,
  SyncQueueItem,
  CHWProfile,
  ToastMessage,
  User,
  UserRole,
  Doctor,
  HospitalFacility,
  DigitalPrescription,
  Appointment,
  MedicineReminder,
  SurveillanceCluster,
  AppLanguage,
  Vitals,
} from '../types';
import {
  INITIAL_PATIENTS,
  INITIAL_CONSULTATIONS,
  INITIAL_SYNC_QUEUE,
  INITIAL_CHW_PROFILE,
  INITIAL_USERS,
  INITIAL_DOCTORS,
  INITIAL_HOSPITALS,
  INITIAL_PRESCRIPTIONS,
  INITIAL_APPOINTMENTS,
  INITIAL_REMINDERS,
  INITIAL_SURVEILLANCE,
} from '../mock/initialData';
import { t } from '../utils/i18n';

export type NavTab =
  | 'dashboard'
  | 'patients'
  | 'consultations'
  | 'symptom-assessment'
  | 'sync-status'
  | 'hospitals'
  | 'appointments'
  | 'pharmacy'
  | 'surveillance'
  | 'settings';

interface AppContextType {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  isOnline: boolean;
  setIsOnline: React.Dispatch<React.SetStateAction<boolean>>;
  language: AppLanguage;
  setLanguage: (lang: AppLanguage) => void;
  translate: (key: string) => string;

  // Multi-role Auth
  currentUser: User;
  setCurrentUser: (user: User) => void;
  switchUserRole: (role: UserRole) => void;
  isAuthenticated: boolean;
  login: (role: UserRole) => void;
  logout: () => void;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;

  // Data Collections
  patients: Patient[];
  consultations: Consultation[];
  syncQueue: SyncQueueItem[];
  doctors: Doctor[];
  hospitals: HospitalFacility[];
  prescriptions: DigitalPrescription[];
  appointments: Appointment[];
  reminders: MedicineReminder[];
  surveillanceClusters: SurveillanceCluster[];
  chwProfile: CHWProfile;
  toasts: ToastMessage[];

  // Selection & Modal States
  selectedPatient: Patient | null;
  setSelectedPatient: (patient: Patient | null) => void;
  isPatientModalOpen: boolean;
  setIsPatientModalOpen: (open: boolean) => void;
  isConsultationModalOpen: boolean;
  setIsConsultationModalOpen: (open: boolean) => void;
  defaultConsultationPatientId: string | undefined;
  setDefaultConsultationPatientId: (id: string | undefined) => void;
  isPrescriptionModalOpen: boolean;
  setIsPrescriptionModalOpen: (open: boolean) => void;
  isEmergencyVoiceModalOpen: boolean;
  setIsEmergencyVoiceModalOpen: (open: boolean) => void;
  openEmergencyVoice: () => void;

  // Actions
  addPatient: (newPatient: Omit<Patient, 'id' | 'syncStatus' | 'registeredAt'>) => Patient;
  addConsultation: (newConsultation: Omit<Consultation, 'id' | 'date' | 'syncStatus' | 'chwName'>) => Consultation;
  logPatientVitals: (patientId: string, vitals: Vitals) => void;
  addPrescription: (prescriptionData: Omit<DigitalPrescription, 'id' | 'date'>) => DigitalPrescription;
  bookAppointment: (appointmentData: Omit<Appointment, 'id' | 'status'>) => Appointment;
  toggleReminderTaken: (reminderId: string) => void;
  addSurveillanceCluster: (cluster: Omit<SurveillanceCluster, 'id'>) => void;
  performSync: () => void;
  addToast: (type: ToastMessage['type'], message: string) => void;
  removeToast: (id: string) => void;
  clearOfflineStorage: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const LOCAL_STORAGE_PATIENTS_KEY = 'swasthya_patients_v2';
const LOCAL_STORAGE_CONSULTATIONS_KEY = 'swasthya_consultations_v2';
const LOCAL_STORAGE_SYNC_KEY = 'swasthya_sync_queue_v2';
const LOCAL_STORAGE_PRESCRIPTIONS_KEY = 'swasthya_prescriptions_v2';
const LOCAL_STORAGE_APPOINTMENTS_KEY = 'swasthya_appointments_v2';
const LOCAL_STORAGE_USER_KEY = 'swasthya_current_user_v2';
const LOCAL_STORAGE_LANG_KEY = 'swasthya_language_v2';
const LOCAL_STORAGE_AUTH_KEY = 'swasthya_auth_v2';
const LOCAL_STORAGE_SURVEILLANCE_KEY = 'swasthya_surveillance_v2';

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [isOnline, setIsOnline] = useState<boolean>(true);

  // Language state
  const [language, setLanguageState] = useState<AppLanguage>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_LANG_KEY);
      return saved ? (saved as AppLanguage) : 'en';
    } catch (e) {
      return 'en';
    }
  });

  const setLanguage = (lang: AppLanguage) => {
    setLanguageState(lang);
    try {
      localStorage.setItem(LOCAL_STORAGE_LANG_KEY, lang);
    } catch (e) {}
  };

  const translate = (key: string) => t(key, language);

  // Multi-Role Auth state (Default: ASHA worker Sunita Devi)
  const [currentUser, setCurrentUser] = useState<User>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_USER_KEY);
      return saved ? JSON.parse(saved) : INITIAL_USERS[0];
    } catch (e) {
      return INITIAL_USERS[0];
    }
  });

  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_AUTH_KEY);
      return saved !== null ? JSON.parse(saved) : true;
    } catch (e) {
      return true;
    }
  });

  const login = (role: UserRole) => {
    switchUserRole(role);
    setIsAuthenticated(true);
    try {
      localStorage.setItem(LOCAL_STORAGE_AUTH_KEY, JSON.stringify(true));
    } catch (e) {}
    addToast(
      'success',
      `Logged in as ${
        role === 'asha'
          ? 'ASHA Worker (Sunita Devi)'
          : role === 'doctor'
          ? 'Medical Officer (Dr. Anand Verma)'
          : 'Patient (Rajesh Kumar)'
      }`
    );
  };

  const logout = () => {
    setIsAuthenticated(false);
    try {
      localStorage.setItem(LOCAL_STORAGE_AUTH_KEY, JSON.stringify(false));
    } catch (e) {}
    addToast('info', 'Logged out of SwasthyaSetu.');
  };

  const switchUserRole = (role: UserRole) => {
    const targetUser = INITIAL_USERS.find((u) => u.role === role) || {
      id: `USR-${Date.now()}`,
      name: role === 'doctor' ? 'Dr. Anand Verma' : role === 'patient' ? 'Rajesh Kumar' : 'Sunita Devi',
      role,
      phone: '+91 98765 00000',
      verified: true,
      facilityOrVillage: role === 'doctor' ? 'District Hospital' : 'Rampur Village',
    };
    setCurrentUser(targetUser);
    try {
      localStorage.setItem(LOCAL_STORAGE_USER_KEY, JSON.stringify(targetUser));
    } catch (e) {}
    addToast('info', `Switched role to: ${role === 'asha' ? 'ASHA Worker' : role === 'doctor' ? 'Doctor / Clinical Officer' : 'Patient'}`);
  };

  // Selection & Modal States
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [isPatientModalOpen, setIsPatientModalOpen] = useState(false);
  const [isConsultationModalOpen, setIsConsultationModalOpen] = useState(false);
  const [isPrescriptionModalOpen, setIsPrescriptionModalOpen] = useState(false);
  const [isEmergencyVoiceModalOpen, setIsEmergencyVoiceModalOpen] = useState(false);
  const [defaultConsultationPatientId, setDefaultConsultationPatientId] = useState<string | undefined>(undefined);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const openEmergencyVoice = () => {
    setIsEmergencyVoiceModalOpen(true);
  };

  // Collections state
  const [patients, setPatients] = useState<Patient[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_PATIENTS_KEY);
      return saved ? JSON.parse(saved) : INITIAL_PATIENTS;
    } catch (e) {
      return INITIAL_PATIENTS;
    }
  });

  const [consultations, setConsultations] = useState<Consultation[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_CONSULTATIONS_KEY);
      return saved ? JSON.parse(saved) : INITIAL_CONSULTATIONS;
    } catch (e) {
      return INITIAL_CONSULTATIONS;
    }
  });

  const [syncQueue, setSyncQueue] = useState<SyncQueueItem[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_SYNC_KEY);
      return saved ? JSON.parse(saved) : INITIAL_SYNC_QUEUE;
    } catch (e) {
      return INITIAL_SYNC_QUEUE;
    }
  });

  const [prescriptions, setPrescriptions] = useState<DigitalPrescription[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_PRESCRIPTIONS_KEY);
      return saved ? JSON.parse(saved) : INITIAL_PRESCRIPTIONS;
    } catch (e) {
      return INITIAL_PRESCRIPTIONS;
    }
  });

  const [appointments, setAppointments] = useState<Appointment[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_APPOINTMENTS_KEY);
      return saved ? JSON.parse(saved) : INITIAL_APPOINTMENTS;
    } catch (e) {
      return INITIAL_APPOINTMENTS;
    }
  });

  const [doctors] = useState<Doctor[]>(INITIAL_DOCTORS);
  const [hospitals] = useState<HospitalFacility[]>(INITIAL_HOSPITALS);
  const [reminders, setReminders] = useState<MedicineReminder[]>(INITIAL_REMINDERS);
  const [surveillanceClusters, setSurveillanceClusters] = useState<SurveillanceCluster[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_SURVEILLANCE_KEY);
      return saved ? JSON.parse(saved) : INITIAL_SURVEILLANCE;
    } catch (e) {
      return INITIAL_SURVEILLANCE;
    }
  });
  const [chwProfile] = useState<CHWProfile>(INITIAL_CHW_PROFILE);

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_SURVEILLANCE_KEY, JSON.stringify(surveillanceClusters));
    } catch (e) {}
  }, [surveillanceClusters]);
  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_PATIENTS_KEY, JSON.stringify(patients));
    } catch (e) {}
  }, [patients]);

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_CONSULTATIONS_KEY, JSON.stringify(consultations));
    } catch (e) {}
  }, [consultations]);

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_SYNC_KEY, JSON.stringify(syncQueue));
    } catch (e) {}
  }, [syncQueue]);

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_PRESCRIPTIONS_KEY, JSON.stringify(prescriptions));
    } catch (e) {}
  }, [prescriptions]);

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_APPOINTMENTS_KEY, JSON.stringify(appointments));
    } catch (e) {}
  }, [appointments]);

  // Toast System
  const addToast = (type: ToastMessage['type'], message: string) => {
    const id = Date.now().toString();
    setToasts((prev) => [...prev, { id, type, message }]);
    setTimeout(() => removeToast(id), 4000);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Add Patient
  const addPatient = (newPatientData: Omit<Patient, 'id' | 'syncStatus' | 'registeredAt'>): Patient => {
    const id = `PAT-${Math.floor(1000 + Math.random() * 9000)}`;
    const today = new Date().toISOString().split('T')[0];
    const abhaId = newPatientData.abhaId.trim() || `91-${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(1000 + Math.random() * 9000)}`;

    const newPatient: Patient = {
      ...newPatientData,
      id,
      abhaId,
      registeredAt: today,
      lastVisit: today,
      syncStatus: isOnline ? 'synced' : 'pending',
      bpHistory: [],
      bloodSugarHistory: [],
    };

    setPatients((prev) => [newPatient, ...prev]);

    const syncItem: SyncQueueItem = {
      id: `SYNC-${Date.now()}`,
      type: 'patient',
      action: 'REGISTER',
      title: `New Patient: ${newPatient.name}`,
      details: `${newPatient.village} | ABHA: ${newPatient.abhaId}`,
      timestamp: new Date().toLocaleString(),
      status: isOnline ? 'synced' : 'pending',
    };

    if (!isOnline) {
      setSyncQueue((prev) => [syncItem, ...prev]);
      addToast('warning', `Patient ${newPatient.name} saved offline.`);
    } else {
      addToast('success', `Patient ${newPatient.name} registered.`);
    }

    return newPatient;
  };

  // Add Consultation
  const addConsultation = (newConsultationData: Omit<Consultation, 'id' | 'date' | 'syncStatus' | 'chwName'>): Consultation => {
    const id = `CON-${Math.floor(8000 + Math.random() * 1000)}`;
    const nowStr = new Date().toLocaleString([], { dateStyle: 'short', timeStyle: 'short' });

    const newConsultation: Consultation = {
      ...newConsultationData,
      id,
      chwName: currentUser.name,
      date: nowStr,
      syncStatus: isOnline ? 'synced' : 'pending',
    };

    setConsultations((prev) => [newConsultation, ...prev]);

    setPatients((prev) =>
      prev.map((p) =>
        p.id === newConsultationData.patientId
          ? {
              ...p,
              lastVisit: new Date().toISOString().split('T')[0],
              triageLevel:
                newConsultationData.triageRisk === 'critical'
                  ? 'critical'
                  : newConsultationData.triageRisk === 'high' || newConsultationData.triageRisk === 'moderate'
                  ? 'moderate'
                  : 'normal',
            }
          : p
      )
    );

    const syncItem: SyncQueueItem = {
      id: `SYNC-${Date.now()}`,
      type: 'consultation',
      action: 'RECORD_CONSULTATION',
      title: `Consultation: ${newConsultation.patientName}`,
      details: `Vitals & Chief Complaint (${newConsultation.id})`,
      timestamp: nowStr,
      status: isOnline ? 'synced' : 'pending',
    };

    if (!isOnline) {
      setSyncQueue((prev) => [syncItem, ...prev]);
      addToast('warning', `Consultation for ${newConsultation.patientName} queued offline.`);
    } else {
      addToast('success', `Consultation recorded for ${newConsultation.patientName}.`);
    }

    return newConsultation;
  };

  // Log Vitals (BP & Sugar)
  const logPatientVitals = (patientId: string, vitals: Vitals) => {
    const today = new Date().toISOString().split('T')[0];

    setPatients((prev) =>
      prev.map((p) => {
        if (p.id !== patientId) return p;

        const updatedBpHistory = p.bpHistory ? [...p.bpHistory] : [];
        if (vitals.bpSystolic && vitals.bpDiastolic) {
          updatedBpHistory.push({ date: today, sys: vitals.bpSystolic, dia: vitals.bpDiastolic });
        }

        const updatedSugarHistory = p.bloodSugarHistory ? [...p.bloodSugarHistory] : [];
        if (vitals.bloodSugar) {
          updatedSugarHistory.push({
            date: today,
            value: vitals.bloodSugar,
            type: vitals.sugarType || 'random',
          });
        }

        return {
          ...p,
          bpHistory: updatedBpHistory,
          bloodSugarHistory: updatedSugarHistory,
        };
      })
    );

    addToast('success', 'Vitals logged & updated in patient history.');
  };

  // Add Prescription
  const addPrescription = (prescriptionData: Omit<DigitalPrescription, 'id' | 'date'>): DigitalPrescription => {
    const id = `RX-${Math.floor(9000 + Math.random() * 1000)}`;
    const today = new Date().toISOString().split('T')[0];

    const newRx: DigitalPrescription = {
      ...prescriptionData,
      id,
      date: today,
    };

    setPrescriptions((prev) => [newRx, ...prev]);

    // Attach to consultation if matching
    setConsultations((prev) =>
      prev.map((c) => (c.id === newRx.consultationId ? { ...c, prescription: newRx } : c))
    );

    addToast('success', `Digital prescription issued for ${newRx.patientName}.`);
    return newRx;
  };

  // Book Appointment
  const bookAppointment = (appointmentData: Omit<Appointment, 'id' | 'status'>): Appointment => {
    const id = `APT-${Math.floor(300 + Math.random() * 700)}`;
    const newApt: Appointment = {
      ...appointmentData,
      id,
      status: 'scheduled',
    };

    setAppointments((prev) => [newApt, ...prev]);
    addToast('success', `Appointment booked with ${newApt.doctorName} for ${newApt.date}.`);
    return newApt;
  };

  // Toggle Reminder
  const toggleReminderTaken = (reminderId: string) => {
    setReminders((prev) =>
      prev.map((r) => (r.id === reminderId ? { ...r, takenToday: !r.takenToday } : r))
    );
  };

  // Add Surveillance Cluster
  const addSurveillanceCluster = (clusterData: Omit<SurveillanceCluster, 'id'>) => {
    const id = `SURV-${Date.now()}`;
    const newCluster: SurveillanceCluster = {
      ...clusterData,
      id,
    };
    setSurveillanceClusters((prev) => [newCluster, ...prev]);

    if (!isOnline) {
      const syncItem: SyncQueueItem = {
        id: `SYNC-${Date.now()}`,
        type: 'surveillance',
        action: 'REPORT_CLUSTER',
        title: `Outbreak Report: ${newCluster.syndrome}`,
        details: `${newCluster.village} (${newCluster.casesCount} cases)`,
        timestamp: new Date().toLocaleString(),
        status: 'pending',
      };
      setSyncQueue((prev) => [syncItem, ...prev]);
      addToast('warning', `Outbreak report queued in offline vault.`);
    } else {
      addToast('success', `Outbreak report transmitted to District Health Cloud.`);
    }
  };

  // Perform Sync
  const performSync = async () => {
    if (!isOnline) {
      addToast('error', 'Cannot sync while offline. Please connect to internet or switch to Online mode first.');
      return;
    }
    if (syncQueue.length === 0) {
      addToast('info', 'Sync queue is clear. All records are currently synchronized.');
      return;
    }

    addToast('info', 'Synchronizing with District Health Cloud...');

    try {
      // Live sync bridge to standalone Node.js REST API server (http://localhost:5000)
      await fetch('http://localhost:5000/api/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ items: syncQueue }),
      }).catch(() => null);
    } catch {
      // Fallback if backend server is not running
    }

    setTimeout(() => {
      setSyncQueue([]);
      setPatients((prev) => prev.map((p) => ({ ...p, syncStatus: 'synced' })));
      setConsultations((prev) => prev.map((c) => ({ ...c, syncStatus: 'synced' })));
      addToast('success', 'Cloud synchronization completed successfully.');
    }, 1200);
  };

  const clearOfflineStorage = () => {
    setPatients(INITIAL_PATIENTS);
    setConsultations(INITIAL_CONSULTATIONS);
    setSyncQueue(INITIAL_SYNC_QUEUE);
    setPrescriptions(INITIAL_PRESCRIPTIONS);
    setAppointments(INITIAL_APPOINTMENTS);
    localStorage.clear();
    addToast('info', 'Demo storage reset to initial synthetic dataset.');
  };

  return (
    <AppContext.Provider
      value={{
        activeTab,
        setActiveTab,
        isOnline,
        setIsOnline,
        language,
        setLanguage,
        translate,
        currentUser,
        setCurrentUser,
        switchUserRole,
        isAuthenticated,
        login,
        logout,
        isAuthModalOpen,
        setIsAuthModalOpen,
        patients,
        consultations,
        syncQueue,
        doctors,
        hospitals,
        prescriptions,
        appointments,
        reminders,
        surveillanceClusters,
        chwProfile,
        toasts,
        selectedPatient,
        setSelectedPatient,
        isPatientModalOpen,
        setIsPatientModalOpen,
        isConsultationModalOpen,
        setIsConsultationModalOpen,
        defaultConsultationPatientId,
        setDefaultConsultationPatientId,
        isPrescriptionModalOpen,
        setIsPrescriptionModalOpen,
        isEmergencyVoiceModalOpen,
        setIsEmergencyVoiceModalOpen,
        openEmergencyVoice,
        addPatient,
        addConsultation,
        logPatientVitals,
        addPrescription,
        bookAppointment,
        toggleReminderTaken,
        addSurveillanceCluster,
        performSync,
        addToast,
        removeToast,
        clearOfflineStorage,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
