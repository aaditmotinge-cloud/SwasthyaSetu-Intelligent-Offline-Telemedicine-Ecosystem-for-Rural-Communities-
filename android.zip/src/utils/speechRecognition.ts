import type { AppLanguage } from '../types';

export interface EmergencySpeechAnalysis {
  transcript: string;
  isEmergency: boolean;
  riskLevel: 'critical' | 'moderate' | 'normal';
  matchedKeywords: string[];
  recommendedAction: string;
  symptomsDetected: {
    fever: boolean;
    cough: boolean;
    breathlessness: boolean;
    chestPain: boolean;
    dizziness: boolean;
    vomiting: boolean;
    bleeding: boolean;
    unconscious: boolean;
  };
}

// Emergency keywords database across English, Hindi, and Marathi
export const EMERGENCY_KEYWORDS = {
  critical: [
    // English
    'chest pain', 'heart attack', 'cardiac', 'difficulty breathing', 'breathless',
    'cant breathe', 'shortness of breath', 'unconscious', 'fainted', 'unresponsive',
    'severe bleeding', 'blood loss', 'stroke', 'paralysis', 'seizure', 'fits',
    'choking', 'poison', 'snake bite', 'accident', 'head injury', 'collapsed',
    // Hindi
    'छाती में दर्द', 'सीने में दर्द', 'हार्ट अटैक', 'दिल का दौरा', 'सांस लेने में तकलीफ',
    'सांस फूलना', 'दम घुटना', 'बेहोश', 'बेहोशी', 'खून बहना', 'लकवा', 'दौरा',
    'मिर्गी', 'जहर', 'सांप', 'दुर्घटना', 'गंभीर चोट',
    // Marathi
    'छातीत दुखणे', 'छातीत कळ', 'हार्ट अटॅक', 'हृदयविकार', 'श्वास घेण्यास त्रास',
    'दम लागणे', 'श्वास कोंडणे', 'बेशुद्ध', 'शुद्ध हरपणे', 'रक्तस्त्राव', 'पक्षाघात',
    'आकडी', 'विषबाधा', 'साप चावला', 'अपघात'
  ],
  moderate: [
    // English
    'high fever', 'chills', 'dizziness', 'vomiting', 'dehydration', 'severe headache',
    'diarrhea', 'abdominal pain', 'stomach pain', 'high blood pressure', 'bp',
    // Hindi
    'तेज बुखार', 'चक्कर', 'उल्टी', 'दस्त', 'पेट में तेज दर्द', 'सिर दर्द', 'बीपी',
    // Marathi
    'तीव्र ताप', 'चक्कर येणे', 'उलटी', 'जुलाब', 'पोटात दुखणे', 'डोकेदुखी'
  ],
  routine: [
    // English
    'mild fever', 'cough', 'cold', 'body ache', 'throat pain', 'weakness', 'fatigue',
    // Hindi
    'हल्का बुखार', 'खांसी', 'सर्दी', 'बदन दर्द', 'गले में खराश', 'कमजोरी',
    // Marathi
    'कमी ताप', 'खोकला', 'सर्दी', 'अंगदुखी', 'घसा दुखणे', 'थकवा'
  ]
};

export function analyzeEmergencySpeech(
  transcript: string,
  _language: AppLanguage = 'en'
): EmergencySpeechAnalysis {
  const normalizedText = transcript.toLowerCase();

  const matchedCritical = EMERGENCY_KEYWORDS.critical.filter((kw) =>
    normalizedText.includes(kw.toLowerCase())
  );
  const matchedModerate = EMERGENCY_KEYWORDS.moderate.filter((kw) =>
    normalizedText.includes(kw.toLowerCase())
  );
  const matchedRoutine = EMERGENCY_KEYWORDS.routine.filter((kw) =>
    normalizedText.includes(kw.toLowerCase())
  );

  const isCritical = matchedCritical.length > 0;
  const isModerate = matchedModerate.length > 0 || matchedRoutine.length >= 2;

  let riskLevel: 'critical' | 'moderate' | 'normal' = 'normal';
  if (isCritical) {
    riskLevel = 'critical';
  } else if (isModerate) {
    riskLevel = 'moderate';
  }

  // Symptom extraction
  const symptomsDetected = {
    chestPain: isCritical && (
      normalizedText.includes('chest') ||
      normalizedText.includes('heart') ||
      normalizedText.includes('छाती') ||
      normalizedText.includes('सीने') ||
      normalizedText.includes('हार्ट')
    ),
    breathlessness:
      normalizedText.includes('breath') ||
      normalizedText.includes('सांस') ||
      normalizedText.includes('दम') ||
      normalizedText.includes('श्वास'),
    fever:
      normalizedText.includes('fever') ||
      normalizedText.includes('बुखार') ||
      normalizedText.includes('ताप'),
    cough:
      normalizedText.includes('cough') ||
      normalizedText.includes('खांसी') ||
      normalizedText.includes('खोकला'),
    dizziness:
      normalizedText.includes('dizzi') ||
      normalizedText.includes('faint') ||
      normalizedText.includes('चक्कर') ||
      normalizedText.includes('बेशुद्ध') ||
      normalizedText.includes('बेहोश'),
    vomiting:
      normalizedText.includes('vomit') ||
      normalizedText.includes('उल्टी') ||
      normalizedText.includes('उलटी'),
    bleeding:
      normalizedText.includes('bleed') ||
      normalizedText.includes('blood') ||
      normalizedText.includes('खून') ||
      normalizedText.includes('रक्त'),
    unconscious:
      normalizedText.includes('unconscious') ||
      normalizedText.includes('unresponsive') ||
      normalizedText.includes('बेहोश') ||
      normalizedText.includes('बेशुद्ध')
  };

  let recommendedAction = 'Continue routine symptomatic observation. Consult ASHA worker if symptoms persist.';
  if (riskLevel === 'critical') {
    recommendedAction = 'IMMEDIATE RED FLAG: Dispatch 108 Emergency Ambulance or transfer immediately to nearest Community Health Centre (CHC).';
  } else if (riskLevel === 'moderate') {
    recommendedAction = 'URGENT ATTENTION: Check vitals (BP, SpO2) and schedule priority Medical Officer tele-consultation within 2 hours.';
  }

  return {
    transcript,
    isEmergency: isCritical,
    riskLevel,
    matchedKeywords: [...matchedCritical, ...matchedModerate],
    recommendedAction,
    symptomsDetected,
  };
}
