import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import type { NavTab } from '../../context/AppContext';
import type { AppLanguage } from '../../types';
import {
  HeartPulse,
  LayoutDashboard,
  Stethoscope,
  Activity,
  RefreshCw,
  Menu,
  X,
  Wifi,
  WifiOff,
  Building2,
  Calendar,
  Pill,
  Mic,
  Users,
  TrendingUp,
  Settings,
  LogOut,
} from 'lucide-react';

export const MobileNav: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
    isOnline,
    setIsOnline,
    syncQueue,
    currentUser,
    switchUserRole,
    language,
    setLanguage,
    translate,
    openEmergencyVoice,
    logout,
  } = useApp();

  const [isOpen, setIsOpen] = useState(false);

  const tabs: { id: NavTab; labelKey: string; icon: React.ReactNode }[] = [
    { id: 'dashboard', labelKey: 'dashboard', icon: <LayoutDashboard className="w-5 h-5" /> },
    { id: 'consultations', labelKey: 'consultations', icon: <Stethoscope className="w-5 h-5" /> },
    { id: 'symptom-assessment', labelKey: 'symptomAssessment', icon: <Activity className="w-5 h-5" /> },
    { id: 'hospitals', labelKey: 'hospitals', icon: <Building2 className="w-5 h-5" /> },
    { id: 'sync-status', labelKey: 'syncStatus', icon: <RefreshCw className="w-5 h-5" /> },
  ];

  const allDrawerItems: {
    id: NavTab;
    labelKey: string;
    icon: React.ReactNode;
    roles?: ('patient' | 'asha' | 'doctor')[];
  }[] = [
    { id: 'dashboard', labelKey: 'dashboard', icon: <LayoutDashboard className="w-5 h-5" /> },
    { id: 'patients', labelKey: 'patients', icon: <Users className="w-5 h-5" />, roles: ['asha', 'doctor'] },
    { id: 'consultations', labelKey: 'consultations', icon: <Stethoscope className="w-5 h-5" /> },
    { id: 'symptom-assessment', labelKey: 'symptomAssessment', icon: <Activity className="w-5 h-5" /> },
    { id: 'hospitals', labelKey: 'hospitals', icon: <Building2 className="w-5 h-5" /> },
    { id: 'appointments', labelKey: 'appointments', icon: <Calendar className="w-5 h-5" /> },
    { id: 'pharmacy', labelKey: 'pharmacy', icon: <Pill className="w-5 h-5" /> },
    { id: 'surveillance', labelKey: 'surveillance', icon: <TrendingUp className="w-5 h-5" />, roles: ['asha', 'doctor'] },
    { id: 'sync-status', labelKey: 'syncStatus', icon: <RefreshCw className="w-5 h-5" /> },
    { id: 'settings', labelKey: 'settings', icon: <Settings className="w-5 h-5" /> },
  ];

  const visibleDrawerItems = allDrawerItems.filter(
    (item) => !item.roles || item.roles.includes(currentUser.role)
  );

  const handleNavClick = (tab: NavTab) => {
    setActiveTab(tab);
    setIsOpen(false);
  };

  return (
    <>
      {/* Top Mobile Bar */}
      <div className="md:hidden bg-slate-900 text-white px-4 py-3 flex items-center justify-between sticky top-0 z-40 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-teal-600 flex items-center justify-center text-white">
            <HeartPulse className="w-5 h-5" />
          </div>
          <span className="font-extrabold text-base tracking-tight">SwasthyaSetu</span>
        </div>

        <div className="flex items-center gap-2">
          {/* Emergency Voice SOS Trigger (Mobile) - Only for Patient Role */}
          {currentUser.role === 'patient' && (
            <button
              type="button"
              onClick={openEmergencyVoice}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-xs font-black shadow-xs active:scale-95 animate-pulse"
              title="Emergency Voice SOS"
            >
              <Mic className="w-3.5 h-3.5" />
              <span>SOS</span>
            </button>
          )}

          {/* Language Picker */}
          <select
            value={language}
            onChange={(e) => setLanguage(e.target.value as AppLanguage)}
            className="bg-slate-800 text-teal-300 text-xs font-bold px-2 py-1 rounded-lg border border-slate-700 focus:outline-hidden"
          >
            <option value="en">EN</option>
            <option value="hi">हिन्दी</option>
            <option value="mr">मराठी</option>
          </select>

          {/* Quick Connection Toggle */}
          <button
            onClick={() => setIsOnline((prev) => !prev)}
            className={`p-1.5 rounded-lg text-xs flex items-center gap-1 ${
              isOnline ? 'bg-teal-900/80 text-teal-300' : 'bg-amber-900/80 text-amber-300 animate-pulse'
            }`}
          >
            {isOnline ? <Wifi className="w-4 h-4" /> : <WifiOff className="w-4 h-4" />}
          </button>

          <button
            onClick={() => setIsOpen(!isOpen)}
            className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white"
            aria-label="Toggle menu"
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Drawer Menu Overlay */}
      {isOpen && (
        <div className="md:hidden fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex flex-col justify-between p-6">
          <div className="flex items-center justify-between pb-4 border-b border-slate-800">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-teal-600 flex items-center justify-center text-white">
                <HeartPulse className="w-6 h-6" />
              </div>
              <div>
                <h2 className="font-extrabold text-lg text-white">SwasthyaSetu</h2>
                <p className="text-xs text-teal-400">Offline Telemedicine System</p>
              </div>
            </div>
            <button onClick={() => setIsOpen(false)} className="p-2 text-slate-400 hover:text-white">
              <X className="w-6 h-6" />
            </button>
          </div>

          <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 space-y-2">
            <span className="text-[10px] font-extrabold uppercase text-slate-400 block">Switch User Role:</span>
            <div className="grid grid-cols-3 gap-2 text-xs font-bold">
              <button
                onClick={() => switchUserRole('asha')}
                className={`py-1.5 rounded-lg ${currentUser.role === 'asha' ? 'bg-teal-600 text-white' : 'bg-slate-800 text-slate-300'}`}
              >
                ASHA
              </button>
              <button
                onClick={() => switchUserRole('doctor')}
                className={`py-1.5 rounded-lg ${currentUser.role === 'doctor' ? 'bg-teal-600 text-white' : 'bg-slate-800 text-slate-300'}`}
              >
                Doctor
              </button>
              <button
                onClick={() => switchUserRole('patient')}
                className={`py-1.5 rounded-lg ${currentUser.role === 'patient' ? 'bg-teal-600 text-white' : 'bg-slate-800 text-slate-300'}`}
              >
                Patient
              </button>
            </div>
          </div>

          <nav className="my-auto space-y-1 overflow-y-auto max-h-[52vh] pr-1">
            {visibleDrawerItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-colors ${
                  activeTab === item.id ? 'bg-teal-600 text-white shadow-xs' : 'text-slate-300 hover:bg-slate-800'
                }`}
              >
                {item.icon}
                <span>{translate(item.labelKey)}</span>
              </button>
            ))}

            <button
              onClick={() => {
                setIsOpen(false);
                logout();
              }}
              className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm text-rose-400 hover:bg-rose-950/40 border border-rose-900/40 mt-3 transition-colors"
            >
              <LogOut className="w-5 h-5 text-rose-400" />
              <span>Logout / Switch User</span>
            </button>
          </nav>
        </div>
      )}

      {/* Bottom Sticky Navigation Bar */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-slate-900 border-t border-slate-800 flex items-center justify-around px-2 py-2 text-slate-400">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex flex-col items-center gap-1 px-3 py-1 rounded-lg text-[10px] font-semibold transition-colors ${
                isActive ? 'text-teal-400 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div className="relative">
                {tab.icon}
                {tab.id === 'sync-status' && syncQueue.length > 0 && (
                  <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-amber-400 rounded-full" />
                )}
              </div>
              <span>{translate(tab.labelKey).split(' ')[0]}</span>
            </button>
          );
        })}
      </div>
    </>
  );
};
