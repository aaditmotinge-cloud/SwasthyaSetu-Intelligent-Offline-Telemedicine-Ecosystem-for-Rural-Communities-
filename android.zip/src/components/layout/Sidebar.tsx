import React from 'react';
import { useApp } from '../../context/AppContext';
import type { NavTab } from '../../context/AppContext';
import {
  LayoutDashboard,
  Users,
  Stethoscope,
  Activity,
  RefreshCw,
  Settings,
  HeartPulse,
  Wifi,
  WifiOff,
  UserCheck,
  Building2,
  Calendar,
  Pill,
  TrendingUp,
} from 'lucide-react';

interface NavItemProps {
  id: NavTab;
  labelKey: string;
  icon: React.ReactNode;
  badge?: number | string;
  roles?: ('patient' | 'asha' | 'doctor')[];
}

export const Sidebar: React.FC = () => {
  const { activeTab, setActiveTab, syncQueue, isOnline, currentUser, translate } = useApp();

  const navItems: NavItemProps[] = [
    { id: 'dashboard', labelKey: 'dashboard', icon: <LayoutDashboard className="w-5 h-5" /> },
    { id: 'patients', labelKey: 'patients', icon: <Users className="w-5 h-5" />, roles: ['asha', 'doctor'] },
    { id: 'consultations', labelKey: 'consultations', icon: <Stethoscope className="w-5 h-5" /> },
    { id: 'symptom-assessment', labelKey: 'symptomAssessment', icon: <Activity className="w-5 h-5" /> },
    { id: 'hospitals', labelKey: 'hospitals', icon: <Building2 className="w-5 h-5" /> },
    { id: 'appointments', labelKey: 'appointments', icon: <Calendar className="w-5 h-5" /> },
    { id: 'pharmacy', labelKey: 'pharmacy', icon: <Pill className="w-5 h-5" /> },
    { id: 'surveillance', labelKey: 'surveillance', icon: <TrendingUp className="w-5 h-5" />, roles: ['asha', 'doctor'] },
    {
      id: 'sync-status',
      labelKey: 'syncStatus',
      icon: <RefreshCw className="w-5 h-5" />,
      badge: syncQueue.length > 0 ? syncQueue.length : undefined,
    },
    { id: 'settings', labelKey: 'settings', icon: <Settings className="w-5 h-5" /> },
  ];

  const visibleNavItems = navItems.filter(
    (item) => !item.roles || item.roles.includes(currentUser.role)
  );

  return (
    <aside className="hidden md:flex flex-col w-64 bg-slate-900 border-r border-slate-800 shrink-0 min-h-screen text-slate-300 select-none">
      {/* Brand Header */}
      <div className="p-5 border-b border-slate-800 flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-teal-600 flex items-center justify-center text-white shadow-md shadow-teal-900/40">
          <HeartPulse className="w-6 h-6 animate-pulse" />
        </div>
        <div>
          <h1 className="font-extrabold text-lg text-white tracking-tight">SwasthyaSetu</h1>
          <p className="text-[10px] text-teal-400 font-medium tracking-wide uppercase">
            Telemedicine Ecosystem
          </p>
        </div>
      </div>

      {/* Connection Indicator Bar */}
      <div
        className={`px-4 py-2 mx-3 mt-3 rounded-lg text-xs font-semibold flex items-center justify-between border ${
          isOnline
            ? 'bg-teal-950/60 text-teal-300 border-teal-800/60'
            : 'bg-amber-950/80 text-amber-300 border-amber-800/80 animate-pulse'
        }`}
      >
        <div className="flex items-center gap-2">
          {isOnline ? <Wifi className="w-4 h-4 text-teal-400" /> : <WifiOff className="w-4 h-4 text-amber-400" />}
          <span>{isOnline ? translate('networkOnline') : translate('networkOffline')}</span>
        </div>
        <span
          className={`w-2 h-2 rounded-full ${
            isOnline ? 'bg-teal-400 shadow-sm shadow-teal-400' : 'bg-amber-400 shadow-sm shadow-amber-400'
          }`}
        />
      </div>

      {/* Navigation Links */}
      <nav className="flex-1 px-3 py-3 space-y-1 overflow-y-auto max-h-[calc(100vh-210px)]">
        {visibleNavItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-medium transition-all ${
                isActive
                  ? 'bg-teal-600 text-white shadow-md shadow-teal-900/50 font-semibold'
                  : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/70'
              }`}
            >
              <div className="flex items-center gap-3">
                <span className={isActive ? 'text-white' : 'text-slate-400'}>{item.icon}</span>
                <span>{translate(item.labelKey)}</span>
              </div>
              {item.badge !== undefined && (
                <span
                  className={`px-2 py-0.5 text-[10px] font-bold rounded-full ${
                    isActive
                      ? 'bg-teal-800 text-teal-100'
                      : typeof item.badge === 'number'
                      ? 'bg-amber-500 text-amber-950 font-extrabold'
                      : 'bg-slate-800 text-teal-400 border border-teal-800'
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* User Profile Footer */}
      <div className="p-3.5 m-3 bg-slate-800/80 rounded-xl border border-slate-700/60 mt-auto">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-full bg-teal-800 text-teal-200 flex items-center justify-center font-bold text-xs border border-teal-600 shrink-0">
            <UserCheck className="w-4 h-4 text-teal-300" />
          </div>
          <div className="min-w-0 flex-1 text-xs">
            <p className="font-bold text-white truncate">{currentUser.name}</p>
            <p className="text-[10px] text-teal-400 font-medium truncate uppercase">
              Role: {currentUser.role}
            </p>
          </div>
        </div>
      </div>
    </aside>
  );
};
