import React from 'react';
import { useApp } from '../../context/AppContext';
import type { AppLanguage } from '../../types';
import {
  Wifi,
  WifiOff,
  UserPlus,
  Stethoscope,
  RefreshCw,
  Globe,
  Mic,
  LogOut,
} from 'lucide-react';

export const Header: React.FC = () => {
  const {
    activeTab,
    isOnline,
    setIsOnline,
    syncQueue,
    performSync,
    setIsPatientModalOpen,
    setIsConsultationModalOpen,
    setDefaultConsultationPatientId,
    currentUser,
    switchUserRole,
    logout,
    openEmergencyVoice,
    language,
    setLanguage,
    translate,
  } = useApp();

  const getTitle = () => {
    switch (activeTab) {
      case 'dashboard':
        return `${currentUser.role === 'asha' ? 'ASHA Command Center' : currentUser.role === 'doctor' ? 'Clinical Doctor Hub' : 'Patient Health Portal'}`;
      case 'patients':
        return translate('patients');
      case 'consultations':
        return translate('consultations');
      case 'symptom-assessment':
        return translate('symptomAssessment');
      case 'sync-status':
        return translate('syncStatus');
      case 'hospitals':
        return translate('hospitals');
      case 'appointments':
        return translate('appointments');
      case 'pharmacy':
        return translate('pharmacy');
      case 'surveillance':
        return translate('surveillance');
      case 'settings':
        return translate('settings');
      default:
        return translate('appName');
    }
  };

  const handleQuickNewConsultation = () => {
    setDefaultConsultationPatientId(undefined);
    setIsConsultationModalOpen(true);
  };

  return (
    <header className="bg-white border-b border-slate-200 px-4 sm:px-8 py-3.5 sticky top-0 z-30 flex flex-wrap items-center justify-between gap-3 shadow-xs">
      <div>
        <div className="flex items-center gap-2">
          <h2 className="text-lg sm:text-xl font-extrabold text-slate-900 tracking-tight">{getTitle()}</h2>
          <span className="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase bg-teal-100 text-teal-900">
            {currentUser.role === 'asha' ? 'ASHA' : currentUser.role === 'doctor' ? 'DOCTOR' : 'PATIENT'}
          </span>
        </div>
        <p className="text-xs text-slate-500 font-medium hidden sm:block">
          Primary Health Sub-Centre • Sitapur District Telemedicine Portal
        </p>
      </div>

      <div className="flex flex-wrap items-center gap-2.5">
        {/* Emergency Voice SOS Trigger - Only for Patient Role */}
        {currentUser.role === 'patient' && (
          <button
            type="button"
            onClick={openEmergencyVoice}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-black transition-all bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200 shadow-xs active:scale-95 group"
            title="Voice-Activated Emergency Triage (Hindi, Marathi, English)"
          >
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-600"></span>
            </span>
            <Mic className="w-3.5 h-3.5 text-rose-600 group-hover:scale-110 transition-transform" />
            <span className="hidden sm:inline">{translate('emergencyVoiceSOS')}</span>
            <span className="sm:hidden font-extrabold">SOS</span>
          </button>
        )}

        {/* Role Switcher Selector */}
        <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs font-semibold">
          <button
            onClick={() => switchUserRole('asha')}
            className={`px-2.5 py-1 rounded-lg transition-all ${
              currentUser.role === 'asha' ? 'bg-teal-700 text-white font-bold shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            ASHA
          </button>
          <button
            onClick={() => switchUserRole('doctor')}
            className={`px-2.5 py-1 rounded-lg transition-all ${
              currentUser.role === 'doctor' ? 'bg-teal-700 text-white font-bold shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Doctor
          </button>
          <button
            onClick={() => switchUserRole('patient')}
            className={`px-2.5 py-1 rounded-lg transition-all ${
              currentUser.role === 'patient' ? 'bg-teal-700 text-white font-bold shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Patient
          </button>
        </div>

        {/* Language Selector Switcher */}
        <div className="flex items-center gap-1 bg-slate-100 px-2 py-1 rounded-xl border border-slate-200 text-xs font-bold text-slate-700">
          <Globe className="w-3.5 h-3.5 text-teal-700" />
          <select
            value={language}
            onChange={(e) => setLanguage(e.target.value as AppLanguage)}
            className="bg-transparent focus:outline-hidden font-extrabold cursor-pointer"
          >
            <option value="en">EN</option>
            <option value="hi">हिंदी</option>
            <option value="mr">मराठी</option>
          </select>
        </div>

        {/* Connectivity Simulator Toggle */}
        <button
          onClick={() => setIsOnline((prev) => !prev)}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-bold transition-all border ${
            isOnline
              ? 'bg-teal-50 text-teal-800 border-teal-200 hover:bg-teal-100'
              : 'bg-amber-50 text-amber-900 border-amber-300 hover:bg-amber-100 animate-pulse'
          }`}
          title="Click to simulate Online / Offline field network conditions"
        >
          {isOnline ? (
            <>
              <Wifi className="w-3.5 h-3.5 text-teal-600" />
              <span className="hidden lg:inline text-teal-700 font-extrabold">4G Online</span>
            </>
          ) : (
            <>
              <WifiOff className="w-3.5 h-3.5 text-amber-600" />
              <span className="hidden lg:inline text-amber-800 font-extrabold">Offline</span>
            </>
          )}
        </button>

        {/* Sync Status Button if pending queue */}
        {syncQueue.length > 0 && (
          <button
            onClick={performSync}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs rounded-xl shadow-xs transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Sync ({syncQueue.length})</span>
          </button>
        )}

        {/* Logout to Login Page Button */}
        <button
          type="button"
          onClick={logout}
          className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-bold text-slate-500 hover:text-rose-600 hover:bg-rose-50 border border-slate-200 transition-colors cursor-pointer"
          title="Sign out to Login Screen"
        >
          <LogOut className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Logout</span>
        </button>

        {/* Action Buttons for ASHA / Doctor */}
        {currentUser.role !== 'patient' && (
          <div className="hidden xl:flex items-center gap-2">
            <button
              onClick={() => setIsPatientModalOpen(true)}
              className="flex items-center gap-1 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-xs rounded-xl transition-colors border border-slate-300"
            >
              <UserPlus className="w-3.5 h-3.5 text-teal-700" />
              <span>+ Patient</span>
            </button>

            <button
              onClick={handleQuickNewConsultation}
              className="flex items-center gap-1 px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors"
            >
              <Stethoscope className="w-3.5 h-3.5" />
              <span>+ Consult</span>
            </button>
          </div>
        )}
      </div>
    </header>
  );
};
