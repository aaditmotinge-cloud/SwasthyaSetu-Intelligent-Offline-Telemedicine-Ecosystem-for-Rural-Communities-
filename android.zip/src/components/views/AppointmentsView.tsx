import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import type { Doctor } from '../../types';
import { Modal } from '../common/Modal';
import {
  Calendar,
  UserCheck,
  Stethoscope,
  Plus,
  Search,
  Star,
  Building2,
} from 'lucide-react';

export const AppointmentsView: React.FC = () => {
  const {
    doctors,
    appointments,
    patients,
    bookAppointment,
    isPrescriptionModalOpen,
    setIsPrescriptionModalOpen,
    addPrescription,
    currentUser,
    addToast,
  } = useApp();

  const [selectedSpecialty, setSelectedSpecialty] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);

  // Form State for Booking
  const [bookingPatientId, setBookingPatientId] = useState('');
  const [bookingDate, setBookingDate] = useState('');
  const [bookingSlot, setBookingSlot] = useState('10:00 AM');
  const [chiefComplaint, setChiefComplaint] = useState('');

  // Form State for Prescription (Doctor View)
  const [rxPatientId, setRxPatientId] = useState('');
  const [medsList, setMedsList] = useState<
    { name: string; dosage: string; frequency: string; durationDays: number; instructions: string }[]
  >([
    { name: 'Tab Paracetamol', dosage: '500mg', frequency: '1-0-1', durationDays: 5, instructions: 'After meal' },
  ]);
  const [precautionsAdvice, setPrecautionsAdvice] = useState('');

  const isPatientRole = currentUser.role === 'patient';
  const myPatient = patients.find((p) => p.id === currentUser.associatedPatientId) || patients[0];

  const filteredDoctors = doctors.filter((doc) => {
    const matchesSearch =
      doc.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      doc.specialty.toLowerCase().includes(searchTerm.toLowerCase()) ||
      doc.hospital.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesSpecialty = selectedSpecialty === 'All' || doc.specialty.includes(selectedSpecialty);
    return matchesSearch && matchesSpecialty;
  });

  const handleOpenBooking = (doc: Doctor) => {
    setSelectedDoctor(doc);
    if (isPatientRole) {
      setBookingPatientId(myPatient.id);
    } else if (patients.length > 0) {
      setBookingPatientId(patients[0].id);
    }
    setBookingDate(new Date().toISOString().split('T')[0]);
    setIsBookingModalOpen(true);
  };

  const roleFilteredAppointments = isPatientRole
    ? appointments.filter((a) => a.patientId === myPatient.id)
    : currentUser.role === 'doctor'
    ? appointments.filter((a) => a.doctorName.toLowerCase().includes('verma') || a.doctorId === 'DOC-101')
    : appointments;

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDoctor || !bookingPatientId || !bookingDate) {
      addToast('error', 'Please fill all required appointment fields.');
      return;
    }

    const patient = patients.find((p) => p.id === bookingPatientId);
    if (!patient) return;

    bookAppointment({
      patientId: patient.id,
      patientName: patient.name,
      doctorId: selectedDoctor.id,
      doctorName: selectedDoctor.name,
      specialty: selectedDoctor.specialty,
      date: bookingDate,
      timeSlot: bookingSlot,
      chiefComplaint: chiefComplaint.trim() || 'Routine Consultation',
    });

    setIsBookingModalOpen(false);
  };

  const handleAddMedRow = () => {
    setMedsList((prev) => [
      ...prev,
      { name: '', dosage: '', frequency: '1-0-1', durationDays: 5, instructions: '' },
    ]);
  };

  const handlePrescriptionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!rxPatientId) {
      addToast('error', 'Please select patient for digital prescription.');
      return;
    }

    const patient = patients.find((p) => p.id === rxPatientId);
    if (!patient) return;

    const formattedMeds = medsList
      .filter((m) => m.name.trim())
      .map((m, idx) => ({
        id: `m-${idx + 1}`,
        name: m.name,
        dosage: m.dosage || 'Standard',
        frequency: m.frequency,
        durationDays: Number(m.durationDays) || 5,
        instructions: m.instructions,
      }));

    addPrescription({
      consultationId: `CON-${Date.now()}`,
      patientId: patient.id,
      patientName: patient.name,
      doctorId: currentUser.id,
      doctorName: currentUser.name,
      medications: formattedMeds,
      precautionsAdvice: precautionsAdvice.trim() || 'Follow dosage carefully & rest.',
    });

    setIsPrescriptionModalOpen(false);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 tracking-tight">
            Doctor Discovery & Appointments
          </h2>
          <p className="text-xs text-slate-500">
            Book specialist consultations, manage scheduled slots, and issue digital prescriptions.
          </p>
        </div>

        {currentUser.role === 'doctor' && (
          <button
            onClick={() => {
              if (patients.length > 0) setRxPatientId(patients[0].id);
              setIsPrescriptionModalOpen(true);
            }}
            className="flex items-center gap-2 px-4 py-2.5 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs sm:text-sm rounded-xl shadow-xs transition-colors shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>+ Issue Digital Prescription</span>
          </button>
        )}
      </div>

      {/* Scheduled Appointments Section */}
      {roleFilteredAppointments.length > 0 && (
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-3">
          <h3 className="font-extrabold text-base text-slate-900 border-b border-slate-100 pb-2 flex items-center gap-2">
            <Calendar className="w-4 h-4 text-teal-600" />
            <span>
              {isPatientRole ? 'My Scheduled Tele-Consultations' : 'Scheduled Appointments'} ({roleFilteredAppointments.length})
            </span>
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {roleFilteredAppointments.map((apt) => (
              <div
                key={apt.id}
                className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-2"
              >
                <div className="flex items-center justify-between font-bold text-slate-900">
                  <span className="flex items-center gap-1.5 text-teal-800">
                    <UserCheck className="w-4 h-4 text-teal-600" /> {apt.patientName}
                  </span>
                  <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-[10px] rounded-full uppercase">
                    {apt.status}
                  </span>
                </div>

                <div className="space-y-1 text-slate-600">
                  <p>
                    <strong>Doctor:</strong> {apt.doctorName} ({apt.specialty})
                  </p>
                  <p className="font-mono text-[11px] text-slate-500">
                    Date & Time: {apt.date} at {apt.timeSlot}
                  </p>
                  <p className="italic text-slate-700 bg-white p-2 rounded border border-slate-200">
                    "{apt.chiefComplaint}"
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Doctor Directory */}
      <div className="space-y-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="sm:col-span-2 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              placeholder="Search Doctor Name, Specialty, Hospital..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium focus:bg-white focus:ring-2 focus:ring-teal-500"
            />
          </div>

          <div>
            <select
              value={selectedSpecialty}
              onChange={(e) => setSelectedSpecialty(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-800 focus:bg-white focus:ring-2 focus:ring-teal-500"
            >
              <option value="All">All Specialties</option>
              <option value="General Medicine">General Medicine</option>
              <option value="Obstetrics">Gynecology / MCH</option>
              <option value="Pediatrician">Pediatrician</option>
              <option value="Cardiologist">Cardiologist</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredDoctors.map((doc) => (
            <div
              key={doc.id}
              className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4 hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-full bg-teal-100 text-teal-800 font-extrabold flex items-center justify-center text-sm border border-teal-200 shrink-0">
                      <Stethoscope className="w-5 h-5 text-teal-700" />
                    </div>
                    <div>
                      <h3 className="font-extrabold text-base text-slate-900">{doc.name}</h3>
                      <p className="text-xs font-bold text-teal-700">{doc.specialty}</p>
                      <p className="text-[11px] text-slate-500">{doc.qualification}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1 bg-amber-50 text-amber-900 px-2 py-1 rounded-lg text-xs font-extrabold border border-amber-200">
                    <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                    <span>{doc.rating}</span>
                  </div>
                </div>

                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 space-y-1 text-xs">
                  <div className="flex items-center gap-1.5 text-slate-700">
                    <Building2 className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="font-medium">{doc.hospital}</span>
                  </div>
                  <div className="flex items-center justify-between text-slate-500 text-[11px]">
                    <span>Experience: {doc.experienceYears} Years</span>
                    <span>License: {doc.licenseNo}</span>
                  </div>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-500">
                  Available: {doc.availableDays.join(', ')}
                </span>

                <button
                  onClick={() => handleOpenBooking(doc)}
                  className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1.5"
                >
                  <Calendar className="w-3.5 h-3.5" />
                  <span>Book Appointment</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* MODAL 1: BOOK APPOINTMENT */}
      {selectedDoctor && (
        <Modal
          isOpen={isBookingModalOpen}
          onClose={() => setIsBookingModalOpen(false)}
          title={`Book Appointment — ${selectedDoctor.name}`}
          subtitle={selectedDoctor.specialty}
        >
          <form onSubmit={handleBookingSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {isPatientRole ? 'Patient Details' : 'Select Patient'}
              </label>
              {isPatientRole ? (
                <div className="p-3 bg-teal-50 border border-teal-200 rounded-xl text-xs text-teal-950 font-bold flex items-center justify-between">
                  <span>{myPatient.name} ({myPatient.village})</span>
                  <span className="font-mono text-[11px] text-teal-800">ABHA: {myPatient.abhaId}</span>
                </div>
              ) : (
                <select
                  value={bookingPatientId}
                  onChange={(e) => setBookingPatientId(e.target.value)}
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-medium"
                >
                  {patients.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.village}) • ABHA: {p.abhaId}
                    </option>
                  ))}
                </select>
              )}
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Preferred Date</label>
                <input
                  type="date"
                  value={bookingDate}
                  onChange={(e) => setBookingDate(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Time Slot</label>
                <select
                  value={bookingSlot}
                  onChange={(e) => setBookingSlot(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-medium"
                >
                  <option value="10:00 AM">10:00 AM</option>
                  <option value="11:30 AM">11:30 AM</option>
                  <option value="02:30 PM">02:30 PM</option>
                  <option value="04:00 PM">04:00 PM</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Reason for Appointment</label>
              <textarea
                rows={2}
                placeholder="Describe chief complaint or routine review notes..."
                value={chiefComplaint}
                onChange={(e) => setChiefComplaint(e.target.value)}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm"
              />
            </div>

            <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setIsBookingModalOpen(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-xl shadow-xs"
              >
                Confirm Appointment Slot
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* MODAL 2: ISSUE DIGITAL PRESCRIPTION */}
      <Modal
        isOpen={isPrescriptionModalOpen}
        onClose={() => setIsPrescriptionModalOpen(false)}
        title="Issue Digital Prescription"
        subtitle="Create verifiable digital E-Prescription for patient"
        maxWidth="max-w-3xl"
      >
        <form onSubmit={handlePrescriptionSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Select Patient</label>
            <select
              value={rxPatientId}
              onChange={(e) => setRxPatientId(e.target.value)}
              className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-medium"
            >
              {patients.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.age}y, {p.village}) • ABHA: {p.abhaId}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-extrabold text-slate-700 uppercase tracking-wider">
                Prescribed Medications
              </label>
              <button
                type="button"
                onClick={handleAddMedRow}
                className="text-xs font-bold text-teal-700 hover:text-teal-900"
              >
                + Add Medication
              </button>
            </div>

            {medsList.map((m, idx) => (
              <div key={idx} className="p-3 bg-slate-50 rounded-xl border border-slate-200 grid grid-cols-1 sm:grid-cols-4 gap-2 text-xs">
                <input
                  type="text"
                  placeholder="Medicine Name (e.g. Tab Amlodipine)"
                  value={m.name}
                  onChange={(e) => {
                    const list = [...medsList];
                    list[idx].name = e.target.value;
                    setMedsList(list);
                  }}
                  className="px-3 py-1.5 bg-white border border-slate-300 rounded-lg sm:col-span-2"
                />
                <input
                  type="text"
                  placeholder="Dosage (e.g. 5mg)"
                  value={m.dosage}
                  onChange={(e) => {
                    const list = [...medsList];
                    list[idx].dosage = e.target.value;
                    setMedsList(list);
                  }}
                  className="px-3 py-1.5 bg-white border border-slate-300 rounded-lg"
                />
                <input
                  type="text"
                  placeholder="Timing (e.g. 1-0-1 after meal)"
                  value={m.frequency}
                  onChange={(e) => {
                    const list = [...medsList];
                    list[idx].frequency = e.target.value;
                    setMedsList(list);
                  }}
                  className="px-3 py-1.5 bg-white border border-slate-300 rounded-lg"
                />
              </div>
            ))}
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Precautions & Dietary Advice</label>
            <textarea
              rows={2}
              placeholder="e.g. Low salt intake, drink plenty of fluids, avoid heavy exertion..."
              value={precautionsAdvice}
              onChange={(e) => setPrecautionsAdvice(e.target.value)}
              className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm"
            />
          </div>

          <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={() => setIsPrescriptionModalOpen(false)}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-xl shadow-xs"
            >
              Save & Issue Digital E-Prescription
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
