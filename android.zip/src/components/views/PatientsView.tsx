import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import type { Patient } from '../../types';
import { Modal } from '../common/Modal';
import {
  Search,
  UserPlus,
  MapPin,
  Stethoscope,
  QrCode,
  FileText,
} from 'lucide-react';

export const PatientsView: React.FC = () => {
  const {
    patients,
    addPatient,
    isPatientModalOpen,
    setIsPatientModalOpen,
    selectedPatient,
    setSelectedPatient,
    setIsConsultationModalOpen,
    setDefaultConsultationPatientId,
    consultations,
    currentUser,
    setActiveTab,
  } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedVillage, setSelectedVillage] = useState('All');
  const [selectedTriage, setSelectedTriage] = useState('All');

  // Form State for New Patient Registration
  const [formData, setFormData] = useState({
    name: '',
    abhaId: '',
    age: '',
    gender: 'Male' as Patient['gender'],
    village: 'Rampur',
    phone: '',
    bloodGroup: 'O+',
    emergencyContact: '',
    chronicConditionsStr: '',
    allergiesStr: '',
    triageLevel: 'normal' as Patient['triageLevel'],
  });

  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  // Search & Filter Patients
  const filteredPatients = patients.filter((p) => {
    const matchesSearch =
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.abhaId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.village.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.phone.includes(searchTerm);

    const matchesVillage = selectedVillage === 'All' || p.village === selectedVillage;
    const matchesTriage = selectedTriage === 'All' || p.triageLevel === selectedTriage;

    return matchesSearch && matchesVillage && matchesTriage;
  });

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errors: Record<string, string> = {};

    if (!formData.name.trim()) errors.name = 'Patient Full Name is required';
    if (!formData.age || Number(formData.age) <= 0 || Number(formData.age) > 120) {
      errors.age = 'Please enter a valid age (1-120)';
    }
    if (!formData.village.trim()) errors.village = 'Village name is required';
    if (!formData.phone.trim() || formData.phone.length < 10) {
      errors.phone = 'Valid 10-digit mobile number required';
    }

    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      return;
    }

    const chronicConditions = formData.chronicConditionsStr
      ? formData.chronicConditionsStr.split(',').map((s) => s.trim())
      : ['None'];
    const allergies = formData.allergiesStr
      ? formData.allergiesStr.split(',').map((s) => s.trim())
      : ['None'];

    addPatient({
      name: formData.name.trim(),
      abhaId: formData.abhaId.trim(),
      age: Number(formData.age),
      gender: formData.gender,
      village: formData.village.trim(),
      phone: formData.phone.trim(),
      bloodGroup: formData.bloodGroup,
      emergencyContact: formData.emergencyContact.trim() || 'N/A',
      chronicConditions,
      allergies,
      triageLevel: formData.triageLevel,
    });

    // Reset & Close
    setFormData({
      name: '',
      abhaId: '',
      age: '',
      gender: 'Male',
      village: 'Rampur',
      phone: '',
      bloodGroup: 'O+',
      emergencyContact: '',
      chronicConditionsStr: '',
      allergiesStr: '',
      triageLevel: 'normal',
    });
    setFormErrors({});
    setIsPatientModalOpen(false);
  };

  const handleOpenConsultationForPatient = (patientId: string) => {
    setSelectedPatient(null);
    setDefaultConsultationPatientId(patientId);
    setIsConsultationModalOpen(true);
  };

  if (currentUser.role === 'patient') {
    const myPatient =
      patients.find((p) => p.id === currentUser.associatedPatientId) || patients[0];

    return (
      <div className="space-y-6 pb-12">
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-4">
            <div>
              <h2 className="text-xl font-extrabold text-slate-900 tracking-tight">
                My Digital Patient Dossier
              </h2>
              <p className="text-xs text-slate-500">
                Your authenticated ABHA health identity card and clinical profile.
              </p>
            </div>
            <button
              onClick={() => setActiveTab('dashboard')}
              className="px-4 py-2 bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs rounded-xl shadow-xs transition-colors cursor-pointer"
            >
              Back to Dashboard
            </button>
          </div>

          <div className="bg-gradient-to-br from-teal-900 to-slate-900 text-white rounded-2xl p-6 shadow-md space-y-4 max-w-lg">
            <div className="flex items-center justify-between border-b border-teal-700/60 pb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-teal-300">
                Ayushman Bharat Digital Health Pass
              </span>
              <span className="text-[10px] font-extrabold px-2 py-0.5 rounded bg-emerald-500 text-slate-950 uppercase">
                Active Pass
              </span>
            </div>
            <div>
              <h3 className="text-2xl font-black">{myPatient.name}</h3>
              <p className="text-xs text-teal-200">
                Age: {myPatient.age}y • Gender: {myPatient.gender} • Blood Group: {myPatient.bloodGroup}
              </p>
            </div>
            <div className="pt-2">
              <span className="text-[10px] uppercase text-teal-400 block font-bold">
                ABHA Health ID
              </span>
              <span className="font-mono text-lg font-black tracking-wider text-teal-100">
                {myPatient.abhaId}
              </span>
            </div>
            <div className="text-xs text-slate-300 pt-2 border-t border-teal-800 space-y-1">
              <p>Village Panchayat: <strong>{myPatient.village}</strong></p>
              <p>Emergency Contact: {myPatient.emergencyContact}</p>
              <p>Registered Chronic Conditions: {myPatient.chronicConditions.join(', ')}</p>
              <p>Allergies: {myPatient.allergies.join(', ')}</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-12">
      {/* Top Header & Search Bar Row */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-extrabold text-slate-900 tracking-tight">
              Community Health Directory
            </h2>
            <p className="text-xs text-slate-500">
              Manage local citizen records, ABHA health cards & triage status.
            </p>
          </div>

          <button
            onClick={() => setIsPatientModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2.5 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs sm:text-sm rounded-xl shadow-xs transition-colors"
          >
            <UserPlus className="w-4 h-4" />
            <span>Register New Patient</span>
          </button>
        </div>

        {/* Search and Filters */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 pt-2">
          {/* Search Box */}
          <div className="md:col-span-2 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              placeholder="Search by Patient Name, ABHA ID, Village, Phone..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-800 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-teal-500 transition-all"
            />
          </div>

          {/* Village Filter */}
          <div>
            <select
              value={selectedVillage}
              onChange={(e) => setSelectedVillage(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-800 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-teal-500"
            >
              <option value="All">All Villages (Cluster)</option>
              <option value="Rampur">Rampur Village</option>
              <option value="Kalyanpur">Kalyanpur Village</option>
              <option value="Belpur">Belpur Village</option>
            </select>
          </div>

          {/* Triage Filter */}
          <div>
            <select
              value={selectedTriage}
              onChange={(e) => setSelectedTriage(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-800 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-teal-500"
            >
              <option value="All">All Triage Levels</option>
              <option value="normal">Normal Priority</option>
              <option value="moderate">Moderate Priority</option>
              <option value="critical">High Risk / Critical</option>
            </select>
          </div>
        </div>
      </div>

      {/* Patient Cards / Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredPatients.map((patient) => {
          const patientConsultations = consultations.filter((c) => c.patientId === patient.id);
          const isCritical = patient.triageLevel === 'critical';

          return (
            <div
              key={patient.id}
              className={`bg-white rounded-2xl border p-5 shadow-xs transition-all flex flex-col justify-between hover:shadow-md ${
                isCritical ? 'border-rose-300 ring-2 ring-rose-500/10' : 'border-slate-200'
              }`}
            >
              <div className="space-y-3">
                {/* Header Row */}
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-teal-100 text-teal-800 font-extrabold flex items-center justify-center text-sm border border-teal-200 shrink-0">
                      {patient.name
                        .split(' ')
                        .map((n) => n[0])
                        .join('')}
                    </div>
                    <div>
                      <h3
                        onClick={() => setSelectedPatient(patient)}
                        className="font-extrabold text-base text-slate-900 hover:text-teal-700 cursor-pointer"
                      >
                        {patient.name}
                      </h3>
                      <p className="text-xs text-slate-500">
                        {patient.age} yrs • {patient.gender} • Blood Group: <strong>{patient.bloodGroup}</strong>
                      </p>
                    </div>
                  </div>

                  <span
                    className={`px-2.5 py-1 rounded-full text-[10px] font-extrabold uppercase ${
                      isCritical
                        ? 'bg-rose-100 text-rose-800'
                        : patient.triageLevel === 'moderate'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}
                  >
                    {patient.triageLevel}
                  </span>
                </div>

                {/* ABHA Badge & Village */}
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200/80 space-y-1.5 text-xs">
                  <div className="flex items-center justify-between text-slate-600">
                    <span className="font-semibold">ABHA Health ID:</span>
                    <span className="font-mono font-bold text-slate-900">{patient.abhaId}</span>
                  </div>
                  <div className="flex items-center justify-between text-slate-600">
                    <span className="font-semibold">Village:</span>
                    <span className="font-medium text-slate-800 flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-teal-600" />
                      {patient.village}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-slate-600">
                    <span className="font-semibold">Mobile:</span>
                    <span className="font-mono text-slate-800">{patient.phone}</span>
                  </div>
                </div>

                {/* Conditions & History */}
                <div className="text-xs text-slate-600 space-y-1">
                  <p>
                    <strong className="text-slate-800">History: </strong>
                    {patient.chronicConditions.join(', ')}
                  </p>
                  <p className="text-[11px] text-slate-500">
                    Consultations: <strong>{patientConsultations.length} recorded</strong>
                  </p>
                </div>
              </div>

              {/* Card Footer Actions */}
              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                <button
                  onClick={() => setSelectedPatient(patient)}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-lg transition-colors"
                >
                  View Details
                </button>
                <button
                  onClick={() => handleOpenConsultationForPatient(patient.id)}
                  className="px-3.5 py-1.5 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-lg transition-colors flex items-center gap-1"
                >
                  <Stethoscope className="w-3.5 h-3.5" />
                  <span>+ Consult</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {filteredPatients.length === 0 && (
        <div className="bg-white rounded-2xl p-12 text-center border border-slate-200 text-slate-500 space-y-3">
          <Search className="w-10 h-10 text-slate-300 mx-auto" />
          <h3 className="text-base font-bold text-slate-800">No matching patients found</h3>
          <p className="text-xs">Try modifying search term or clear active filters.</p>
        </div>
      )}

      {/* MODAL 1: REGISTER NEW PATIENT */}
      <Modal
        isOpen={isPatientModalOpen}
        onClose={() => setIsPatientModalOpen(false)}
        title="Register Community Patient"
        subtitle="Create offline health profile & ABHA card entry for rural citizen"
      >
        <form onSubmit={handleRegisterSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Full Name <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                placeholder="e.g. Ramesh Kumar"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-medium focus:bg-white focus:ring-2 focus:ring-teal-500 outline-hidden"
              />
              {formErrors.name && (
                <p className="text-xs text-rose-600 font-semibold mt-1">{formErrors.name}</p>
              )}
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                ABHA Health ID (Optional)
              </label>
              <input
                type="text"
                placeholder="e.g. 91-4820-9182-3011 (Auto-generated if empty)"
                value={formData.abhaId}
                onChange={(e) => setFormData({ ...formData, abhaId: e.target.value })}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-mono text-slate-800 focus:bg-white focus:ring-2 focus:ring-teal-500 outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Age (Years) <span className="text-rose-500">*</span>
              </label>
              <input
                type="number"
                placeholder="e.g. 35"
                value={formData.age}
                onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-medium focus:bg-white focus:ring-2 focus:ring-teal-500 outline-hidden"
              />
              {formErrors.age && (
                <p className="text-xs text-rose-600 font-semibold mt-1">{formErrors.age}</p>
              )}
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Gender</label>
              <select
                value={formData.gender}
                onChange={(e) => setFormData({ ...formData, gender: e.target.value as Patient['gender'] })}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-medium focus:bg-white focus:ring-2 focus:ring-teal-500 outline-hidden"
              >
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Village / Panchayat <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                placeholder="e.g. Rampur"
                value={formData.village}
                onChange={(e) => setFormData({ ...formData, village: e.target.value })}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-medium focus:bg-white focus:ring-2 focus:ring-teal-500 outline-hidden"
              />
              {formErrors.village && (
                <p className="text-xs text-rose-600 font-semibold mt-1">{formErrors.village}</p>
              )}
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Mobile Number <span className="text-rose-500">*</span>
              </label>
              <input
                type="tel"
                placeholder="e.g. +91 98765 43210"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-medium focus:bg-white focus:ring-2 focus:ring-teal-500 outline-hidden"
              />
              {formErrors.phone && (
                <p className="text-xs text-rose-600 font-semibold mt-1">{formErrors.phone}</p>
              )}
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Blood Group</label>
              <select
                value={formData.bloodGroup}
                onChange={(e) => setFormData({ ...formData, bloodGroup: e.target.value })}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-medium focus:bg-white focus:ring-2 focus:ring-teal-500 outline-hidden"
              >
                <option value="O+">O+</option>
                <option value="O-">O-</option>
                <option value="A+">A+</option>
                <option value="A-">A-</option>
                <option value="B+">B+</option>
                <option value="B-">B-</option>
                <option value="AB+">AB+</option>
                <option value="AB-">AB-</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Initial Triage Priority</label>
              <select
                value={formData.triageLevel}
                onChange={(e) => setFormData({ ...formData, triageLevel: e.target.value as Patient['triageLevel'] })}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-medium focus:bg-white focus:ring-2 focus:ring-teal-500 outline-hidden"
              >
                <option value="normal">Normal (Routine Care)</option>
                <option value="moderate">Moderate Priority</option>
                <option value="critical">Critical (Immediate Referral)</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Known Chronic Conditions (Comma separated)
            </label>
            <input
              type="text"
              placeholder="e.g. Hypertension, Type-2 Diabetes, Asthma"
              value={formData.chronicConditionsStr}
              onChange={(e) => setFormData({ ...formData, chronicConditionsStr: e.target.value })}
              className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-medium focus:bg-white focus:ring-2 focus:ring-teal-500 outline-hidden"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Known Allergies (Comma separated)
            </label>
            <input
              type="text"
              placeholder="e.g. Penicillin, Dust, Sulfa"
              value={formData.allergiesStr}
              onChange={(e) => setFormData({ ...formData, allergiesStr: e.target.value })}
              className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-medium focus:bg-white focus:ring-2 focus:ring-teal-500 outline-hidden"
            />
          </div>

          <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={() => setIsPatientModalOpen(false)}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-xl shadow-xs"
            >
              Save Patient Record
            </button>
          </div>
        </form>
      </Modal>

      {/* MODAL 2: PATIENT DETAILS SCREEN */}
      {selectedPatient && (
        <Modal
          isOpen={!!selectedPatient}
          onClose={() => setSelectedPatient(null)}
          title={`Patient Health Dossier — ${selectedPatient.name}`}
          subtitle={`ABHA ID: ${selectedPatient.abhaId}`}
        >
          <div className="space-y-6">
            {/* ABHA Card Graphic Preview */}
            <div className="bg-gradient-to-r from-teal-900 via-teal-800 to-slate-900 rounded-2xl p-5 text-white shadow-lg relative overflow-hidden">
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <span className="text-[10px] font-extrabold uppercase tracking-widest text-teal-300 bg-teal-950 px-2 py-0.5 rounded border border-teal-700">
                    ABHA Digital Health Pass
                  </span>
                  <h3 className="text-xl font-black text-white">{selectedPatient.name}</h3>
                  <p className="text-xs text-teal-200 font-mono">{selectedPatient.abhaId}</p>
                </div>
                <div className="w-14 h-14 bg-white p-1 rounded-lg shrink-0 flex items-center justify-center">
                  <QrCode className="w-12 h-12 text-slate-900" />
                </div>
              </div>

              <div className="mt-4 pt-4 border-t border-teal-700/60 grid grid-cols-3 gap-2 text-xs text-teal-100">
                <div>
                  <span className="text-[10px] text-teal-400 block">AGE / GENDER</span>
                  <span className="font-bold">{selectedPatient.age} yrs • {selectedPatient.gender}</span>
                </div>
                <div>
                  <span className="text-[10px] text-teal-400 block">BLOOD GROUP</span>
                  <span className="font-bold text-amber-300">{selectedPatient.bloodGroup}</span>
                </div>
                <div>
                  <span className="text-[10px] text-teal-400 block">VILLAGE</span>
                  <span className="font-bold">{selectedPatient.village}</span>
                </div>
              </div>
            </div>

            {/* Medical Info & Conditions */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-1">
                <span className="font-bold text-slate-700 block text-xs uppercase tracking-wide">
                  Chronic Pre-conditions
                </span>
                <p className="text-slate-800 font-medium">
                  {selectedPatient.chronicConditions.join(', ') || 'None reported'}
                </p>
              </div>

              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-1">
                <span className="font-bold text-slate-700 block text-xs uppercase tracking-wide">
                  Allergies
                </span>
                <p className="text-slate-800 font-medium">
                  {selectedPatient.allergies.join(', ') || 'None reported'}
                </p>
              </div>
            </div>

            {/* Consultation History for Patient */}
            <div className="space-y-3">
              <h4 className="font-extrabold text-sm text-slate-900 flex items-center gap-2">
                <FileText className="w-4 h-4 text-teal-600" />
                <span>Consultation History ({consultations.filter((c) => c.patientId === selectedPatient.id).length})</span>
              </h4>

              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {consultations
                  .filter((c) => c.patientId === selectedPatient.id)
                  .map((con) => (
                    <div
                      key={con.id}
                      className="p-3 bg-white rounded-xl border border-slate-200 text-xs space-y-1"
                    >
                      <div className="flex items-center justify-between font-bold text-slate-800">
                        <span>{con.date}</span>
                        <span className="text-teal-700 bg-teal-50 px-2 py-0.5 rounded text-[10px]">
                          {con.chwName}
                        </span>
                      </div>
                      <p className="text-slate-600">
                        <strong>Chief Complaint:</strong> {con.chiefComplaint}
                      </p>
                      {con.vitals.bpSystolic && (
                        <p className="text-slate-500 font-mono text-[11px]">
                          Vitals: BP {con.vitals.bpSystolic}/{con.vitals.bpDiastolic} | SpO2{' '}
                          {con.vitals.oxygenSaturation}% | Pulse {con.vitals.pulseRate} bpm
                        </p>
                      )}
                    </div>
                  ))}

                {consultations.filter((c) => c.patientId === selectedPatient.id).length === 0 && (
                  <p className="text-xs text-slate-500 italic bg-slate-50 p-3 rounded-lg text-center">
                    No consultations logged yet for this patient.
                  </p>
                )}
              </div>
            </div>

            {/* Action Bar */}
            <div className="pt-4 border-t border-slate-200 flex items-center justify-between">
              <button
                onClick={() => setSelectedPatient(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl"
              >
                Close Dossier
              </button>
              <button
                onClick={() => handleOpenConsultationForPatient(selectedPatient.id)}
                className="px-5 py-2 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5"
              >
                <Stethoscope className="w-4 h-4" />
                <span>Start New Consultation</span>
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
