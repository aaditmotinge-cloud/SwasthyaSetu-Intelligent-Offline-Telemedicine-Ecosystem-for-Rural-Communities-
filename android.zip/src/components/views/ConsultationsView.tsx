import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import type { Consultation, Vitals } from '../../types';
import { Modal } from '../common/Modal';
import {
  Stethoscope,
  Plus,
  Search,
  Activity,
  Heart,
  Thermometer,
  Wind,
  Send,
} from 'lucide-react';

const COMMON_SYMPTOMS = [
  'Fever (>100°F)',
  'Cough (Dry/Productive)',
  'Shortness of Breath',
  'Chest Tightness / Pain',
  'Headache / Migraine',
  'Abdominal Pain / Nausea',
  'Diarrhea / Vomiting',
  'Joint / Body Aches',
  'Skin Rash / Lesions',
  'High Blood Pressure History',
  'Dizziness / Fainting',
  'Fatigue / Extreme Weakness',
];

export const ConsultationsView: React.FC = () => {
  const {
    consultations,
    patients,
    addConsultation,
    isConsultationModalOpen,
    setIsConsultationModalOpen,
    defaultConsultationPatientId,
    setDefaultConsultationPatientId,
    currentUser,
  } = useApp();

  const isPatientRole = currentUser.role === 'patient';
  const myPatient = patients.find((p) => p.id === currentUser.associatedPatientId) || patients[0];

  const [searchTerm, setSearchTerm] = useState('');
  const [riskFilter, setRiskFilter] = useState('All');

  // Consultation Form State
  const [selectedPatientId, setSelectedPatientId] = useState('');
  const [chiefComplaint, setChiefComplaint] = useState('');
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);
  const [prescriptionAdvice, setPrescriptionAdvice] = useState('');
  const [notes, setNotes] = useState('');
  const [followUpDate, setFollowUpDate] = useState('');
  const [teleconsultationRequested, setTeleconsultationRequested] = useState(false);

  // Vitals State
  const [vitals, setVitals] = useState<Vitals>({
    bpSystolic: undefined,
    bpDiastolic: undefined,
    pulseRate: undefined,
    oxygenSaturation: undefined,
    bodyTemp: undefined,
    respRate: undefined,
  });

  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (defaultConsultationPatientId) {
      setSelectedPatientId(defaultConsultationPatientId);
    } else if (patients.length > 0 && !selectedPatientId) {
      setSelectedPatientId(patients[0].id);
    }
  }, [defaultConsultationPatientId, patients]);

  const toggleSymptom = (symptom: string) => {
    setSelectedSymptoms((prev) =>
      prev.includes(symptom) ? prev.filter((s) => s !== symptom) : [...prev, symptom]
    );
  };

  const handleConsultationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errors: Record<string, string> = {};

    if (!selectedPatientId) errors.patientId = 'Please select a patient from directory';
    if (!chiefComplaint.trim()) errors.chiefComplaint = 'Chief complaint / reason for visit is required';
    if (selectedSymptoms.length === 0) errors.symptoms = 'Please select at least one symptom';

    // Vitals safety checks
    if (vitals.oxygenSaturation && (vitals.oxygenSaturation < 50 || vitals.oxygenSaturation > 100)) {
      errors.spO2 = 'SpO2 must be between 50% and 100%';
    }
    if (vitals.bpSystolic && (vitals.bpSystolic < 50 || vitals.bpSystolic > 260)) {
      errors.bpSystolic = 'Invalid Systolic BP value';
    }

    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      return;
    }

    const patient = patients.find((p) => p.id === selectedPatientId);
    if (!patient) return;

    // Calculate preliminary risk level for consultation
    let triageRisk: Consultation['triageRisk'] = 'low';
    if (
      (vitals.oxygenSaturation && vitals.oxygenSaturation < 92) ||
      (vitals.bpSystolic && vitals.bpSystolic > 160) ||
      selectedSymptoms.includes('Shortness of Breath') ||
      selectedSymptoms.includes('Chest Tightness / Pain')
    ) {
      triageRisk = 'critical';
    } else if (
      (vitals.oxygenSaturation && vitals.oxygenSaturation < 95) ||
      (vitals.bpSystolic && vitals.bpSystolic > 140) ||
      selectedSymptoms.includes('Fever (>100°F)')
    ) {
      triageRisk = 'moderate';
    }

    addConsultation({
      patientId: patient.id,
      patientName: patient.name,
      patientAge: patient.age,
      patientVillage: patient.village,
      chiefComplaint: chiefComplaint.trim(),
      symptoms: selectedSymptoms,
      vitals,
      notes: notes.trim() || 'No additional notes.',
      prescriptionAdvice: prescriptionAdvice.trim() || 'Rest, fluid hydration & routine monitoring.',
      followUpDate: followUpDate || undefined,
      teleconsultationRequested,
      triageRisk,
    });

    // Reset form
    setChiefComplaint('');
    setSelectedSymptoms([]);
    setPrescriptionAdvice('');
    setNotes('');
    setFollowUpDate('');
    setTeleconsultationRequested(false);
    setVitals({
      bpSystolic: undefined,
      bpDiastolic: undefined,
      pulseRate: undefined,
      oxygenSaturation: undefined,
      bodyTemp: undefined,
      respRate: undefined,
    });
    setFormErrors({});
    setIsConsultationModalOpen(false);
  };

  const roleFiltered = isPatientRole
    ? consultations.filter((c) => c.patientId === myPatient.id)
    : consultations;

  const filteredConsultations = roleFiltered.filter((c) => {
    const matchesSearch =
      c.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.chiefComplaint.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.patientVillage.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesRisk = riskFilter === 'All' || c.triageRisk === riskFilter;
    return matchesSearch && matchesRisk;
  });

  return (
    <div className="space-y-6 pb-12">
      {/* Top Header Card */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-extrabold text-slate-900 tracking-tight">
              {isPatientRole ? 'My Consultation Records' : 'Teleconsultation Ledger'}
            </h2>
            <p className="text-xs text-slate-500">
              {isPatientRole
                ? `Personal medical notes, prescribed remedies, and doctor advice for ${myPatient.name}.`
                : 'Record vitals, symptoms, OTC remedies, and flag cases for District Medical Officer video call.'}
            </p>
          </div>

          {!isPatientRole && (
            <button
              onClick={() => {
                setDefaultConsultationPatientId(undefined);
                setIsConsultationModalOpen(true);
              }}
              className="flex items-center gap-2 px-4 py-2.5 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs sm:text-sm rounded-xl shadow-xs transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Record New Consultation</span>
            </button>
          )}
        </div>

        {/* Search & Filters */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
          <div className="sm:col-span-2 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              placeholder="Search by Patient Name, Chief Complaint, Village..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-800 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-teal-500"
            />
          </div>

          <div>
            <select
              value={riskFilter}
              onChange={(e) => setRiskFilter(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-800 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-teal-500"
            >
              <option value="All">All Risk Levels</option>
              <option value="low">Low Risk</option>
              <option value="moderate">Moderate Risk</option>
              <option value="critical">Critical / Urgent</option>
            </select>
          </div>
        </div>
      </div>

      {/* Consultation Records List */}
      <div className="space-y-4">
        {filteredConsultations.map((con) => {
          const isCritical = con.triageRisk === 'critical';
          const isModerate = con.triageRisk === 'moderate';

          return (
            <div
              key={con.id}
              className={`bg-white rounded-2xl border p-5 shadow-xs transition-all space-y-4 ${
                isCritical ? 'border-rose-300 ring-2 ring-rose-500/10' : 'border-slate-200'
              }`}
            >
              {/* Top Meta Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-teal-100 text-teal-800 font-extrabold flex items-center justify-center text-xs shrink-0">
                    <Stethoscope className="w-5 h-5 text-teal-700" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-base text-slate-900">{con.patientName}</h3>
                    <p className="text-xs text-slate-500">
                      {con.patientAge} yrs • {con.patientVillage} Village • Recorded by <strong>{con.chwName}</strong>
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono text-slate-500">{con.date}</span>
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                      isCritical
                        ? 'bg-rose-100 text-rose-800'
                        : isModerate
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-teal-100 text-teal-800'
                    }`}
                  >
                    {con.triageRisk} RISK
                  </span>
                </div>
              </div>

              {/* Body: Chief Complaints & Symptoms */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="md:col-span-2 space-y-2">
                  <div>
                    <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
                      Chief Complaint
                    </span>
                    <p className="text-sm font-semibold text-slate-800 bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                      {con.chiefComplaint}
                    </p>
                  </div>

                  <div>
                    <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-1">
                      Reported Symptoms
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {con.symptoms.map((s, idx) => (
                        <span
                          key={idx}
                          className="px-2.5 py-1 bg-teal-50 text-teal-800 border border-teal-200 rounded-lg text-xs font-medium"
                        >
                          {s}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div>
                    <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block mt-2">
                      Advice / OTC Medication
                    </span>
                    <p className="text-xs text-slate-700 bg-emerald-50/60 p-2.5 rounded-xl border border-emerald-200">
                      {con.prescriptionAdvice}
                    </p>
                  </div>
                </div>

                {/* Vitals Sidebar Box */}
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/90 space-y-3">
                  <span className="text-xs font-extrabold text-slate-700 uppercase tracking-wider block border-b border-slate-200 pb-2">
                    Recorded Vitals
                  </span>

                  <div className="space-y-2 text-xs font-mono">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500 flex items-center gap-1">
                        <Heart className="w-3.5 h-3.5 text-rose-500" /> BP:
                      </span>
                      <span className="font-bold text-slate-900">
                        {con.vitals.bpSystolic ? `${con.vitals.bpSystolic}/${con.vitals.bpDiastolic} mmHg` : 'N/A'}
                      </span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-slate-500 flex items-center gap-1">
                        <Activity className="w-3.5 h-3.5 text-cyan-600" /> SpO2:
                      </span>
                      <span
                        className={`font-bold ${
                          con.vitals.oxygenSaturation && con.vitals.oxygenSaturation < 95
                            ? 'text-rose-700 bg-rose-100 px-1 rounded'
                            : 'text-slate-900'
                        }`}
                      >
                        {con.vitals.oxygenSaturation ? `${con.vitals.oxygenSaturation}%` : 'N/A'}
                      </span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-slate-500 flex items-center gap-1">
                        <Thermometer className="w-3.5 h-3.5 text-amber-600" /> Pulse:
                      </span>
                      <span className="font-bold text-slate-900">
                        {con.vitals.pulseRate ? `${con.vitals.pulseRate} bpm` : 'N/A'}
                      </span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-slate-500 flex items-center gap-1">
                        <Wind className="w-3.5 h-3.5 text-teal-600" /> Temp:
                      </span>
                      <span className="font-bold text-slate-900">
                        {con.vitals.bodyTemp ? `${con.vitals.bodyTemp} °F` : 'N/A'}
                      </span>
                    </div>
                  </div>

                  {con.teleconsultationRequested && (
                    <div className="pt-2 border-t border-slate-200">
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold text-purple-800 bg-purple-100 px-2 py-1 rounded-md w-full justify-center">
                        <Send className="w-3 h-3" /> Teleconsult Request Flagged
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}

        {filteredConsultations.length === 0 && (
          <div className="bg-white rounded-2xl p-12 text-center border border-slate-200 text-slate-500 space-y-3">
            <Stethoscope className="w-10 h-10 text-slate-300 mx-auto" />
            <h3 className="text-base font-bold text-slate-800">No consultation records match</h3>
            <p className="text-xs">Adjust search keywords or risk filter.</p>
          </div>
        )}
      </div>

      {/* FORM MODAL: RECORD NEW CONSULTATION */}
      <Modal
        isOpen={isConsultationModalOpen}
        onClose={() => setIsConsultationModalOpen(false)}
        title="Record New Teleconsultation"
        subtitle="Log patient symptoms, physical vitals, and preliminary care plan"
        maxWidth="max-w-3xl"
      >
        <form onSubmit={handleConsultationSubmit} className="space-y-5">
          {/* Step 1: Select Patient */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Select Patient <span className="text-rose-500">*</span>
            </label>
            <select
              value={selectedPatientId}
              onChange={(e) => setSelectedPatientId(e.target.value)}
              className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-medium focus:bg-white focus:ring-2 focus:ring-teal-500"
            >
              <option value="">-- Choose Patient from Directory --</option>
              {patients.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.age}y, {p.village}) • ABHA: {p.abhaId}
                </option>
              ))}
            </select>
            {formErrors.patientId && (
              <p className="text-xs text-rose-600 font-semibold mt-1">{formErrors.patientId}</p>
            )}
          </div>

          {/* Step 2: Chief Complaint */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Chief Complaint / Reason for Visit <span className="text-rose-500">*</span>
            </label>
            <textarea
              rows={2}
              placeholder="Describe primary symptom, duration, and patient comments..."
              value={chiefComplaint}
              onChange={(e) => setChiefComplaint(e.target.value)}
              className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-medium focus:bg-white focus:ring-2 focus:ring-teal-500 outline-hidden"
            />
            {formErrors.chiefComplaint && (
              <p className="text-xs text-rose-600 font-semibold mt-1">{formErrors.chiefComplaint}</p>
            )}
          </div>

          {/* Step 3: Symptoms Selector Checklist */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Select Symptoms Checklist <span className="text-rose-500">*</span>
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {COMMON_SYMPTOMS.map((symptom) => {
                const isSelected = selectedSymptoms.includes(symptom);
                return (
                  <button
                    type="button"
                    key={symptom}
                    onClick={() => toggleSymptom(symptom)}
                    className={`px-3 py-2 rounded-xl text-xs font-semibold text-left transition-all border ${
                      isSelected
                        ? 'bg-teal-600 text-white border-teal-700 shadow-xs'
                        : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                    }`}
                  >
                    {symptom}
                  </button>
                );
              })}
            </div>
            {formErrors.symptoms && (
              <p className="text-xs text-rose-600 font-semibold mt-1">{formErrors.symptoms}</p>
            )}
          </div>

          {/* Step 4: Vitals Entry Inputs */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
            <span className="text-xs font-extrabold text-slate-800 uppercase tracking-wider block">
              Patient Physical Vitals (Optional / Field Device Inputs)
            </span>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  BP Systolic (mmHg)
                </label>
                <input
                  type="number"
                  placeholder="120"
                  value={vitals.bpSystolic || ''}
                  onChange={(e) =>
                    setVitals({ ...vitals, bpSystolic: e.target.value ? Number(e.target.value) : undefined })
                  }
                  className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  BP Diastolic (mmHg)
                </label>
                <input
                  type="number"
                  placeholder="80"
                  value={vitals.bpDiastolic || ''}
                  onChange={(e) =>
                    setVitals({ ...vitals, bpDiastolic: e.target.value ? Number(e.target.value) : undefined })
                  }
                  className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  SpO2 (% Saturation)
                </label>
                <input
                  type="number"
                  placeholder="98"
                  value={vitals.oxygenSaturation || ''}
                  onChange={(e) =>
                    setVitals({
                      ...vitals,
                      oxygenSaturation: e.target.value ? Number(e.target.value) : undefined,
                    })
                  }
                  className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-mono"
                />
                {formErrors.spO2 && (
                  <p className="text-[10px] text-rose-600 font-bold">{formErrors.spO2}</p>
                )}
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Pulse (BPM)
                </label>
                <input
                  type="number"
                  placeholder="72"
                  value={vitals.pulseRate || ''}
                  onChange={(e) =>
                    setVitals({ ...vitals, pulseRate: e.target.value ? Number(e.target.value) : undefined })
                  }
                  className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-mono"
                />
              </div>
            </div>
          </div>

          {/* Step 5: Prescription & Followup */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Advice / OTC Remedies
              </label>
              <textarea
                rows={2}
                placeholder="e.g. Paracetamol 500mg, ORS hydration solution..."
                value={prescriptionAdvice}
                onChange={(e) => setPrescriptionAdvice(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Follow-up Date & Options
              </label>
              <input
                type="date"
                value={followUpDate}
                onChange={(e) => setFollowUpDate(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm mb-2"
              />
              <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-purple-900 bg-purple-50 p-2 rounded-lg border border-purple-200">
                <input
                  type="checkbox"
                  checked={teleconsultationRequested}
                  onChange={(e) => setTeleconsultationRequested(e.target.checked)}
                  className="rounded text-purple-600 focus:ring-purple-500"
                />
                <span>Flag for District MO Teleconsultation</span>
              </label>
            </div>
          </div>

          {/* Form Actions */}
          <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={() => setIsConsultationModalOpen(false)}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-xl shadow-xs"
            >
              Save Consultation Entry
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
