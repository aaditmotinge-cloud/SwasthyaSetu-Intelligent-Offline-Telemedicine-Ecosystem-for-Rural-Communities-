import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Users,
  Stethoscope,
  RefreshCw,
  UserPlus,
  ChevronRight,
  ShieldAlert,
  MapPin,
  Clock,
  CheckCircle2,
  Heart,
  Activity,
  Calendar,
  Pill,
  Building2,
  FileText,
  Mic,
} from 'lucide-react';

export const DashboardView: React.FC = () => {
  const {
    chwProfile,
    patients,
    consultations,
    syncQueue,
    isOnline,
    setActiveTab,
    setIsPatientModalOpen,
    setIsConsultationModalOpen,
    setDefaultConsultationPatientId,
    setSelectedPatient,
    currentUser,
    logPatientVitals,
    prescriptions,
    setIsPrescriptionModalOpen,
    openEmergencyVoice,
  } = useApp();

  // State for Patient Log Vitals Form
  const [logBpSys, setLogBpSys] = useState<number | ''>('');
  const [logBpDia, setLogBpDia] = useState<number | ''>('');
  const [logSugar, setLogSugar] = useState<number | ''>('');
  const [sugarType, setSugarType] = useState<'fasting' | 'random'>('fasting');

  const myPatient = patients.find((p) => p.id === currentUser.associatedPatientId) || patients[0];

  const handlePatientLogVitals = (e: React.FormEvent) => {
    e.preventDefault();
    if (!logBpSys && !logSugar) return;

    logPatientVitals(myPatient.id, {
      bpSystolic: logBpSys ? Number(logBpSys) : undefined,
      bpDiastolic: logBpDia ? Number(logBpDia) : undefined,
      bloodSugar: logSugar ? Number(logSugar) : undefined,
      sugarType,
    });

    setLogBpSys('');
    setLogBpDia('');
    setLogSugar('');
  };

  // --- ROLE 1: PATIENT DASHBOARD ---
  if (currentUser.role === 'patient') {
    return (
      <div className="space-y-6 pb-12">
        {/* Patient Hero Banner */}
        <div className="bg-gradient-to-r from-teal-900 via-teal-800 to-slate-900 rounded-2xl p-6 text-white shadow-xl space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-teal-800/60 rounded-full text-xs font-semibold text-teal-200 border border-teal-700">
                <MapPin className="w-3.5 h-3.5" />
                <span>{myPatient.village} Panchayat</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight mt-1">
                Namaste, {myPatient.name}
              </h1>
              <p className="text-xs text-teal-100/90 mt-1">
                ABHA ID: <strong className="font-mono">{myPatient.abhaId}</strong> • Blood Group: <strong>{myPatient.bloodGroup}</strong>
              </p>
            </div>

            <button
              onClick={() => setSelectedPatient(myPatient)}
              className="px-4 py-2.5 bg-white text-teal-900 font-extrabold text-xs sm:text-sm rounded-xl shadow-md hover:bg-teal-50 shrink-0"
            >
              View My Digital ABHA Pass
            </button>
          </div>
        </div>

        {/* Emergency Voice SOS Banner for Patient */}
        <div className="bg-rose-50 border border-rose-200 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-600 text-white flex items-center justify-center shrink-0 shadow-xs">
              <Mic className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h4 className="font-extrabold text-sm text-rose-950">Feeling Unwell or in Acute Distress?</h4>
              <p className="text-xs text-rose-800/90 font-medium">
                Tap to speak symptoms in Hindi, Marathi, or English. Instant emergency triage & 108 ambulance link.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={openEmergencyVoice}
            className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-extrabold text-xs rounded-xl shadow-xs transition-transform active:scale-95 shrink-0 flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Mic className="w-4 h-4" />
            <span>Speak Symptoms Now</span>
          </button>
        </div>

        {/* Quick Actions Grid for Patient */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <button
            onClick={() => setActiveTab('symptom-assessment')}
            className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs hover:border-teal-500 text-left space-y-2 group"
          >
            <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center group-hover:bg-teal-600 group-hover:text-white transition-colors">
              <Activity className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-slate-900">Check Symptoms</h4>
              <p className="text-[11px] text-slate-500">Self Triage Matrix</p>
            </div>
          </button>

          <button
            onClick={() => setActiveTab('appointments')}
            className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs hover:border-teal-500 text-left space-y-2 group"
          >
            <div className="w-10 h-10 rounded-xl bg-cyan-50 text-cyan-700 flex items-center justify-center group-hover:bg-cyan-600 group-hover:text-white transition-colors">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-slate-900">Book Doctor</h4>
              <p className="text-[11px] text-slate-500">Specialist Slots</p>
            </div>
          </button>

          <button
            onClick={() => setActiveTab('pharmacy')}
            className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs hover:border-teal-500 text-left space-y-2 group"
          >
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center group-hover:bg-emerald-600 group-hover:text-white transition-colors">
              <Pill className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-slate-900">Medicine Reminders</h4>
              <p className="text-[11px] text-slate-500">Daily Dosage</p>
            </div>
          </button>

          <button
            onClick={() => setActiveTab('hospitals')}
            className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs hover:border-rose-500 text-left space-y-2 group"
          >
            <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-700 flex items-center justify-center group-hover:bg-rose-600 group-hover:text-white transition-colors">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-slate-900">Emergency 108</h4>
              <p className="text-[11px] text-slate-500">Hospital Locator</p>
            </div>
          </button>
        </div>

        {/* Daily Vitals Logger & History */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
            <h3 className="font-extrabold text-base text-slate-900 border-b border-slate-100 pb-2 flex items-center gap-2">
              <Heart className="w-4 h-4 text-rose-500" />
              <span>Daily Blood Pressure & Sugar Logger</span>
            </h3>

            <form onSubmit={handlePatientLogVitals} className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">BP Systolic</label>
                  <input
                    type="number"
                    placeholder="120"
                    value={logBpSys}
                    onChange={(e) => setLogBpSys(e.target.value ? Number(e.target.value) : '')}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">BP Diastolic</label>
                  <input
                    type="number"
                    placeholder="80"
                    value={logBpDia}
                    onChange={(e) => setLogBpDia(e.target.value ? Number(e.target.value) : '')}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">Blood Sugar (mg/dL)</label>
                <div className="flex gap-2">
                  <input
                    type="number"
                    placeholder="110"
                    value={logSugar}
                    onChange={(e) => setLogSugar(e.target.value ? Number(e.target.value) : '')}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs"
                  />
                  <select
                    value={sugarType}
                    onChange={(e) => setSugarType(e.target.value as 'fasting' | 'random')}
                    className="px-2 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs font-bold"
                  >
                    <option value="fasting">Fasting</option>
                    <option value="random">Random</option>
                  </select>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-xl shadow-xs"
              >
                Log Today's Measurements
              </button>
            </form>
          </div>

          {/* Vitals History List */}
          <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
            <h3 className="font-extrabold text-base text-slate-900 border-b border-slate-100 pb-2">
              My Health Vitals History
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
                <span className="font-extrabold text-xs text-slate-700 block">Blood Pressure History</span>
                {myPatient.bpHistory && myPatient.bpHistory.length > 0 ? (
                  <div className="space-y-1 text-xs">
                    {myPatient.bpHistory.map((bp, i) => (
                      <div key={i} className="flex justify-between py-1 border-b border-slate-200/60 font-mono">
                        <span className="text-slate-500">{bp.date}</span>
                        <span className="font-bold text-slate-900">{bp.sys}/{bp.dia} mmHg</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-xs text-slate-400 italic">No BP measurements logged yet.</p>
                )}
              </div>

              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
                <span className="font-extrabold text-xs text-slate-700 block">Blood Sugar History</span>
                {myPatient.bloodSugarHistory && myPatient.bloodSugarHistory.length > 0 ? (
                  <div className="space-y-1 text-xs">
                    {myPatient.bloodSugarHistory.map((bs, i) => (
                      <div key={i} className="flex justify-between py-1 border-b border-slate-200/60 font-mono">
                        <span className="text-slate-500">{bs.date} ({bs.type})</span>
                        <span className="font-bold text-slate-900">{bs.value} mg/dL</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-xs text-slate-400 italic">No sugar measurements logged yet.</p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // --- ROLE 2: DOCTOR DASHBOARD ---
  if (currentUser.role === 'doctor') {
    return (
      <div className="space-y-6 pb-12">
        <div className="bg-gradient-to-r from-slate-900 via-teal-950 to-slate-900 rounded-2xl p-6 text-white shadow-xl space-y-2">
          <h1 className="text-2xl font-extrabold">Welcome, {currentUser.name}</h1>
          <p className="text-xs text-teal-300">
            Designation: Senior Medical Officer • License: <strong className="font-mono">MCI-2015-88319</strong> • Sitapur District Hospital
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-slate-500 uppercase block">Clinical Patient Queue</span>
              <h3 className="text-3xl font-black text-slate-900">{patients.length} Patients</h3>
            </div>
            <Users className="w-8 h-8 text-teal-600" />
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-slate-500 uppercase block">Pending Tele-Video Requests</span>
              <h3 className="text-3xl font-black text-slate-900">
                {consultations.filter((c) => c.teleconsultationRequested).length} Cases
              </h3>
            </div>
            <Stethoscope className="w-8 h-8 text-purple-600" />
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-slate-500 uppercase block">Digital E-Prescriptions</span>
              <h3 className="text-3xl font-black text-slate-900">{prescriptions.length} Issued</h3>
            </div>
            <FileText className="w-8 h-8 text-cyan-600" />
          </div>
        </div>

        {/* Clinical Patient Review Table */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-5 border-b border-slate-200 flex items-center justify-between">
            <h3 className="font-extrabold text-base text-slate-900">Authorized Patient Clinical Queue</h3>
            <button
              onClick={() => setIsPrescriptionModalOpen(true)}
              className="px-3.5 py-1.5 bg-teal-600 text-white font-bold text-xs rounded-xl shadow-xs"
            >
              + Create Digital E-Prescription
            </button>
          </div>

          <div className="divide-y divide-slate-100">
            {patients.map((p) => (
              <div key={p.id} className="p-4 flex items-center justify-between hover:bg-slate-50">
                <div>
                  <h4 className="font-bold text-sm text-slate-900">{p.name} ({p.age}y, {p.gender})</h4>
                  <p className="text-xs text-slate-500">ABHA: {p.abhaId} • Village: {p.village}</p>
                  <p className="text-xs text-slate-700 mt-1">Conditions: {p.chronicConditions.join(', ')}</p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setSelectedPatient(p)}
                    className="px-3 py-1.5 bg-slate-100 text-slate-800 font-bold text-xs rounded-lg"
                  >
                    View Dossier
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // --- ROLE 3: ASHA WORKER DASHBOARD (DEFAULT) ---
  const totalPatients = patients.length;
  const totalConsultations = consultations.length;
  const pendingSyncCount = syncQueue.length;
  const criticalPatients = patients.filter((p) => p.triageLevel === 'critical' || p.triageLevel === 'moderate');
  const recentPatients = patients.slice(0, 4);
  const recentConsultations = consultations.slice(0, 3);

  const handleStartConsultationForPatient = (patientId: string) => {
    setDefaultConsultationPatientId(patientId);
    setIsConsultationModalOpen(true);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* CHW Welcome Hero Banner */}
      <div className="bg-gradient-to-br from-teal-800 via-teal-900 to-slate-900 rounded-2xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:16px_16px] pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-teal-700/50 rounded-full text-xs font-semibold text-teal-200 border border-teal-600/40">
              <MapPin className="w-3.5 h-3.5" />
              <span>{chwProfile.healthCenter}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Namaste, {chwProfile.name}
            </h1>
            <p className="text-sm text-teal-100/90 leading-relaxed">
              Your offline telemedicine vault is active. Record patient visits, perform vital triage,
              and sync consultation records to Sitapur District Health Cloud when network is available.
            </p>
          </div>

          <div className="flex flex-wrap gap-3 shrink-0">
            <button
              onClick={() => setIsPatientModalOpen(true)}
              className="flex items-center gap-2 px-4 py-2.5 bg-white text-teal-900 hover:bg-teal-50 font-bold text-xs sm:text-sm rounded-xl shadow-lg transition-transform active:scale-95"
            >
              <UserPlus className="w-4 h-4 text-teal-700" />
              <span>Register Patient</span>
            </button>
            <button
              onClick={() => {
                setDefaultConsultationPatientId(undefined);
                setIsConsultationModalOpen(true);
              }}
              className="flex items-center gap-2 px-4 py-2.5 bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs sm:text-sm rounded-xl shadow-lg transition-transform active:scale-95 border border-teal-400/30"
            >
              <Stethoscope className="w-4 h-4" />
              <span>Start Consultation</span>
            </button>
          </div>
        </div>

        <div className="mt-6 pt-4 border-t border-teal-700/50 flex flex-wrap items-center justify-between text-xs text-teal-200 gap-2">
          <div className="flex items-center gap-2">
            <span
              className={`w-2.5 h-2.5 rounded-full ${
                isOnline ? 'bg-teal-400 animate-pulse' : 'bg-amber-400'
              }`}
            />
            <span>
              Network Status:{' '}
              <strong className={isOnline ? 'text-white' : 'text-amber-300'}>
                {isOnline ? 'Connected (4G Satellite Bridge)' : 'Offline Vault Mode Active'}
              </strong>
            </span>
          </div>
          <div className="flex items-center gap-1.5 text-teal-300">
            <Clock className="w-3.5 h-3.5" />
            <span>Last Auto Sync: Today at 09:30 AM</span>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div
          onClick={() => setActiveTab('patients')}
          className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Registered Patients
            </span>
            <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center group-hover:bg-teal-600 group-hover:text-white transition-colors">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4 flex items-baseline justify-between">
            <h3 className="text-3xl font-extrabold text-slate-900">{totalPatients}</h3>
            <span className="text-xs font-semibold text-teal-700 bg-teal-50 px-2 py-0.5 rounded-md flex items-center gap-0.5">
              Active <ChevronRight className="w-3 h-3" />
            </span>
          </div>
        </div>

        <div
          onClick={() => setActiveTab('consultations')}
          className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Consultations
            </span>
            <div className="w-10 h-10 rounded-xl bg-cyan-50 text-cyan-600 flex items-center justify-center group-hover:bg-cyan-600 group-hover:text-white transition-colors">
              <Stethoscope className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4 flex items-baseline justify-between">
            <h3 className="text-3xl font-extrabold text-slate-900">{totalConsultations}</h3>
            <span className="text-xs font-semibold text-cyan-700 bg-cyan-50 px-2 py-0.5 rounded-md">
              Total Logged
            </span>
          </div>
        </div>

        <div
          onClick={() => setActiveTab('sync-status')}
          className={`bg-white rounded-2xl p-5 border transition-all cursor-pointer group ${
            pendingSyncCount > 0 ? 'border-amber-300 ring-2 ring-amber-400/20' : 'border-slate-200'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Pending Sync Queue
            </span>
            <div
              className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors ${
                pendingSyncCount > 0
                  ? 'bg-amber-100 text-amber-700 group-hover:bg-amber-500 group-hover:text-white'
                  : 'bg-emerald-50 text-emerald-600'
              }`}
            >
              <RefreshCw className={`w-5 h-5 ${pendingSyncCount > 0 ? 'animate-spin-slow' : ''}`} />
            </div>
          </div>
          <div className="mt-4 flex items-baseline justify-between">
            <h3 className="text-3xl font-extrabold text-slate-900">{pendingSyncCount}</h3>
            <span
              className={`text-xs font-semibold px-2 py-0.5 rounded-md ${
                pendingSyncCount > 0 ? 'bg-amber-100 text-amber-800 font-bold' : 'bg-emerald-100 text-emerald-800'
              }`}
            >
              {pendingSyncCount > 0 ? 'Action Needed' : 'All Synced'}
            </span>
          </div>
        </div>

        <div
          onClick={() => setActiveTab('symptom-assessment')}
          className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Triage Watchlist
            </span>
            <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center group-hover:bg-rose-600 group-hover:text-white transition-colors">
              <ShieldAlert className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4 flex items-baseline justify-between">
            <h3 className="text-3xl font-extrabold text-slate-900">{criticalPatients.length}</h3>
            <span className="text-xs font-semibold text-rose-700 bg-rose-50 px-2 py-0.5 rounded-md">
              Moderate / High
            </span>
          </div>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-5 border-b border-slate-200 flex items-center justify-between">
            <div>
              <h3 className="font-extrabold text-lg text-slate-900">Recent Patients</h3>
              <p className="text-xs text-slate-500">Registered Community Members in your cluster</p>
            </div>
            <button
              onClick={() => setActiveTab('patients')}
              className="text-xs font-bold text-teal-700 hover:text-teal-900 flex items-center gap-1"
            >
              <span>View All Patients ({patients.length})</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 border-b border-slate-200 text-xs font-bold text-slate-500 uppercase tracking-wider">
                <tr>
                  <th className="px-5 py-3.5">Patient Details</th>
                  <th className="px-4 py-3.5">ABHA ID / Village</th>
                  <th className="px-4 py-3.5">Triage Level</th>
                  <th className="px-4 py-3.5">Sync Status</th>
                  <th className="px-5 py-3.5 text-right">Quick Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {recentPatients.map((patient) => {
                  const isCritical = patient.triageLevel === 'critical';
                  const isModerate = patient.triageLevel === 'moderate';

                  return (
                    <tr key={patient.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="px-5 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-full bg-teal-100 text-teal-900 font-bold flex items-center justify-center text-xs shrink-0">
                            {patient.name.split(' ').map((n) => n[0]).join('')}
                          </div>
                          <div>
                            <p
                              onClick={() => setSelectedPatient(patient)}
                              className="font-bold text-slate-900 hover:text-teal-700 cursor-pointer"
                            >
                              {patient.name}
                            </p>
                            <p className="text-xs text-slate-500">
                              {patient.age} yrs • {patient.gender} • {patient.bloodGroup}
                            </p>
                          </div>
                        </div>
                      </td>

                      <td className="px-4 py-4">
                        <p className="font-mono text-xs text-slate-700 font-medium">{patient.abhaId}</p>
                        <p className="text-xs text-slate-500 flex items-center gap-1 mt-0.5">
                          <MapPin className="w-3 h-3 text-slate-400" />
                          <span>{patient.village}</span>
                        </p>
                      </td>

                      <td className="px-4 py-4">
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-extrabold ${
                            isCritical
                              ? 'bg-rose-100 text-rose-800 border border-rose-200'
                              : isModerate
                              ? 'bg-amber-100 text-amber-800 border border-amber-200'
                              : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                          }`}
                        >
                          {patient.triageLevel.toUpperCase()}
                        </span>
                      </td>

                      <td className="px-4 py-4">
                        {patient.syncStatus === 'synced' ? (
                          <span className="inline-flex items-center gap-1 text-xs text-emerald-700 font-semibold">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                            <span>Synced</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-xs text-amber-700 font-semibold">
                            <Clock className="w-3.5 h-3.5 text-amber-600" />
                            <span>Offline Draft</span>
                          </span>
                        )}
                      </td>

                      <td className="px-5 py-4 text-right">
                        <button
                          onClick={() => handleStartConsultationForPatient(patient.id)}
                          className="px-3 py-1.5 bg-teal-50 hover:bg-teal-600 text-teal-800 hover:text-white font-bold text-xs rounded-lg transition-colors border border-teal-200"
                        >
                          + Consult
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="font-extrabold text-lg text-slate-900">Recent Consultations</h3>
            <button
              onClick={() => setActiveTab('consultations')}
              className="text-xs font-bold text-teal-700 hover:text-teal-900"
            >
              View All
            </button>
          </div>

          <div className="space-y-3">
            {recentConsultations.map((con) => (
              <div
                key={con.id}
                className="p-4 rounded-xl border border-slate-200/80 bg-slate-50/50 space-y-2 hover:border-teal-300 transition-colors"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="font-bold text-sm text-slate-900">{con.patientName}</h4>
                    <p className="text-xs text-slate-500">{con.patientVillage} • {con.date}</p>
                  </div>
                  <span className="px-2 py-0.5 rounded-md text-[10px] font-extrabold bg-teal-100 text-teal-800 uppercase">
                    {con.triageRisk} RISK
                  </span>
                </div>
                <p className="text-xs text-slate-700 italic bg-white p-2 rounded-lg border border-slate-200">
                  "{con.chiefComplaint}"
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
