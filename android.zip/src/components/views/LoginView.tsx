import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import type { UserRole } from '../../types';
import {
  HeartPulse,
  UserCheck,
  Stethoscope,
  Users,
  ShieldCheck,
  Lock,
  Phone,
  ArrowRight,
  Sparkles,
  KeyRound,
} from 'lucide-react';

export const LoginView: React.FC = () => {
  const { login, isOnline } = useApp();

  const [selectedRole, setSelectedRole] = useState<UserRole>('asha');
  const [identifier, setIdentifier] = useState('98765 11223');
  const [pin, setPin] = useState('1234');
  const [loginError, setLoginError] = useState('');

  const handleRoleSelect = (role: UserRole) => {
    setSelectedRole(role);
    setLoginError('');
    if (role === 'asha') {
      setIdentifier('98765 11223');
      setPin('1234');
    } else if (role === 'doctor') {
      setIdentifier('94150 99887');
      setPin('1234');
    } else {
      setIdentifier('98765 43210');
      setPin('1234');
    }
  };

  const handleFormLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!identifier.trim()) {
      setLoginError('Please enter your Registered Mobile Number or ID.');
      return;
    }
    if (!pin || pin.length < 4) {
      setLoginError('Please enter your 4-digit security PIN (Demo PIN is 1234).');
      return;
    }

    login(selectedRole);
  };

  const handleQuickDemoLogin = (role: UserRole) => {
    login(role);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-teal-950 to-slate-900 text-slate-100 flex flex-col justify-center items-center p-4 sm:p-6 font-sans">
      <div className="max-w-4xl w-full space-y-6">
        {/* Brand Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full bg-teal-800/50 border border-teal-600/40 text-teal-300 text-xs font-bold shadow-md">
            <HeartPulse className="w-4 h-4 text-teal-400 animate-pulse" />
            <span>SwasthyaSetu Rural Telemedicine Ecosystem</span>
            <span className="w-1.5 h-1.5 rounded-full bg-teal-400" />
            <span>{isOnline ? 'Online Ready' : 'Offline Vault Active'}</span>
          </div>

          <h1 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
            SwasthyaSetu <span className="text-teal-400 font-normal text-2xl sm:text-3xl">Portal Login</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 max-w-lg mx-auto">
            Offline-first role-based access for Community Health Workers, Medical Officers, and Rural Patients.
          </p>
        </div>

        {/* Main Card Container */}
        <div className="bg-white text-slate-800 rounded-3xl shadow-2xl border border-slate-200 overflow-hidden grid grid-cols-1 lg:grid-cols-12">
          {/* Left Column: Form & Role Selection (7 cols) */}
          <div className="lg:col-span-7 p-6 sm:p-8 space-y-6">
            <div>
              <h2 className="text-xl font-extrabold text-slate-900 tracking-tight">
                Secure Account Sign-In
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Select your designated role or use the quick demo credentials.
              </p>
            </div>

            {/* Role Tabs */}
            <div className="grid grid-cols-3 gap-2 p-1.5 bg-slate-100 rounded-2xl border border-slate-200 text-xs font-bold">
              <button
                type="button"
                onClick={() => handleRoleSelect('asha')}
                className={`py-2.5 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                  selectedRole === 'asha'
                    ? 'bg-teal-700 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                }`}
              >
                <UserCheck className="w-4 h-4" />
                <span>ASHA</span>
              </button>

              <button
                type="button"
                onClick={() => handleRoleSelect('doctor')}
                className={`py-2.5 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                  selectedRole === 'doctor'
                    ? 'bg-teal-700 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                }`}
              >
                <Stethoscope className="w-4 h-4" />
                <span>Doctor</span>
              </button>

              <button
                type="button"
                onClick={() => handleRoleSelect('patient')}
                className={`py-2.5 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                  selectedRole === 'patient'
                    ? 'bg-teal-700 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                }`}
              >
                <Users className="w-4 h-4" />
                <span>Patient</span>
              </button>
            </div>

            {/* Login Form */}
            <form onSubmit={handleFormLogin} className="space-y-4">
              {loginError && (
                <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-semibold">
                  {loginError}
                </div>
              )}

              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-700">
                  {selectedRole === 'asha'
                    ? 'Registered Mobile or ASHA ID'
                    : selectedRole === 'doctor'
                    ? 'Medical License No. or Registered Mobile'
                    : 'ABHA Health ID or Mobile Number'}
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type="text"
                    value={identifier}
                    onChange={(e) => setIdentifier(e.target.value)}
                    placeholder="e.g. 98765 11223"
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-medium focus:bg-white focus:ring-2 focus:ring-teal-600 focus:border-teal-600"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-700">4-Digit Security PIN</label>
                  <span className="text-[11px] text-teal-700 font-semibold">Demo PIN: 1234</span>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type="password"
                    maxLength={6}
                    value={pin}
                    onChange={(e) => setPin(e.target.value)}
                    placeholder="Enter 4-digit PIN"
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-mono tracking-widest focus:bg-white focus:ring-2 focus:ring-teal-600 focus:border-teal-600"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-teal-700 hover:bg-teal-800 text-white font-extrabold text-sm rounded-xl shadow-md transition-all flex items-center justify-center gap-2 active:scale-98 cursor-pointer mt-2"
              >
                <span>Login as {selectedRole === 'asha' ? 'ASHA Worker' : selectedRole === 'doctor' ? 'Medical Officer' : 'Patient'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>

            <div className="flex items-center gap-2 text-xs text-slate-400 pt-2 border-t border-slate-100">
              <ShieldCheck className="w-4 h-4 text-teal-600 shrink-0" />
              <span>Offline Token Validation • Secured by ABHA & DISHA Guidelines</span>
            </div>
          </div>

          {/* Right Column: 1-Click Demo Credentials (5 cols) */}
          <div className="lg:col-span-5 bg-slate-50 p-6 sm:p-8 border-t lg:border-t-0 lg:border-l border-slate-200 flex flex-col justify-between space-y-6">
            <div className="space-y-3">
              <div className="flex items-center gap-1.5 text-xs font-black uppercase tracking-wider text-teal-800">
                <Sparkles className="w-4 h-4 text-teal-600" />
                <span>1-Click Demo Logins</span>
              </div>
              <p className="text-xs text-slate-500">
                Instantly explore the app in any role without typing:
              </p>

              {/* Demo Card: ASHA */}
              <div
                onClick={() => handleQuickDemoLogin('asha')}
                className="p-3.5 bg-white hover:bg-teal-50/60 rounded-2xl border border-slate-200 hover:border-teal-400 shadow-xs transition-all cursor-pointer space-y-1.5 group select-none"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 font-black text-sm text-slate-900 group-hover:text-teal-900">
                    <UserCheck className="w-4 h-4 text-teal-700" />
                    <span>Sunita Devi</span>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase bg-teal-100 text-teal-800">
                    ASHA Role
                  </span>
                </div>
                <p className="text-[11px] text-slate-500">
                  ID: <code className="font-mono text-teal-800">ASHA-UP-8842</code> • Sub-Centre Rampur
                </p>
                <div className="text-[11px] text-teal-700 font-bold flex items-center justify-between pt-1 border-t border-slate-100">
                  <span>Mobile: 98765 11223 • PIN: 1234</span>
                  <span className="group-hover:translate-x-1 transition-transform">Enter →</span>
                </div>
              </div>

              {/* Demo Card: Doctor */}
              <div
                onClick={() => handleQuickDemoLogin('doctor')}
                className="p-3.5 bg-white hover:bg-teal-50/60 rounded-2xl border border-slate-200 hover:border-teal-400 shadow-xs transition-all cursor-pointer space-y-1.5 group select-none"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 font-black text-sm text-slate-900 group-hover:text-teal-900">
                    <Stethoscope className="w-4 h-4 text-teal-700" />
                    <span>Dr. Anand Verma</span>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase bg-teal-100 text-teal-800">
                    Doctor Role
                  </span>
                </div>
                <p className="text-[11px] text-slate-500">
                  MCI: <code className="font-mono text-teal-800">MCI-2015-88319</code> • Sitapur District Hospital
                </p>
                <div className="text-[11px] text-teal-700 font-bold flex items-center justify-between pt-1 border-t border-slate-100">
                  <span>Mobile: 94150 99887 • PIN: 1234</span>
                  <span className="group-hover:translate-x-1 transition-transform">Enter →</span>
                </div>
              </div>

              {/* Demo Card: Patient */}
              <div
                onClick={() => handleQuickDemoLogin('patient')}
                className="p-3.5 bg-white hover:bg-teal-50/60 rounded-2xl border border-slate-200 hover:border-teal-400 shadow-xs transition-all cursor-pointer space-y-1.5 group select-none"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 font-black text-sm text-slate-900 group-hover:text-teal-900">
                    <Users className="w-4 h-4 text-teal-700" />
                    <span>Rajesh Kumar</span>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase bg-teal-100 text-teal-800">
                    Patient Role
                  </span>
                </div>
                <p className="text-[11px] text-slate-500">
                  ABHA: <code className="font-mono text-teal-800">91-4820-9182-3011</code> • Rampur Village
                </p>
                <div className="text-[11px] text-teal-700 font-bold flex items-center justify-between pt-1 border-t border-slate-100">
                  <span>Mobile: 98765 43210 • PIN: 1234</span>
                  <span className="group-hover:translate-x-1 transition-transform">Enter →</span>
                </div>
              </div>
            </div>

            {/* Offline Vault Info */}
            <div className="bg-teal-900/10 p-3 rounded-xl border border-teal-200/60 text-xs text-teal-950 flex items-center gap-2">
              <KeyRound className="w-4 h-4 text-teal-700 shrink-0" />
              <span>Offline credentials cached in secure local vault. No network needed to log in.</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
