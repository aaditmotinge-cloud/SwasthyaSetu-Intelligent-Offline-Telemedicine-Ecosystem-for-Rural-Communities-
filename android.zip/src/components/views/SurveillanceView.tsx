import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Activity,
  MapPin,
  Send,
} from 'lucide-react';

export const SurveillanceView: React.FC = () => {
  const { surveillanceClusters, addSurveillanceCluster } = useApp();

  const [reportModalOpen, setReportModalOpen] = useState(false);
  const [villageName, setVillageName] = useState('Rampur');
  const [syndromeType, setSyndromeType] = useState('Viral Fever Cluster');
  const [casesCount, setCasesCount] = useState<number | ''>(5);

  const handleReportSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!villageName || !syndromeType || !casesCount) return;

    addSurveillanceCluster({
      village: villageName,
      syndrome: syndromeType,
      casesCount: Number(casesCount),
      status: 'flagged',
      lastReported: new Date().toISOString().split('T')[0],
      riskLevel: Number(casesCount) >= 5 ? 'high' : 'medium',
    });

    setReportModalOpen(false);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="bg-gradient-to-r from-slate-900 via-teal-950 to-slate-900 rounded-2xl p-6 text-white shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-teal-800/60 rounded-full text-xs font-semibold text-teal-200 border border-teal-700/50">
            <Activity className="w-3.5 h-3.5" />
            <span>IDSP Public Health Surveillance</span>
          </div>
          <h2 className="text-2xl font-extrabold tracking-tight mt-1">
            Community Disease Cluster & Outbreak Tracker
          </h2>
          <p className="text-xs text-slate-300 max-w-2xl mt-1">
            Monitors early symptom clusters across Panchayats. Privacy-conscious aggregated statistics for ASHA field workers and District Health Officers.
          </p>
        </div>

        <button
          onClick={() => setReportModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs sm:text-sm rounded-xl shadow-lg transition-transform active:scale-95 shrink-0"
        >
          <Send className="w-4 h-4" />
          <span>Report Unusual Cluster</span>
        </button>
      </div>

      {/* Cluster Monitoring Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {surveillanceClusters.map((c) => {
          const isHigh = c.riskLevel === 'high';
          const isMedium = c.riskLevel === 'medium';

          return (
            <div
              key={c.id}
              className={`bg-white rounded-2xl border p-5 shadow-xs space-y-3 transition-all ${
                isHigh
                  ? 'border-rose-300 ring-2 ring-rose-500/10'
                  : isMedium
                  ? 'border-amber-300'
                  : 'border-slate-200'
              }`}
            >
              <div className="flex items-start justify-between">
                <div>
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                      isHigh
                        ? 'bg-rose-100 text-rose-900'
                        : isMedium
                        ? 'bg-amber-100 text-amber-900'
                        : 'bg-emerald-100 text-emerald-900'
                    }`}
                  >
                    {c.riskLevel} RISK CLUSTER
                  </span>
                  <h3 className="font-extrabold text-base text-slate-900 mt-1">{c.syndrome}</h3>
                  <p className="text-xs text-slate-500 flex items-center gap-1 mt-0.5">
                    <MapPin className="w-3.5 h-3.5 text-teal-600" />
                    <span>Village: <strong>{c.village}</strong></span>
                  </p>
                </div>

                <div className="text-right">
                  <span className="text-2xl font-black text-slate-900 block">{c.casesCount}</span>
                  <span className="text-[10px] font-bold text-slate-500 uppercase block">Reported Cases</span>
                </div>
              </div>

              <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 flex items-center justify-between text-xs">
                <span className="text-slate-600">Last Updated: {c.lastReported}</span>
                <span className="font-bold text-teal-800 uppercase tracking-wide text-[10px]">
                  Status: {c.status}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* REPORT OUTBREAK MODAL */}
      {reportModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-white rounded-2xl p-6 max-w-lg w-full shadow-2xl border border-slate-200 space-y-4">
            <h3 className="font-extrabold text-lg text-slate-900 border-b border-slate-100 pb-2">
              Report Community Symptom Cluster
            </h3>

            <form onSubmit={handleReportSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Village / Panchayat</label>
                <select
                  value={villageName}
                  onChange={(e) => setVillageName(e.target.value)}
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm font-medium"
                >
                  <option value="Rampur">Rampur Village</option>
                  <option value="Kalyanpur">Kalyanpur Village</option>
                  <option value="Belpur">Belpur Village</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Observed Syndrome / Pattern</label>
                <input
                  type="text"
                  placeholder="e.g. High Grade Fever Cluster with Rash"
                  value={syndromeType}
                  onChange={(e) => setSyndromeType(e.target.value)}
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Approximate Affected Persons</label>
                <input
                  type="number"
                  placeholder="5"
                  value={casesCount}
                  onChange={(e) => setCasesCount(e.target.value ? Number(e.target.value) : '')}
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm"
                />
              </div>

              <div className="bg-amber-50 p-3 rounded-xl border border-amber-200 text-xs text-amber-950">
                <strong>Privacy Policy Notice:</strong> Only aggregated village counts are reported to public health officers. Individual patient identities are protected.
              </div>

              <div className="flex gap-3 pt-2 justify-end">
                <button
                  type="button"
                  onClick={() => setReportModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-xl shadow-xs"
                >
                  Transmit Report to District Officer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
