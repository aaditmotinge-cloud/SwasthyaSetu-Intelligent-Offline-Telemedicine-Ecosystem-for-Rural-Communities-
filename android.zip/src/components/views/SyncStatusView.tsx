import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  RefreshCw,
  Wifi,
  WifiOff,
  CheckCircle2,
  HardDrive,
  Download,
  Trash2,
  Clock,
  ShieldCheck,
} from 'lucide-react';

export const SyncStatusView: React.FC = () => {
  const {
    isOnline,
    setIsOnline,
    syncQueue,
    patients,
    consultations,
    performSync,
    clearOfflineStorage,
    addToast,
  } = useApp();

  const pendingCount = syncQueue.length;

  const handleExportBackup = () => {
    const data = {
      exportedAt: new Date().toISOString(),
      system: 'SwasthyaSetu Offline Telemedicine',
      patients,
      consultations,
      syncQueue,
    };
    const jsonStr = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `swasthya_setu_backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    addToast('success', 'Offline database exported as JSON backup file.');
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Explicit Mockup & Demonstration Callout Banner */}
      <div className="bg-teal-50 border border-teal-200 rounded-2xl p-5 text-teal-950 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2 font-extrabold text-sm text-teal-900">
            <ShieldCheck className="w-5 h-5 text-teal-700" />
            <span>UI Demonstration Notice — Stage 1 Frontend Foundation</span>
          </div>
          <p className="text-xs text-teal-800 leading-relaxed max-w-2xl">
            This screen demonstrates the <strong>Offline-First Synchronization Engine</strong>. Records created while offline are securely queued in browser LocalStorage. Triggering "Force Manual Sync" simulates uploading queued records to the District Health Cloud.
          </p>
        </div>

        {/* Connectivity Simulator Switch */}
        <button
          onClick={() => setIsOnline((prev) => !prev)}
          className={`px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 shrink-0 transition-all ${
            isOnline
              ? 'bg-teal-700 text-white hover:bg-teal-800'
              : 'bg-amber-500 text-amber-950 hover:bg-amber-600 animate-pulse'
          }`}
        >
          {isOnline ? <Wifi className="w-4 h-4" /> : <WifiOff className="w-4 h-4" />}
          <span>Simulate: {isOnline ? 'Network Online' : 'Network Offline'}</span>
        </button>
      </div>

      {/* Hero Sync Status Header Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Status Card 1 */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex items-center gap-4">
          <div
            className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${
              isOnline ? 'bg-teal-100 text-teal-700' : 'bg-amber-100 text-amber-700'
            }`}
          >
            {isOnline ? <Wifi className="w-6 h-6" /> : <WifiOff className="w-6 h-6" />}
          </div>
          <div>
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
              Network Status
            </span>
            <h3 className="text-lg font-extrabold text-slate-900">
              {isOnline ? 'Online 4G Connected' : 'Offline Vault Active'}
            </h3>
            <p className="text-xs text-slate-500">
              {isOnline ? 'Ready for auto background sync' : 'Saving all records to local storage'}
            </p>
          </div>
        </div>

        {/* Status Card 2 */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
              Pending Sync Queue
            </span>
            <h3 className="text-2xl font-extrabold text-slate-900">{pendingCount} Items</h3>
            <p className="text-xs text-slate-500">Records waiting for cloud upload</p>
          </div>
          <button
            onClick={performSync}
            disabled={pendingCount === 0}
            className={`p-3 rounded-xl font-bold text-xs flex items-center justify-center transition-colors ${
              pendingCount > 0
                ? 'bg-amber-500 hover:bg-amber-600 text-amber-950 shadow-md cursor-pointer'
                : 'bg-slate-100 text-slate-400 cursor-not-allowed'
            }`}
            title="Manual Sync"
          >
            <RefreshCw className={`w-5 h-5 ${pendingCount > 0 ? 'animate-spin-slow' : ''}`} />
          </button>
        </div>

        {/* Status Card 3 */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
            <HardDrive className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
              Offline Vault Capacity
            </span>
            <h3 className="text-lg font-extrabold text-slate-900">1.4 MB / 50 MB</h3>
            <p className="text-xs text-slate-500">HTML5 LocalStorage active</p>
          </div>
        </div>
      </div>

      {/* Main Grid: Sync Queue Table & Offline Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column (2 Cols): Pending Sync Items */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-5 border-b border-slate-200 flex items-center justify-between">
            <div>
              <h3 className="font-extrabold text-lg text-slate-900">Pending Sync Records</h3>
              <p className="text-xs text-slate-500">Queued local changes waiting for upload</p>
            </div>
            <button
              onClick={performSync}
              className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-2"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Force Sync Now</span>
            </button>
          </div>

          <div className="divide-y divide-slate-100">
            {syncQueue.map((item) => (
              <div key={item.id} className="p-4 flex items-center justify-between hover:bg-slate-50">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center font-bold text-xs shrink-0">
                    <Clock className="w-5 h-5 text-amber-700" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-slate-900">{item.title}</h4>
                    <p className="text-xs text-slate-500">{item.details}</p>
                    <span className="text-[10px] font-mono text-slate-400">{item.timestamp}</span>
                  </div>
                </div>

                <span className="px-2.5 py-1 bg-amber-100 text-amber-900 font-extrabold text-[11px] rounded-full">
                  Pending Upload
                </span>
              </div>
            ))}

            {syncQueue.length === 0 && (
              <div className="p-12 text-center text-slate-500 space-y-2">
                <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto" />
                <h4 className="font-bold text-slate-800 text-sm">All local records are synchronized!</h4>
                <p className="text-xs">No pending items in offline upload queue.</p>
              </div>
            )}
          </div>
        </div>

        {/* Right Column (1 Col): Offline Database Controls */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-5">
          <h3 className="font-extrabold text-base text-slate-900 border-b border-slate-100 pb-3">
            Offline Vault Controls
          </h3>

          <div className="space-y-3">
            <button
              onClick={handleExportBackup}
              className="w-full p-3 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl text-left flex items-center gap-3 transition-colors"
            >
              <Download className="w-5 h-5 text-teal-600 shrink-0" />
              <div>
                <span className="font-bold text-xs text-slate-900 block">Export Offline DB (.JSON)</span>
                <span className="text-[11px] text-slate-500 block">Download local patient records backup</span>
              </div>
            </button>

            <button
              onClick={clearOfflineStorage}
              className="w-full p-3 bg-rose-50/60 hover:bg-rose-100/80 border border-rose-200 rounded-xl text-left flex items-center gap-3 transition-colors"
            >
              <Trash2 className="w-5 h-5 text-rose-600 shrink-0" />
              <div>
                <span className="font-bold text-xs text-rose-950 block">Reset Demo Local Storage</span>
                <span className="text-[11px] text-rose-800 block">Restore initial synthetic dataset</span>
              </div>
            </button>
          </div>

          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2 text-xs text-slate-600">
            <span className="font-bold text-slate-800 block">Sync Architecture Summary:</span>
            <ul className="list-disc pl-4 space-y-1 text-[11px]">
              <li><strong>Local Storage Vault:</strong> Instant zero-latency CRUD operations offline.</li>
              <li><strong>Conflict Resolution:</strong> Last-Write-Wins (LWW) timestamp strategy.</li>
              <li><strong>Bandwidth Saver:</strong> Gzip JSON payloads for 2G cellular networks.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
