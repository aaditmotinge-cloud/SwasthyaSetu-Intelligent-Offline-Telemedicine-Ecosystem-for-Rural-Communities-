import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import type { AppLanguage } from '../../types';
import {
  UserCheck,
  Stethoscope,
  Users,
  Globe,
  Sun,
  Info,
  LogOut,
  ShieldCheck,
} from 'lucide-react';

export const SettingsView: React.FC = () => {
  const {
    currentUser,
    patients,
    language,
    setLanguage,
    logout,
    addToast,
  } = useApp();

  const [highContrastMode, setHighContrastMode] = useState(false);

  const myPatient =
    patients.find((p) => p.id === currentUser.associatedPatientId) || patients[0];

  const handleLanguageChange = (lang: AppLanguage) => {
    setLanguage(lang);
    addToast(
      'success',
      `App language updated to ${
        lang === 'hi' ? 'हिंदी (Hindi)' : lang === 'mr' ? 'मराठी (Marathi)' : 'English'
      }.`
    );
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 tracking-tight">
            Account & System Settings
          </h2>
          <p className="text-xs text-slate-500">
            View active user credentials, regional language preferences, and offline vault settings.
          </p>
        </div>

        <button
          type="button"
          onClick={logout}
          className="flex items-center gap-2 px-4 py-2 bg-rose-50 hover:bg-rose-100 text-rose-800 font-extrabold text-xs rounded-xl border border-rose-200 shadow-xs transition-colors shrink-0 cursor-pointer"
        >
          <LogOut className="w-4 h-4 text-rose-600" />
          <span>Sign Out / Switch Account</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Dynamic User Profile Card Based on Active Role */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="flex items-center gap-3 border-b border-slate-100 pb-3">
            <div className="w-10 h-10 rounded-xl bg-teal-100 text-teal-800 font-extrabold flex items-center justify-center">
              {currentUser.role === 'asha' ? (
                <UserCheck className="w-5 h-5 text-teal-700" />
              ) : currentUser.role === 'doctor' ? (
                <Stethoscope className="w-5 h-5 text-teal-700" />
              ) : (
                <Users className="w-5 h-5 text-teal-700" />
              )}
            </div>
            <div>
              <h3 className="font-extrabold text-base text-slate-900">
                {currentUser.role === 'asha'
                  ? 'ASHA Field Worker Profile'
                  : currentUser.role === 'doctor'
                  ? 'Medical Officer Clinical Profile'
                  : 'Patient Health Dossier Profile'}
              </h3>
              <p className="text-xs text-slate-500">
                {currentUser.role === 'patient'
                  ? 'Authenticated ABHA Citizen Pass'
                  : 'Verified Government Healthcare Credentials'}
              </p>
            </div>
          </div>

          {/* ASHA Role Details */}
          {currentUser.role === 'asha' && (
            <div className="space-y-3 text-xs">
              <div className="flex justify-between py-2 border-b border-slate-100">
                <span className="text-slate-500 font-semibold">Worker Name:</span>
                <span className="font-bold text-slate-900">{currentUser.name}</span>
              </div>
              <div className="flex justify-between py-2 border-b border-slate-100">
                <span className="text-slate-500 font-semibold">Role:</span>
                <span className="font-bold text-slate-900">Accredited Social Health Activist (ASHA)</span>
              </div>
              <div className="flex justify-between py-2 border-b border-slate-100">
                <span className="text-slate-500 font-semibold">ASHA Accreditation ID:</span>
                <span className="font-mono font-bold text-teal-700">ASHA-UP-8842</span>
              </div>
              <div className="flex justify-between py-2 border-b border-slate-100">
                <span className="text-slate-500 font-semibold">Primary Health Facility:</span>
                <span className="font-bold text-slate-900">Primary Health Sub-Centre, Rampur</span>
              </div>
              <div className="flex justify-between py-2">
                <span className="text-slate-500 font-semibold">District / State:</span>
                <span className="font-bold text-slate-900">Sitapur, Uttar Pradesh</span>
              </div>
            </div>
          )}

          {/* Doctor Role Details */}
          {currentUser.role === 'doctor' && (
            <div className="space-y-3 text-xs">
              <div className="flex justify-between py-2 border-b border-slate-100">
                <span className="text-slate-500 font-semibold">Doctor Name:</span>
                <span className="font-bold text-slate-900">{currentUser.name}</span>
              </div>
              <div className="flex justify-between py-2 border-b border-slate-100">
                <span className="text-slate-500 font-semibold">Designation:</span>
                <span className="font-bold text-slate-900">Senior Medical Officer (Internal Medicine)</span>
              </div>
              <div className="flex justify-between py-2 border-b border-slate-100">
                <span className="text-slate-500 font-semibold">MCI License Number:</span>
                <span className="font-mono font-bold text-teal-700">MCI-2015-88319</span>
              </div>
              <div className="flex justify-between py-2 border-b border-slate-100">
                <span className="text-slate-500 font-semibold">Associated Hospital:</span>
                <span className="font-bold text-slate-900">Sitapur District Hospital</span>
              </div>
              <div className="flex justify-between py-2">
                <span className="text-slate-500 font-semibold">Clinical Verification:</span>
                <span className="font-bold text-emerald-700 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  Verified Medical Council of India
                </span>
              </div>
            </div>
          )}

          {/* Patient Role Details */}
          {currentUser.role === 'patient' && (
            <div className="space-y-3 text-xs">
              <div className="flex justify-between py-2 border-b border-slate-100">
                <span className="text-slate-500 font-semibold">Beneficiary Name:</span>
                <span className="font-bold text-slate-900">{myPatient.name}</span>
              </div>
              <div className="flex justify-between py-2 border-b border-slate-100">
                <span className="text-slate-500 font-semibold">ABHA Health ID:</span>
                <span className="font-mono font-bold text-teal-700">{myPatient.abhaId}</span>
              </div>
              <div className="flex justify-between py-2 border-b border-slate-100">
                <span className="text-slate-500 font-semibold">Age & Gender:</span>
                <span className="font-bold text-slate-900">{myPatient.age} Years • {myPatient.gender}</span>
              </div>
              <div className="flex justify-between py-2 border-b border-slate-100">
                <span className="text-slate-500 font-semibold">Blood Group:</span>
                <span className="font-bold text-rose-700">{myPatient.bloodGroup}</span>
              </div>
              <div className="flex justify-between py-2">
                <span className="text-slate-500 font-semibold">Village Panchayat:</span>
                <span className="font-bold text-slate-900">{myPatient.village}</span>
              </div>
            </div>
          )}
        </div>

        {/* Display & Language Preferences */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-5">
          <div className="flex items-center gap-3 border-b border-slate-100 pb-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-100 text-cyan-800 font-extrabold flex items-center justify-center">
              <Globe className="w-5 h-5 text-cyan-700" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-slate-900">Regional Interface & Display</h3>
              <p className="text-xs text-slate-500">Live Language & Outdoor Sunlight Contrast</p>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-extrabold text-slate-700 uppercase tracking-wider mb-2">
                App Language (Live Global Switcher)
              </label>
              <div className="grid grid-cols-3 gap-2.5">
                {[
                  { code: 'en' as AppLanguage, label: 'English' },
                  { code: 'hi' as AppLanguage, label: 'हिंदी (Hindi)' },
                  { code: 'mr' as AppLanguage, label: 'मराठी (Marathi)' },
                ].map((item) => (
                  <button
                    key={item.code}
                    type="button"
                    onClick={() => handleLanguageChange(item.code)}
                    className={`py-2.5 px-3 rounded-xl text-xs font-bold transition-all border cursor-pointer ${
                      language === item.code
                        ? 'bg-teal-700 text-white border-teal-800 shadow-xs'
                        : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-2 border-t border-slate-100">
              <label className="flex items-center justify-between cursor-pointer p-3 bg-slate-50 rounded-xl border border-slate-200">
                <div className="flex items-center gap-3">
                  <Sun className="w-5 h-5 text-amber-500" />
                  <div>
                    <span className="font-bold text-xs text-slate-900 block">High Sunlight Outdoor Mode</span>
                    <span className="text-[11px] text-slate-500 block">Increases screen contrast for field checkups</span>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={highContrastMode}
                  onChange={(e) => {
                    setHighContrastMode(e.target.checked);
                    addToast('info', `High Sunlight Mode ${e.target.checked ? 'Enabled' : 'Disabled'}.`);
                  }}
                  className="w-4 h-4 rounded text-teal-600 focus:ring-teal-500 cursor-pointer"
                />
              </label>
            </div>
          </div>
        </div>
      </div>

      {/* System Technical Specifications */}
      <div className="bg-slate-900 text-slate-300 rounded-2xl p-6 border border-slate-800 space-y-3">
        <div className="flex items-center gap-2 text-teal-400 font-bold text-sm">
          <Info className="w-4 h-4" />
          <span>SwasthyaSetu Application Info & Scope</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs text-slate-400 pt-2 border-t border-slate-800">
          <div>
            <span className="text-slate-500 block">System Version:</span>
            <span className="font-mono text-white font-bold">v1.0.0-Stage1 (Frontend Build)</span>
          </div>
          <div>
            <span className="text-slate-500 block">Architecture:</span>
            <span className="font-medium text-white">React 19 + TypeScript + Tailwind CSS</span>
          </div>
          <div>
            <span className="text-slate-500 block">Offline Storage:</span>
            <span className="font-medium text-white">HTML5 LocalStorage / IndexedDB Protocol</span>
          </div>
        </div>
      </div>
    </div>
  );
};
