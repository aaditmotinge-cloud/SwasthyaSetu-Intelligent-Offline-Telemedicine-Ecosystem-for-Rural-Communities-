import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  AlertTriangle,
  Brain,
  FileCode,
  Sparkles,
  Stethoscope,
  Mic,
  RotateCcw,
  PhoneCall,
  MapPin,
  Calendar,
  Activity,
  Info,
} from 'lucide-react';

export const SymptomAssessmentView: React.FC = () => {
  const { openEmergencyVoice, setActiveTab, addToast, currentUser } = useApp();

  const [selectedAgeGroup, setSelectedAgeGroup] = useState<'child' | 'adult' | 'elderly'>('adult');
  const [feverChecked, setFeverChecked] = useState(false);
  const [coughChecked, setCoughChecked] = useState(false);
  const [breathlessnessChecked, setBreathlessnessChecked] = useState(false);
  const [chestPainChecked, setChestPainChecked] = useState(false);
  const [dizzinessChecked, setDizzinessChecked] = useState(false);
  const [vomitingChecked, setVomitingChecked] = useState(false);

  const [spO2Value, setSpO2Value] = useState<number | ''>('');
  const [bpSystolicValue, setBpSystolicValue] = useState<number | ''>('');

  const [isCalculated, setIsCalculated] = useState(false);

  // Prototype calculation
  const calculateTriageLevel = () => {
    let score = 0;
    if (feverChecked) score += 1;
    if (coughChecked) score += 1;
    if (breathlessnessChecked) score += 3;
    if (chestPainChecked) score += 4;
    if (dizzinessChecked) score += 1;
    if (vomitingChecked) score += 1;

    if (spO2Value !== '' && spO2Value < 92) score += 4;
    else if (spO2Value !== '' && spO2Value < 95) score += 2;

    if (bpSystolicValue !== '' && bpSystolicValue > 160) score += 3;

    if (score >= 4) {
      return {
        level: 'Critical Red Flag (Urgent Referral Required)',
        color: 'bg-rose-50 text-rose-950 border-rose-300',
        badgeColor: 'bg-rose-600 text-white',
        score,
        category: 'critical',
      };
    }
    if (score >= 2) {
      return {
        level: 'Moderate Risk (Monitor Vitals & CHW Follow-up)',
        color: 'bg-amber-50 text-amber-950 border-amber-300',
        badgeColor: 'bg-amber-600 text-white',
        score,
        category: 'moderate',
      };
    }
    return {
      level: 'Low Risk (Routine Symptomatic Care)',
      color: 'bg-emerald-50 text-emerald-950 border-emerald-300',
      badgeColor: 'bg-emerald-600 text-white',
      score,
      category: 'normal',
    };
  };

  const result = calculateTriageLevel();

  // One-click quick load presets for easy interactive testing
  const handleLoadPreset = (type: 'routine' | 'hypertension' | 'emergency') => {
    if (type === 'routine') {
      setSelectedAgeGroup('adult');
      setFeverChecked(true);
      setCoughChecked(true);
      setBreathlessnessChecked(false);
      setChestPainChecked(false);
      setDizzinessChecked(false);
      setVomitingChecked(false);
      setSpO2Value(98);
      setBpSystolicValue(118);
      setIsCalculated(true);
      addToast('info', 'Loaded Routine Cold & Flu preset scenario.');
    } else if (type === 'hypertension') {
      setSelectedAgeGroup('elderly');
      setFeverChecked(false);
      setCoughChecked(false);
      setBreathlessnessChecked(false);
      setChestPainChecked(false);
      setDizzinessChecked(true);
      setVomitingChecked(false);
      setSpO2Value(96);
      setBpSystolicValue(168);
      setIsCalculated(true);
      addToast('warning', 'Loaded Elderly Hypertension Risk preset scenario.');
    } else if (type === 'emergency') {
      setSelectedAgeGroup('adult');
      setFeverChecked(false);
      setCoughChecked(false);
      setBreathlessnessChecked(true);
      setChestPainChecked(true);
      setDizzinessChecked(true);
      setVomitingChecked(false);
      setSpO2Value(88);
      setBpSystolicValue(175);
      setIsCalculated(true);
      addToast('error', 'Loaded Acute Cardiac Emergency (Red Flag) preset scenario.');
    }
  };

  const handleReset = () => {
    setSelectedAgeGroup('adult');
    setFeverChecked(false);
    setCoughChecked(false);
    setBreathlessnessChecked(false);
    setChestPainChecked(false);
    setDizzinessChecked(false);
    setVomitingChecked(false);
    setSpO2Value('');
    setBpSystolicValue('');
    setIsCalculated(false);
    addToast('info', 'Assessment form reset.');
  };

  // Helper for real-time SpO2 health status
  const getSpO2Status = () => {
    if (spO2Value === '') return null;
    if (spO2Value >= 95) {
      return <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">Normal Oxygen (≥95%)</span>;
    }
    if (spO2Value >= 90) {
      return <span className="text-[11px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">Mild Hypoxia (90-94%)</span>;
    }
    return <span className="text-[11px] font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-200 animate-pulse">Critical Hypoxia (&lt;90%)</span>;
  };

  // Helper for real-time BP health status
  const getBpStatus = () => {
    if (bpSystolicValue === '') return null;
    if (bpSystolicValue < 120) {
      return <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">Optimal (&lt;120)</span>;
    }
    if (bpSystolicValue <= 139) {
      return <span className="text-[11px] font-bold text-slate-700 bg-slate-100 px-2 py-0.5 rounded border border-slate-300">Pre-Hypertension (120-139)</span>;
    }
    if (bpSystolicValue <= 159) {
      return <span className="text-[11px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">Stage 1 High BP (140-159)</span>;
    }
    return <span className="text-[11px] font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-200 animate-pulse">Critical High BP (≥160)</span>;
  };

  return (
    <div className="space-y-6 pb-12">
      {/* PROMINENT MANDATORY CLINICAL DISCLAIMER BANNER */}
      <div className="bg-amber-50 rounded-2xl p-4 sm:p-5 border-2 border-amber-300 text-amber-950 shadow-xs space-y-2">
        <div className="flex items-center gap-2.5 text-amber-900 font-extrabold text-sm sm:text-base">
          <AlertTriangle className="w-5 h-5 sm:w-6 sm:h-6 text-amber-600 shrink-0" />
          <span>EDUCATIONAL PROTOTYPE — NOT CLINICALLY VALIDATED</span>
        </div>
        <p className="text-xs text-amber-900 leading-relaxed font-medium">
          This symptom assessment interface is a <strong>frontend demonstration placeholder</strong> only.
          It does not diagnose medical conditions, provide diagnostic algorithms, or substitute for professional clinical judgment.
          Real field deployment requires formal ICMR / CDSCO clinical trial validation and Medical Officer approval.
        </p>
      </div>

      {/* SPEECH-TO-TEXT EMERGENCY ACTION BANNER - Only for Patient Role */}
      {currentUser.role === 'patient' && (
        <div className="bg-gradient-to-r from-rose-900 via-teal-900 to-slate-900 rounded-2xl p-5 text-white shadow-lg flex flex-col sm:flex-row sm:items-center justify-between gap-4 border border-rose-700/40">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 bg-rose-500/30 text-rose-200 rounded-full text-[11px] font-extrabold border border-rose-400/30">
              <span className="w-2 h-2 rounded-full bg-rose-400 animate-ping" />
              <span>Extreme Emergency Voice Assistant</span>
            </div>
            <h3 className="text-lg sm:text-xl font-extrabold tracking-tight">
              Patient in Severe Distress & Cannot Type?
            </h3>
            <p className="text-xs text-slate-200 font-medium max-w-xl">
              Use real-time Speech-to-Text in <strong>Hindi, Marathi, or English</strong>. The triage engine automatically detects red-flag symptoms and triggers 108 ambulance dispatch routing.
            </p>
          </div>

          <button
            type="button"
            onClick={openEmergencyVoice}
            className="flex items-center justify-center gap-2 px-5 py-3 bg-rose-600 hover:bg-rose-700 text-white font-black text-xs sm:text-sm rounded-xl shadow-lg transition-transform active:scale-95 shrink-0"
          >
            <Mic className="w-5 h-5 animate-pulse" />
            <span>Launch Emergency Voice SOS</span>
          </button>
        </div>
      )}

      {/* Interactive Quick-Load Presets Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-xs font-extrabold text-slate-700">
          <Activity className="w-4 h-4 text-teal-600" />
          <span>Quick Interactive Test Scenarios:</span>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => handleLoadPreset('routine')}
            className="px-3 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-xs font-bold transition-colors"
          >
            🟢 Low Risk (Flu)
          </button>
          <button
            type="button"
            onClick={() => handleLoadPreset('hypertension')}
            className="px-3 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 text-xs font-bold transition-colors"
          >
            🟡 Moderate Risk (High BP)
          </button>
          <button
            type="button"
            onClick={() => handleLoadPreset('emergency')}
            className="px-3 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-900 border border-rose-300 text-xs font-bold transition-colors"
          >
            🔴 Critical (Cardiac Red Flag)
          </button>
          <button
            type="button"
            onClick={handleReset}
            className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 border border-slate-200 text-xs font-bold transition-colors flex items-center gap-1"
            title="Reset form"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset</span>
          </button>
        </div>
      </div>

      {/* Main Module Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column (2 Cols): Interactive Inputs */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-6">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <div className="flex items-center gap-2 text-teal-800 font-extrabold text-lg">
                <Brain className="w-5 h-5 text-teal-600" />
                <h2>Field Symptom Input Simulator</h2>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Record observed clinical symptoms or vitals to calculate prototype risk stratification.
              </p>
            </div>

            {currentUser.role === 'patient' && (
              <button
                type="button"
                onClick={openEmergencyVoice}
                className="text-xs text-rose-700 hover:text-rose-800 font-bold flex items-center gap-1 bg-rose-50 px-2.5 py-1 rounded-lg border border-rose-200 cursor-pointer"
              >
                <Mic className="w-3.5 h-3.5" />
                <span>Voice Input</span>
              </button>
            )}
          </div>

          {/* Age Group Selector */}
          <div>
            <label className="block text-xs font-extrabold text-slate-700 uppercase tracking-wider mb-2">
              1. Patient Age Demographic
            </label>
            <div className="grid grid-cols-3 gap-3">
              {(['child', 'adult', 'elderly'] as const).map((group) => (
                <button
                  type="button"
                  key={group}
                  onClick={() => setSelectedAgeGroup(group)}
                  className={`py-2.5 px-3 rounded-xl text-xs font-bold capitalize transition-all border ${
                    selectedAgeGroup === group
                      ? 'bg-teal-700 text-white border-teal-800 shadow-xs'
                      : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                  }`}
                >
                  {group === 'child' ? 'Pediatric (<12y)' : group === 'adult' ? 'Adult (12-60y)' : 'Elderly (>60y)'}
                </button>
              ))}
            </div>
          </div>

          {/* Symptom Checklist */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-xs font-extrabold text-slate-700 uppercase tracking-wider">
                2. Reported Physical Symptoms
              </label>
              <span className="text-[11px] text-slate-400">Select all that apply</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <label className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200 cursor-pointer hover:bg-slate-100 text-xs font-semibold transition-colors">
                <input
                  type="checkbox"
                  checked={feverChecked}
                  onChange={(e) => setFeverChecked(e.target.checked)}
                  className="rounded text-teal-600 focus:ring-teal-500 w-4 h-4 cursor-pointer"
                />
                <span>High Grade Fever</span>
              </label>

              <label className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200 cursor-pointer hover:bg-slate-100 text-xs font-semibold transition-colors">
                <input
                  type="checkbox"
                  checked={coughChecked}
                  onChange={(e) => setCoughChecked(e.target.checked)}
                  className="rounded text-teal-600 focus:ring-teal-500 w-4 h-4 cursor-pointer"
                />
                <span>Persistent Cough</span>
              </label>

              <label className="flex items-center gap-3 p-3 bg-rose-50/60 rounded-xl border border-rose-200 cursor-pointer hover:bg-rose-100 text-xs font-semibold text-rose-900 transition-colors">
                <input
                  type="checkbox"
                  checked={breathlessnessChecked}
                  onChange={(e) => setBreathlessnessChecked(e.target.checked)}
                  className="rounded text-rose-600 focus:ring-rose-500 w-4 h-4 cursor-pointer"
                />
                <span className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
                  Shortness of Breath (Dyspnea)
                </span>
              </label>

              <label className="flex items-center gap-3 p-3 bg-rose-50/60 rounded-xl border border-rose-200 cursor-pointer hover:bg-rose-100 text-xs font-semibold text-rose-900 transition-colors">
                <input
                  type="checkbox"
                  checked={chestPainChecked}
                  onChange={(e) => setChestPainChecked(e.target.checked)}
                  className="rounded text-rose-600 focus:ring-rose-500 w-4 h-4 cursor-pointer"
                />
                <span className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
                  Severe Chest Pain / Pressure
                </span>
              </label>

              <label className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200 cursor-pointer hover:bg-slate-100 text-xs font-semibold transition-colors">
                <input
                  type="checkbox"
                  checked={dizzinessChecked}
                  onChange={(e) => setDizzinessChecked(e.target.checked)}
                  className="rounded text-teal-600 focus:ring-teal-500 w-4 h-4 cursor-pointer"
                />
                <span>Dizziness / Vertigo</span>
              </label>

              <label className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200 cursor-pointer hover:bg-slate-100 text-xs font-semibold transition-colors">
                <input
                  type="checkbox"
                  checked={vomitingChecked}
                  onChange={(e) => setVomitingChecked(e.target.checked)}
                  className="rounded text-teal-600 focus:ring-teal-500 w-4 h-4 cursor-pointer"
                />
                <span>Severe Nausea / Vomiting</span>
              </label>
            </div>
          </div>

          {/* Measured Vitals Inputs with Real-Time Feedback */}
          <div>
            <label className="block text-xs font-extrabold text-slate-700 uppercase tracking-wider mb-2">
              3. Pulse Oximeter & BP Vitals
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs text-slate-600 font-semibold">SpO2 Oxygen Level (%):</label>
                  {getSpO2Status()}
                </div>
                <input
                  type="number"
                  placeholder="e.g. 96"
                  min="50"
                  max="100"
                  value={spO2Value}
                  onChange={(e) => setSpO2Value(e.target.value ? Number(e.target.value) : '')}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-mono focus:bg-white focus:ring-2 focus:ring-teal-600 focus:border-teal-600"
                />
                <span className="text-[11px] text-slate-400 block">Normal range is 95% - 100%</span>
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs text-slate-600 font-semibold">Systolic BP (mmHg):</label>
                  {getBpStatus()}
                </div>
                <input
                  type="number"
                  placeholder="e.g. 120"
                  min="60"
                  max="260"
                  value={bpSystolicValue}
                  onChange={(e) => setBpSystolicValue(e.target.value ? Number(e.target.value) : '')}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-mono focus:bg-white focus:ring-2 focus:ring-teal-600 focus:border-teal-600"
                />
                <span className="text-[11px] text-slate-400 block">Normal range is &lt;120 mmHg</span>
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setIsCalculated(true)}
            className="w-full py-3 bg-teal-700 hover:bg-teal-800 text-white font-extrabold text-sm rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2 active:scale-98 cursor-pointer"
          >
            <Sparkles className="w-4 h-4" />
            <span>Generate Prototype Risk Stratification</span>
          </button>
        </div>

        {/* Right Column (1 Col): Result Placeholder Box */}
        <div className="space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
            <h3 className="font-extrabold text-base text-slate-900 border-b border-slate-100 pb-3 flex items-center gap-2">
              <Activity className="w-4 h-4 text-teal-600" />
              <span>Prototype Triage Matrix Output</span>
            </h3>

            {isCalculated ? (
              <div className="space-y-4 animate-fade-in">
                <div className={`p-4 rounded-xl border ${result.color} space-y-2`}>
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-extrabold uppercase tracking-widest block opacity-75">
                      Calculated Stratification
                    </span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase ${result.badgeColor}`}>
                      {result.category.toUpperCase()}
                    </span>
                  </div>

                  <h4 className="font-extrabold text-base leading-snug">{result.level}</h4>
                  <p className="text-xs font-semibold opacity-90">Demo triage score: {result.score} points</p>
                </div>

                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2 text-xs text-slate-700">
                  <span className="font-extrabold text-slate-900 block flex items-center gap-1.5">
                    <Info className="w-3.5 h-3.5 text-teal-700" />
                    Recommended CHW Protocol:
                  </span>
                  <ul className="list-disc pl-4 space-y-1.5 leading-relaxed">
                    <li>Log full consultation entry in Teleconsultation Ledger.</li>
                    <li>
                      {result.score >= 4
                        ? 'Flag for immediate Emergency Hospital Routing and 108 Ambulance Dispatch.'
                        : 'Provide standard symptomatic relief & schedule follow-up in 48 hours.'}
                    </li>
                    <li>Ensure SpO2 pulse oximeter re-check every 15 minutes if breathlessness reported.</li>
                  </ul>
                </div>

                {/* Direct Emergency Action Buttons if High Risk */}
                {result.category === 'critical' && (
                  <div className="space-y-2 pt-2 border-t border-slate-100">
                    <span className="text-[11px] font-extrabold text-rose-700 uppercase tracking-wider block">
                      Immediate Emergency Actions:
                    </span>
                    <a
                      href="tel:108"
                      className="flex items-center justify-center gap-2 py-2.5 px-3 bg-rose-600 hover:bg-rose-700 text-white font-extrabold text-xs rounded-xl shadow-xs transition-colors"
                    >
                      <PhoneCall className="w-4 h-4 animate-bounce" />
                      <span>Call 108 Emergency Ambulance</span>
                    </a>
                    <button
                      type="button"
                      onClick={() => setActiveTab('hospitals')}
                      className="w-full flex items-center justify-center gap-2 py-2.5 px-3 bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs rounded-xl shadow-xs transition-colors"
                    >
                      <MapPin className="w-4 h-4 text-rose-400" />
                      <span>Nearest Government Hospital</span>
                    </button>
                  </div>
                )}

                {/* Regular Consultation Booking if Not Critical */}
                {result.category !== 'critical' && (
                  <button
                    type="button"
                    onClick={() => setActiveTab('appointments')}
                    className="w-full flex items-center justify-center gap-2 py-2.5 px-3 bg-teal-700 hover:bg-teal-800 text-white font-extrabold text-xs rounded-xl shadow-xs transition-colors"
                  >
                    <Calendar className="w-4 h-4" />
                    <span>Schedule Tele-Doctor Consultation</span>
                  </button>
                )}
              </div>
            ) : (
              <div className="bg-slate-50 p-8 text-center rounded-xl border border-dashed border-slate-300 text-slate-500 space-y-2">
                <Stethoscope className="w-8 h-8 text-slate-400 mx-auto" />
                <p className="text-xs font-medium">
                  Select symptoms on the left or click a Quick Test Scenario above, then click "Generate Prototype Risk Stratification".
                </p>
              </div>
            )}
          </div>

          {/* Component Validation Status Callout */}
          <div className="bg-slate-900 text-slate-300 p-5 rounded-2xl space-y-2 border border-slate-800">
            <div className="flex items-center gap-2 text-teal-400 font-bold text-xs">
              <FileCode className="w-4 h-4" />
              <span>Development Roadmap Status</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              In Stage 2, this module will integrate edge-inferenced clinical triage models trained on verified rural health datasets, operating 100% offline without cloud connectivity.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
