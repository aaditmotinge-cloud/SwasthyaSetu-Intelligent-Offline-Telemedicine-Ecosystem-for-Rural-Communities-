import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Building2,
  PhoneCall,
  MapPin,
  Ambulance,
  Search,
  Bed,
  WifiOff,
  Mic,
} from 'lucide-react';

export const HospitalsView: React.FC = () => {
  const { hospitals, isOnline, addToast, openEmergencyVoice, currentUser } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [dispatchAlertOpen, setDispatchAlertOpen] = useState(false);
  const [selectedHospital, setSelectedHospital] = useState<string>('');

  const filteredHospitals = hospitals.filter((h) => {
    const matchesSearch =
      h.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      h.address.toLowerCase().includes(searchTerm.toLowerCase()) ||
      h.villageOrCity.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesCategory =
      categoryFilter === 'All' ||
      (categoryFilter === 'government' && h.type === 'government') ||
      (categoryFilter === 'private' && h.type === 'private');

    return matchesSearch && matchesCategory;
  });

  const handleTriggerAmbulance = (hospitalName: string) => {
    setSelectedHospital(hospitalName);
    setDispatchAlertOpen(true);
    addToast('warning', `Connecting to Emergency Ambulance Helpline (108 / 102)...`);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-rose-900 via-rose-800 to-slate-900 rounded-2xl p-6 text-white shadow-xl space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-rose-700/60 rounded-full text-xs font-semibold text-rose-200 border border-rose-600/40">
              <Ambulance className="w-3.5 h-3.5" />
              <span>Sitapur District Emergency Network</span>
            </div>
            <h2 className="text-2xl font-extrabold tracking-tight mt-1">
              Government Hospital & Emergency Locator
            </h2>
            <p className="text-xs text-rose-100/90 max-w-2xl mt-1">
              Prioritizes Government Sub-Centres, PHCs, CHCs, and District Hospitals. Provides offline addresses, emergency hotline numbers, and ambulance dispatch options.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            {currentUser.role === 'patient' && (
              <button
                type="button"
                onClick={openEmergencyVoice}
                className="flex items-center gap-2 px-3.5 py-3 bg-rose-700/80 hover:bg-rose-700 text-white font-extrabold text-xs sm:text-sm rounded-xl border border-rose-500/50 shadow-md transition-all active:scale-95 cursor-pointer"
              >
                <Mic className="w-4 h-4 animate-pulse text-rose-200" />
                <span>Voice SOS</span>
              </button>
            )}
            <button
              onClick={() => handleTriggerAmbulance('Sitapur Emergency Ambulance 108 Service')}
              className="flex items-center gap-2 px-4 py-3 bg-white text-rose-900 hover:bg-rose-50 font-extrabold text-xs sm:text-sm rounded-xl shadow-lg transition-transform active:scale-95"
            >
              <PhoneCall className="w-5 h-5 text-rose-600 animate-bounce" />
              <span>Call 108 Emergency Ambulance</span>
            </button>
          </div>
        </div>

        {!isOnline && (
          <div className="bg-amber-950/80 p-3 rounded-xl border border-amber-700/80 text-xs text-amber-200 flex items-center gap-2">
            <WifiOff className="w-4 h-4 text-amber-400 shrink-0" />
            <span>
              <strong>Offline Mode Active:</strong> Hospital directory, contact numbers, and directions are stored locally in your offline vault.
            </span>
          </div>
        )}
      </div>

      {/* Search and Filters */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="sm:col-span-2 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            placeholder="Search by Hospital Name, PHC/CHC, Village or City..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium focus:bg-white focus:ring-2 focus:ring-rose-500"
          />
        </div>

        <div>
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-800 focus:bg-white focus:ring-2 focus:ring-rose-500"
          >
            <option value="All">All Hospital Types</option>
            <option value="government">Government Hospitals (Prioritized)</option>
            <option value="private">Private Medical Facilities</option>
          </select>
        </div>
      </div>

      {/* Hospital Cards List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredHospitals.map((hosp) => {
          const isGov = hosp.type === 'government';

          return (
            <div
              key={hosp.id}
              className={`bg-white rounded-2xl border p-5 shadow-xs transition-all space-y-4 hover:shadow-md ${
                isGov ? 'border-teal-200/90 border-l-4 border-l-teal-600' : 'border-slate-200'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-extrabold uppercase ${
                        isGov ? 'bg-teal-100 text-teal-900' : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {hosp.category} • {hosp.type.toUpperCase()}
                    </span>
                    <span className="text-xs font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded-full">
                      {hosp.distanceKm} km away
                    </span>
                  </div>
                  <h3 className="font-extrabold text-base text-slate-900 mt-1">{hosp.name}</h3>
                  <p className="text-xs text-slate-500 flex items-center gap-1 mt-0.5">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>{hosp.address}</span>
                  </p>
                </div>

                <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center shrink-0">
                  <Building2 className="w-5 h-5 text-teal-700" />
                </div>
              </div>

              {/* Status Pills */}
              <div className="grid grid-cols-3 gap-2 text-xs bg-slate-50 p-3 rounded-xl border border-slate-100">
                <div>
                  <span className="text-[10px] text-slate-500 block font-semibold">BEDS AVAILABLE</span>
                  <span className="font-bold text-slate-900 flex items-center gap-1">
                    <Bed className="w-3.5 h-3.5 text-teal-600" /> {hosp.bedAvailability} Beds
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 block font-semibold">ICU FACILITY</span>
                  <span className={`font-bold ${hosp.hasICU ? 'text-emerald-700' : 'text-slate-400'}`}>
                    {hosp.hasICU ? 'Available' : 'No ICU'}
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 block font-semibold">OXYGEN SUPPLY</span>
                  <span className={`font-bold ${hosp.hasOxygen ? 'text-emerald-700' : 'text-slate-400'}`}>
                    {hosp.hasOxygen ? '24/7 Oxygen' : 'Limited'}
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex items-center justify-between gap-3">
                <a
                  href={`tel:${hosp.emergencyHotline}`}
                  className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-colors"
                >
                  <PhoneCall className="w-3.5 h-3.5" />
                  <span>Call {hosp.emergencyHotline}</span>
                </a>

                <button
                  onClick={() => handleTriggerAmbulance(hosp.name)}
                  className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl transition-colors flex items-center gap-1.5"
                >
                  <Ambulance className="w-3.5 h-3.5 text-rose-600" />
                  <span>Request Ambulance</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* DISPATCH ALERT MODAL */}
      {dispatchAlertOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full shadow-2xl border border-rose-200 space-y-4">
            <div className="w-12 h-12 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <Ambulance className="w-6 h-6 animate-pulse" />
            </div>

            <div className="text-center space-y-1">
              <h3 className="font-extrabold text-lg text-slate-900">Emergency Ambulance Dispatch</h3>
              <p className="text-xs text-slate-600">
                Initiating emergency helpline routing for <strong>{selectedHospital}</strong>.
              </p>
            </div>

            <div className="bg-rose-50 p-4 rounded-xl border border-rose-200 text-xs text-rose-950 space-y-2">
              <span className="font-bold block text-rose-900">Emergency Action Instructions:</span>
              <ul className="list-disc pl-4 space-y-1 text-[11px]">
                <li>Stay on line with 108 Emergency Dispatch Officer.</li>
                <li>Keep patient in comfortable upright posture.</li>
                <li>Ensure patient ABHA card / ID is ready for paramedics.</li>
              </ul>
            </div>

            <div className="flex gap-3 pt-2">
              <button
                onClick={() => setDispatchAlertOpen(false)}
                className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl"
              >
                Close Notice
              </button>
              <a
                href="tel:108"
                className="w-full py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl text-center shadow-xs flex items-center justify-center gap-1"
              >
                <PhoneCall className="w-4 h-4" />
                <span>Dial 108 Now</span>
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
