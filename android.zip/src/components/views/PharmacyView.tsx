import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Pill,
  CheckCircle2,
  Search,
  BookOpen,
  BellRing,
} from 'lucide-react';

const GENERIC_MEDICINE_DATABASE = [
  { name: 'Paracetamol 500mg', brandNames: 'Crocin, Calpol, Dolo 650', category: 'Analgesic / Antipyretic', usage: 'Fever and mild body aches', precaution: 'Maximum 4000mg/day. Take after food.' },
  { name: 'Amlodipine 5mg', brandNames: 'Amlokind, Stamlo, Ciplavas', category: 'Antihypertensive', usage: 'Blood pressure regulation', precaution: 'Monitor BP regularly. Do not stop abruptly.' },
  { name: 'Metformin 500mg', brandNames: 'Glycomet, Obimet', category: 'Antidiabetic (Biguanide)', usage: 'Type-2 Diabetes blood sugar control', precaution: 'Take with meals to prevent stomach upset.' },
  { name: 'Iron & Folic Acid (IFA)', brandNames: 'Government Jan Aushadhi IFA', category: 'Nutritional Supplement', usage: 'Anemia prevention in pregnancy', precaution: 'May turn stool dark. Take with Vitamin C / lemon water.' },
  { name: 'Oral Rehydration Salts (ORS)', brandNames: 'Electral, ORS WHO Formula', category: 'Electrolyte Replenisher', usage: 'Diarrhea and dehydration', precaution: 'Mix 1 sachet in 1 liter clean drinking water.' },
];

export const PharmacyView: React.FC = () => {
  const { reminders, toggleReminderTaken, addToast } = useApp();

  const [searchTerm, setSearchTerm] = useState('');

  const filteredMeds = GENERIC_MEDICINE_DATABASE.filter(
    (m) =>
      m.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      m.brandNames.toLowerCase().includes(searchTerm.toLowerCase()) ||
      m.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const completedCount = reminders.filter((r) => r.takenToday).length;
  const totalCount = reminders.length;
  const adherencePercent = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 100;

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 tracking-tight">
            Care Continuity & Medication Adherence
          </h2>
          <p className="text-xs text-slate-500">
            Daily medicine reminders, adherence tracking, and Jan Aushadhi generic medicine guidance.
          </p>
        </div>

        <div className="bg-teal-50 px-4 py-2.5 rounded-xl border border-teal-200 flex items-center gap-3 shrink-0">
          <BellRing className="w-5 h-5 text-teal-700" />
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-teal-800 block">
              Today's Adherence Score
            </span>
            <span className="text-base font-black text-teal-900">{adherencePercent}% ({completedCount}/{totalCount} Taken)</span>
          </div>
        </div>
      </div>

      {/* Daily Reminders Checklist */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
        <h3 className="font-extrabold text-base text-slate-900 border-b border-slate-100 pb-2 flex items-center gap-2">
          <Pill className="w-4 h-4 text-teal-600" />
          <span>Daily Dosage Reminders Checklist</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {reminders.map((rem) => (
            <div
              key={rem.id}
              onClick={() => {
                toggleReminderTaken(rem.id);
                addToast(
                  'info',
                  `Marked ${rem.medName} as ${!rem.takenToday ? 'TAKEN' : 'PENDING'}`
                );
              }}
              className={`p-4 rounded-xl border transition-all cursor-pointer space-y-2 select-none ${
                rem.takenToday
                  ? 'bg-emerald-50/80 border-emerald-300 text-emerald-950'
                  : 'bg-amber-50/60 border-amber-300 text-amber-950'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded bg-white border border-slate-200">
                  {rem.time}
                </span>
                <CheckCircle2
                  className={`w-5 h-5 ${rem.takenToday ? 'text-emerald-600 fill-emerald-100' : 'text-slate-300'}`}
                />
              </div>

              <div>
                <h4 className="font-extrabold text-sm text-slate-900">{rem.medName}</h4>
                <p className="text-xs font-medium text-slate-600">Dosage: {rem.dosage}</p>
                <p className="text-[11px] text-slate-500 italic mt-1">{rem.notes}</p>
              </div>

              <div className="text-[10px] font-extrabold uppercase tracking-wide text-slate-500 pt-1">
                Status: {rem.takenToday ? '✓ Dose Completed' : '⏱ Pending Dose'}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Generic Medicine Information Directory */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div>
            <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-cyan-600" />
              <span>Generic Medicine & Jan Aushadhi Guide</span>
            </h3>
            <p className="text-xs text-slate-500">
              Reliable usage, dosage precautions, and active generic salt compositions.
            </p>
          </div>

          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search generic salt, brand name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
            />
          </div>
        </div>

        <div className="divide-y divide-slate-100 space-y-3">
          {filteredMeds.map((med, idx) => (
            <div key={idx} className="pt-3 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <h4 className="font-extrabold text-sm text-slate-900">{med.name}</h4>
                <span className="px-2.5 py-0.5 bg-cyan-100 text-cyan-900 font-bold text-[10px] rounded-md">
                  {med.category}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-slate-700">
                <p>
                  <strong>Equivalent Brands:</strong> {med.brandNames}
                </p>
                <p>
                  <strong>Indication:</strong> {med.usage}
                </p>
              </div>

              <p className="text-slate-600 bg-amber-50/70 p-2.5 rounded-lg border border-amber-200/80 text-[11px]">
                <strong>Precaution:</strong> {med.precaution}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
