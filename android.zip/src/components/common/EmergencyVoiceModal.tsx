import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { analyzeEmergencySpeech, type EmergencySpeechAnalysis } from '../../utils/speechRecognition';
import {
  Mic,
  MicOff,
  PhoneCall,
  MapPin,
  AlertOctagon,
  CheckCircle2,
  X,
  Stethoscope,
  Sparkles,
  RefreshCw,
} from 'lucide-react';

interface EmergencyVoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyToTriage?: (analysis: EmergencySpeechAnalysis) => void;
}

// Simple Web Audio API sound for emergency alert (offline, zero-asset)
const playEmergencyTone = () => {
  try {
    const AudioContextClass =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(880, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(440, ctx.currentTime + 0.3);
    gain.gain.setValueAtTime(0.3, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.3);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.35);
  } catch (e) {
    // Ignore audio context autoplay restrictions
  }
};

export const EmergencyVoiceModal: React.FC<EmergencyVoiceModalProps> = ({
  isOpen,
  onClose,
  onApplyToTriage,
}) => {
  const { language, setActiveTab, addToast } = useApp();

  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [interimText, setInterimText] = useState('');
  const [analysis, setAnalysis] = useState<EmergencySpeechAnalysis | null>(null);
  const [speechSupported, setSpeechSupported] = useState(true);

  // Reference to SpeechRecognition instance
  const recognitionRef = useRef<any>(null);

  const handleAnalyze = (text: string) => {
    if (!text.trim()) return;
    // Analyzes keywords across Hindi, Marathi, and English simultaneously!
    const result = analyzeEmergencySpeech(text, language);
    setAnalysis(result);

    if (result.isEmergency) {
      playEmergencyTone();
      addToast('error', '🚨 RED FLAG DETECTED: Acute emergency symptoms recognized!');
    }
  };

  // Setup SpeechRecognition
  useEffect(() => {
    const windowObj = window as any;
    const SpeechRecognition =
      windowObj.SpeechRecognition || windowObj.webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setSpeechSupported(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;

      // Default to app language or Indian English/Hindi (understands Indian accents & multilingual speech)
      const langCode = language === 'hi' ? 'hi-IN' : language === 'mr' ? 'mr-IN' : 'en-IN';
      recognition.lang = langCode;

      recognition.onstart = () => {
        setIsListening(true);
      };

      recognition.onresult = (event: any) => {
        let currentInterim = '';
        let finalTrans = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTrans += event.results[i][0].transcript + ' ';
          } else {
            currentInterim += event.results[i][0].transcript;
          }
        }

        if (finalTrans) {
          setTranscript((prev) => {
            const updated = (prev + ' ' + finalTrans).trim();
            handleAnalyze(updated);
            return updated;
          });
        }
        setInterimText(currentInterim);
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        if (event.error === 'not-allowed') {
          addToast(
            'warning',
            'Microphone permission blocked. Please use the 1-Tap Emergency phrases below.'
          );
        }
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
    } catch (e) {
      setSpeechSupported(false);
    }

    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (e) {}
      }
    };
  }, [language]);

  // AUTO-START LISTENING IMMEDIATELY WHEN OPENED (Zero clicks required for emergency patients!)
  useEffect(() => {
    if (isOpen && speechSupported && recognitionRef.current) {
      setTranscript('');
      setInterimText('');
      setAnalysis(null);
      try {
        recognitionRef.current.start();
        setIsListening(true);
      } catch (e) {
        // Recognition might already be running
      }
    } else if (!isOpen && recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (e) {}
      setIsListening(false);
    }
  }, [isOpen, speechSupported]);

  const toggleListening = () => {
    if (!speechSupported) {
      addToast(
        'warning',
        'Live microphone speech recognition is not supported in this browser. Please tap the Emergency Phrases below.'
      );
      return;
    }

    if (isListening) {
      try {
        recognitionRef.current?.stop();
      } catch (e) {}
      setIsListening(false);
    } else {
      try {
        setTranscript('');
        setInterimText('');
        setAnalysis(null);
        if (recognitionRef.current) {
          recognitionRef.current.start();
        }
        setIsListening(true);
      } catch (e) {
        console.error('Failed to start speech recognition:', e);
        setIsListening(false);
      }
    }
  };

  const handleSelectQuickPhrase = (phrase: string) => {
    setTranscript(phrase);
    setInterimText('');
    handleAnalyze(phrase);
  };

  const handleRouteToHospitals = () => {
    onClose();
    setActiveTab('hospitals');
    addToast('warning', 'Routing to Emergency Hospitals & 108 Ambulance Dispatch directory...');
  };

  const handleSendToTriage = () => {
    if (analysis && onApplyToTriage) {
      onApplyToTriage(analysis);
    }
    onClose();
    setActiveTab('symptom-assessment');
    addToast('info', 'Voice symptoms populated into Symptom Triage Matrix.');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/85 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full border border-slate-200 shadow-2xl overflow-hidden my-auto animate-scale-up">
        {/* Header Bar */}
        <div className="bg-gradient-to-r from-rose-900 via-rose-800 to-slate-900 text-white p-5 sm:p-6 flex items-start justify-between">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-2 px-2.5 py-0.5 rounded-full bg-rose-500/30 text-rose-200 text-[11px] font-extrabold border border-rose-400/30">
              <span className="w-2 h-2 rounded-full bg-rose-400 animate-ping" />
              <span>Instant Emergency Voice SOS • स्वतः सुरू झाले</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-black tracking-tight flex items-center gap-2">
              <span>Listening Now • आपकी आवाज सुनी जा रही है</span>
            </h3>
            <p className="text-xs text-rose-100/90 font-medium">
              Speak in any language (Hindi, Marathi, or English). No setup or language selection required.
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-rose-200 hover:text-white hover:bg-rose-800/60 rounded-full transition-colors cursor-pointer"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 space-y-5">
          {/* Direct 108 Emergency Banner */}
          <div className="bg-rose-100/70 border-2 border-rose-400 rounded-2xl p-3.5 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <PhoneCall className="w-5 h-5 text-rose-700 shrink-0 animate-bounce" />
              <div>
                <h4 className="font-black text-sm text-rose-950">Too breathless or unable to speak?</h4>
                <p className="text-xs text-rose-900 font-semibold">1-Tap connects directly to National Ambulance 108</p>
              </div>
            </div>
            <a
              href="tel:108"
              className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-black text-xs rounded-xl shadow-md transition-all active:scale-95 shrink-0 flex items-center gap-1.5"
            >
              <PhoneCall className="w-3.5 h-3.5" />
              <span>Call 108</span>
            </a>
          </div>

          {/* Central Active Recording Visualizer */}
          <div className="flex flex-col items-center justify-center p-6 bg-gradient-to-b from-rose-50/50 via-slate-50 to-white rounded-2xl border-2 border-rose-200 text-center space-y-4">
            <div className="relative">
              {/* Pulsing ring animation while listening */}
              {isListening && (
                <>
                  <div className="absolute -inset-4 rounded-full bg-rose-400 opacity-40 animate-ping" />
                  <div className="absolute -inset-8 rounded-full bg-rose-500 opacity-25 animate-pulse" />
                </>
              )}

              <button
                type="button"
                onClick={toggleListening}
                className={`relative z-10 w-24 h-24 sm:w-28 sm:h-28 rounded-full flex flex-col items-center justify-center shadow-xl transition-all transform active:scale-95 cursor-pointer ${
                  isListening
                    ? 'bg-rose-600 hover:bg-rose-700 text-white shadow-rose-300 ring-4 ring-rose-300'
                    : 'bg-slate-700 hover:bg-slate-800 text-white shadow-slate-200'
                }`}
              >
                {isListening ? (
                  <Mic className="w-10 h-10 sm:w-12 sm:h-12 animate-pulse" />
                ) : (
                  <MicOff className="w-10 h-10 sm:w-12 sm:h-12" />
                )}
                <span className="text-[10px] font-extrabold uppercase mt-1 tracking-wider">
                  {isListening ? 'Recording' : 'Tap to Resume'}
                </span>
              </button>
            </div>

            <div className="space-y-1">
              <h4 className="font-black text-base sm:text-lg text-slate-900">
                {isListening ? (
                  <span className="text-rose-700 flex items-center justify-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-600 animate-ping" />
                    Listening now... Tell us what happened
                  </span>
                ) : (
                  'Microphone paused. Tap button above to resume speaking.'
                )}
              </h4>
              <p className="text-xs text-slate-600 font-medium max-w-md">
                Just speak naturally: <em>"सीने में बहुत तेज दर्द है"</em>, <em>"छातीत कळ येत आहे"</em>, or <em>"Patient has severe chest pain and cannot breathe"</em>.
              </p>
            </div>

            {/* Audio Waveform visualization */}
            {isListening && (
              <div className="flex items-center justify-center gap-1.5 h-6">
                {[40, 75, 100, 60, 95, 45, 85, 50, 90, 35].map((height, idx) => (
                  <div
                    key={idx}
                    className="w-1.5 bg-rose-500 rounded-full animate-pulse"
                    style={{
                      height: `${height}%`,
                      animationDelay: `${idx * 0.1}s`,
                    }}
                  />
                ))}
              </div>
            )}
          </div>

          {/* Real-time Transcription Box */}
          <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 space-y-2">
            <div className="flex items-center justify-between text-xs font-bold text-slate-700">
              <span className="flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-rose-600" />
                Transcribed Patient Speech (हिंदी • मराठी • English):
              </span>
              {transcript && (
                <button
                  type="button"
                  onClick={() => {
                    setTranscript('');
                    setInterimText('');
                    setAnalysis(null);
                  }}
                  className="text-slate-400 hover:text-slate-600 flex items-center gap-1 text-[11px] cursor-pointer"
                >
                  <RefreshCw className="w-3 h-3" />
                  Clear
                </button>
              )}
            </div>

            <div className="min-h-16 max-h-28 overflow-y-auto bg-white p-3 rounded-xl border border-slate-200 text-sm leading-relaxed font-semibold text-slate-900">
              {transcript || interimText ? (
                <div>
                  <span>{transcript}</span>
                  {interimText && <span className="text-slate-400 italic font-normal"> {interimText}</span>}
                </div>
              ) : (
                <span className="text-slate-400 italic text-xs font-normal">
                  Say your symptoms... Your words will appear here instantly and will be checked for emergency red flags.
                </span>
              )}
            </div>
          </div>

          {/* Emergency Speech Analysis Result Card */}
          {analysis && (
            <div
              className={`p-5 rounded-2xl border-2 space-y-4 animate-fade-in ${
                analysis.riskLevel === 'critical'
                  ? 'bg-rose-50 border-rose-500 text-rose-950'
                  : analysis.riskLevel === 'moderate'
                  ? 'bg-amber-50 border-amber-400 text-amber-950'
                  : 'bg-emerald-50 border-emerald-400 text-emerald-950'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  {analysis.riskLevel === 'critical' ? (
                    <AlertOctagon className="w-7 h-7 text-rose-600 shrink-0 animate-bounce" />
                  ) : (
                    <CheckCircle2 className="w-6 h-6 text-teal-600 shrink-0" />
                  )}
                  <div>
                    <h4 className="font-black text-base sm:text-lg">
                      {analysis.riskLevel === 'critical'
                        ? '🚨 CRITICAL RED FLAG DETECTED'
                        : analysis.riskLevel === 'moderate'
                        ? '⚠️ URGENT ATTENTION REQUIRED'
                        : '✅ ROUTINE SYMPTOMS IDENTIFIED'}
                    </h4>
                    <p className="text-xs font-semibold opacity-90">{analysis.recommendedAction}</p>
                  </div>
                </div>

                <span className="px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-white/90 border border-slate-200">
                  {analysis.riskLevel.toUpperCase()}
                </span>
              </div>

              {/* Matched Keywords */}
              {analysis.matchedKeywords.length > 0 && (
                <div className="flex flex-wrap items-center gap-1.5 pt-1">
                  <span className="text-[11px] font-extrabold">Emergency Triggers Recognized:</span>
                  {analysis.matchedKeywords.map((kw, i) => (
                    <span
                      key={i}
                      className="px-2.5 py-0.5 rounded-lg bg-rose-200 text-rose-900 font-black text-xs"
                    >
                      {kw}
                    </span>
                  ))}
                </div>
              )}

              {/* Action Buttons */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-2">
                <a
                  href="tel:108"
                  className="flex items-center justify-center gap-2 py-3 px-4 bg-rose-600 hover:bg-rose-700 text-white font-black text-xs rounded-xl shadow-md transition-all active:scale-95"
                >
                  <PhoneCall className="w-4 h-4 animate-pulse" />
                  <span>Call 108 Ambulance</span>
                </a>

                <button
                  type="button"
                  onClick={handleRouteToHospitals}
                  className="flex items-center justify-center gap-2 py-3 px-4 bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs rounded-xl shadow-md transition-all active:scale-95 cursor-pointer"
                >
                  <MapPin className="w-4 h-4 text-rose-400" />
                  <span>Nearest Govt Hospital</span>
                </button>

                <button
                  type="button"
                  onClick={handleSendToTriage}
                  className="flex items-center justify-center gap-2 py-3 px-4 bg-teal-700 hover:bg-teal-800 text-white font-extrabold text-xs rounded-xl shadow-md transition-all active:scale-95 cursor-pointer"
                >
                  <Stethoscope className="w-4 h-4" />
                  <span>Send to Triage Form</span>
                </button>
              </div>
            </div>
          )}

          {/* Quick Emergency 1-Tap Emergency Buttons (If cannot speak or mic is blocked) */}
          <div className="space-y-2 pt-1 border-t border-slate-100">
            <span className="text-[11px] font-extrabold text-slate-500 uppercase tracking-wider block">
              Or 1-Tap Common Emergency Situations:
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() =>
                  handleSelectQuickPhrase(
                    'मरीज को सीने में बहुत तेज दर्द है और सांस नहीं आ रही है (Severe chest pain & breathlessness)'
                  )
                }
                className="p-2.5 bg-rose-50 hover:bg-rose-100 text-rose-950 border border-rose-200 rounded-xl text-xs font-bold transition-colors text-left flex items-center gap-2 cursor-pointer"
              >
                <span className="w-2.5 h-2.5 rounded-full bg-rose-600 shrink-0" />
                <div>
                  <div className="font-extrabold">सीने में तेज दर्द व सांस में तकलीफ</div>
                  <div className="text-[11px] text-rose-700 font-normal">Chest Pain / Cardiac Emergency</div>
                </div>
              </button>

              <button
                type="button"
                onClick={() =>
                  handleSelectQuickPhrase(
                    'मरीज अचानक बेहोश हो गया है और कोई प्रतिक्रिया नहीं दे रहा है (Patient unconscious and unresponsive)'
                  )
                }
                className="p-2.5 bg-rose-50 hover:bg-rose-100 text-rose-950 border border-rose-200 rounded-xl text-xs font-bold transition-colors text-left flex items-center gap-2 cursor-pointer"
              >
                <span className="w-2.5 h-2.5 rounded-full bg-rose-600 shrink-0" />
                <div>
                  <div className="font-extrabold">बेहोश मरीज • बेशुद्ध रुग्ण</div>
                  <div className="text-[11px] text-rose-700 font-normal">Unconscious & Collapsed</div>
                </div>
              </button>

              <button
                type="button"
                onClick={() =>
                  handleSelectQuickPhrase(
                    'खेत में जहरीले सांप ने काट लिया है (Poisonous snake bite in village)'
                  )
                }
                className="p-2.5 bg-rose-50 hover:bg-rose-100 text-rose-950 border border-rose-200 rounded-xl text-xs font-bold transition-colors text-left flex items-center gap-2 cursor-pointer"
              >
                <span className="w-2.5 h-2.5 rounded-full bg-rose-600 shrink-0" />
                <div>
                  <div className="font-extrabold">सांप का काटना • साप चावला</div>
                  <div className="text-[11px] text-rose-700 font-normal">Snake Bite Emergency</div>
                </div>
              </button>

              <button
                type="button"
                onClick={() =>
                  handleSelectQuickPhrase(
                    'गंभीर चोट से बहुत खून बह रहा है (Severe accident and heavy bleeding)'
                  )
                }
                className="p-2.5 bg-rose-50 hover:bg-rose-100 text-rose-950 border border-rose-200 rounded-xl text-xs font-bold transition-colors text-left flex items-center gap-2 cursor-pointer"
              >
                <span className="w-2.5 h-2.5 rounded-full bg-rose-600 shrink-0" />
                <div>
                  <div className="font-extrabold">गंभीर रक्तस्त्राव • भारी खून बहना</div>
                  <div className="text-[11px] text-rose-700 font-normal">Severe Trauma / Bleeding</div>
                </div>
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-50 px-6 py-3.5 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <span className="font-medium">SwasthyaSetu Universal Voice Triage • 100% Offline Capable</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold rounded-lg transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
