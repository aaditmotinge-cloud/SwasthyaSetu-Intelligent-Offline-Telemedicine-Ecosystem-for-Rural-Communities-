import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Sidebar } from './components/layout/Sidebar';
import { Header } from './components/layout/Header';
import { MobileNav } from './components/layout/MobileNav';
import { ToastContainer } from './components/common/Toast';
import { EmergencyVoiceModal } from './components/common/EmergencyVoiceModal';
import { LoginView } from './components/views/LoginView';
import { DashboardView } from './components/views/DashboardView';
import { PatientsView } from './components/views/PatientsView';
import { ConsultationsView } from './components/views/ConsultationsView';
import { SymptomAssessmentView } from './components/views/SymptomAssessmentView';
import { HospitalsView } from './components/views/HospitalsView';
import { AppointmentsView } from './components/views/AppointmentsView';
import { PharmacyView } from './components/views/PharmacyView';
import { SurveillanceView } from './components/views/SurveillanceView';
import { SyncStatusView } from './components/views/SyncStatusView';
import { SettingsView } from './components/views/SettingsView';

const MainContent: React.FC = () => {
  const { activeTab } = useApp();

  return (
    <main className="flex-1 p-4 sm:p-8 max-w-7xl w-full mx-auto">
      {activeTab === 'dashboard' && <DashboardView />}
      {activeTab === 'patients' && <PatientsView />}
      {activeTab === 'consultations' && <ConsultationsView />}
      {activeTab === 'symptom-assessment' && <SymptomAssessmentView />}
      {activeTab === 'hospitals' && <HospitalsView />}
      {activeTab === 'appointments' && <AppointmentsView />}
      {activeTab === 'pharmacy' && <PharmacyView />}
      {activeTab === 'surveillance' && <SurveillanceView />}
      {activeTab === 'sync-status' && <SyncStatusView />}
      {activeTab === 'settings' && <SettingsView />}
    </main>
  );
};

const AppModals: React.FC = () => {
  const { isEmergencyVoiceModalOpen, setIsEmergencyVoiceModalOpen } = useApp();
  return (
    <EmergencyVoiceModal
      isOpen={isEmergencyVoiceModalOpen}
      onClose={() => setIsEmergencyVoiceModalOpen(false)}
    />
  );
};

const AppShell: React.FC = () => {
  const { isAuthenticated } = useApp();

  if (!isAuthenticated) {
    return <LoginView />;
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row text-slate-800 font-sans selection:bg-teal-100 selection:text-teal-900">
      {/* Persistent Desktop Sidebar */}
      <Sidebar />

      {/* Mobile Header & Bottom Navigation */}
      <MobileNav />

      {/* Main Workspace Area */}
      <div className="flex-1 flex flex-col min-w-0 min-h-screen">
        {/* Header */}
        <Header />

        {/* Dynamic Screen View */}
        <MainContent />
      </div>

      {/* Global Emergency Voice Modal */}
      <AppModals />
    </div>
  );
};

export function App() {
  return (
    <AppProvider>
      <AppShell />
      {/* Toast Notifications */}
      <ToastContainer />
    </AppProvider>
  );
}

export default App;
