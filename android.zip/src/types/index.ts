export type TriageLevel = 'normal' | 'moderate' | 'critical';
export type SyncStatusType = 'synced' | 'pending' | 'failed';
export type UserRole = 'patient' | 'asha' | 'doctor';
export type AppLanguage = 'en' | 'hi' | 'mr';

export interface Vitals {
  bpSystolic?: number;
  bpDiastolic?: number;
  bloodSugar?: number;
  sugarType?: 'fasting' | 'post_prandial' | 'random';
  pulseRate?: number;
  oxygenSaturation?: number;
  bodyTemp?: number;
  respRate?: number;
}

export interface VitalRecord {
  id: string;
  patientId: string;
  timestamp: string;
  vitals: Vitals;
}

export interface Patient {
  id: string;
  abhaId: string;
  name: string;
  age: number;
  gender: 'Male' | 'Female' | 'Other';
  village: string;
  phone: string;
  bloodGroup: string;
  emergencyContact: string;
  chronicConditions: string[];
  allergies: string[];
  registeredAt: string;
  syncStatus: SyncStatusType;
  lastVisit?: string;
  triageLevel: TriageLevel;
  bloodSugarHistory?: { date: string; value: number; type: string }[];
  bpHistory?: { date: string; sys: number; dia: number }[];
}

export interface User {
  id: string;
  name: string;
  role: UserRole;
  phone: string;
  email?: string;
  verificationCode?: string; // ASHA ID or Doctor Medical License No
  verified: boolean;
  facilityOrVillage: string;
  associatedPatientId?: string; // If role is patient
}

export interface Doctor {
  id: string;
  name: string;
  specialty: string;
  qualification: string;
  licenseNo: string;
  hospital: string;
  experienceYears: number;
  availableDays: string[];
  phone: string;
  rating: number;
}

export interface MedicationItem {
  id: string;
  name: string;
  dosage: string;
  frequency: string; // e.g. "1-0-1 after meal"
  durationDays: number;
  instructions?: string;
}

export interface DigitalPrescription {
  id: string;
  consultationId: string;
  patientId: string;
  patientName: string;
  doctorId: string;
  doctorName: string;
  date: string;
  medications: MedicationItem[];
  precautionsAdvice: string;
  followUpDate?: string;
}

export interface Appointment {
  id: string;
  patientId: string;
  patientName: string;
  doctorId: string;
  doctorName: string;
  specialty: string;
  date: string;
  timeSlot: string;
  status: 'scheduled' | 'completed' | 'cancelled';
  chiefComplaint: string;
}

export interface Consultation {
  id: string;
  patientId: string;
  patientName: string;
  patientAge: number;
  patientVillage: string;
  chwName: string;
  date: string;
  chiefComplaint: string;
  symptoms: string[];
  vitals: Vitals;
  notes: string;
  prescriptionAdvice: string;
  followUpDate?: string;
  teleconsultationRequested: boolean;
  syncStatus: SyncStatusType;
  triageRisk: 'low' | 'moderate' | 'high' | 'critical';
  prescription?: DigitalPrescription;
}

export interface SyncQueueItem {
  id: string;
  type: 'patient' | 'consultation' | 'vitals' | 'appointment' | 'surveillance';
  action: 'REGISTER' | 'RECORD_CONSULTATION' | 'LOG_VITALS' | 'BOOK_APPOINTMENT' | 'REPORT_CLUSTER';
  title: string;
  details: string;
  timestamp: string;
  status: 'pending' | 'syncing' | 'synced';
}

export interface CHWProfile {
  name: string;
  role: string;
  healthCenter: string;
  villageCluster: string;
  district: string;
  state: string;
  chwId: string;
}

export interface HospitalFacility {
  id: string;
  name: string;
  type: 'government' | 'private';
  category: 'PHC' | 'CHC' | 'District Hospital' | 'Trauma Center' | 'Private Clinic';
  address: string;
  villageOrCity: string;
  distanceKm: number;
  phone: string;
  emergencyHotline: string;
  bedAvailability: number;
  hasICU: boolean;
  hasOxygen: boolean;
}

export interface MedicineReminder {
  id: string;
  patientId: string;
  medName: string;
  dosage: string;
  time: string;
  takenToday: boolean;
  notes: string;
}

export interface SurveillanceCluster {
  id: string;
  village: string;
  syndrome: string; // e.g. "Acute Diarrheal Outbreak", "Viral Fever Cluster"
  casesCount: number;
  status: 'monitoring' | 'flagged' | 'contained';
  lastReported: string;
  riskLevel: 'low' | 'medium' | 'high';
}

export interface ToastMessage {
  id: string;
  type: 'success' | 'warning' | 'info' | 'error';
  message: string;
}
