package org.swasthya.setu;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
