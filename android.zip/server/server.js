/**
 * SwasthyaSetu — Intelligent Offline Telemedicine Ecosystem
 * Backend REST API Server (Node.js ES Module)
 *
 * Runs standalone with native Node.js (zero external dependencies required).
 * Provides REST endpoints for authentication, patients, consultations,
 * offline synchronization, hospitals, appointments, and outbreak surveillance.
 */

import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = process.env.PORT || 5000;
const DB_FILE = path.join(__dirname, 'data', 'db.json');

// Read Database
function readDB() {
  try {
    const raw = fs.readFileSync(DB_FILE, 'utf8');
    return JSON.parse(raw);
  } catch (err) {
    console.error('Error reading db.json:', err);
    return {
      users: [],
      patients: [],
      consultations: [],
      doctors: [],
      hospitals: [],
      appointments: [],
      surveillance: [],
    };
  }
}

// Save Database
function saveDB(data) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf8');
    return true;
  } catch (err) {
    console.error('Error saving db.json:', err);
    return false;
  }
}

// Send JSON response with CORS
function sendJSON(res, statusCode, payload) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  });
  res.end(JSON.stringify(payload));
}

// Request Body Parser helper
function parseBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', (chunk) => {
      body += chunk.toString();
    });
    req.on('end', () => {
      try {
        const parsed = body ? JSON.parse(body) : {};
        resolve(parsed);
      } catch (e) {
        resolve({});
      }
    });
    req.on('error', (err) => reject(err));
  });
}

const server = http.createServer(async (req, res) => {
  const reqUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = reqUrl.pathname;
  const method = req.method;

  // Handle CORS Pre-flight Options
  if (method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    });
    return res.end();
  }

  // --- API ROUTES ---

  // 1. Root & Health Check
  if (pathname === '/' || pathname === '/api/health') {
    return sendJSON(res, 200, {
      status: 'healthy',
      system: 'SwasthyaSetu Rural Telemedicine Backend API',
      version: '1.0.0',
      timestamp: new Date().toISOString(),
      offlineSyncSupported: true,
      endpoints: [
        'POST /api/auth/login',
        'GET  /api/patients',
        'POST /api/patients',
        'GET  /api/consultations',
        'POST /api/consultations',
        'POST /api/sync',
        'GET  /api/hospitals',
        'GET  /api/doctors',
        'GET  /api/appointments',
        'POST /api/appointments',
        'GET  /api/surveillance',
        'POST /api/surveillance',
      ],
    });
  }

  // 2. Authentication Login (POST /api/auth/login)
  if (pathname === '/api/auth/login' && method === 'POST') {
    const body = await parseBody(req);
    const { role, pin } = body;
    const db = readDB();

    const user = db.users.find((u) => u.role === role);
    if (!user) {
      return sendJSON(res, 404, { success: false, message: 'Designated user role not found.' });
    }

    if (pin && pin !== '1234') {
      return sendJSON(res, 401, { success: false, message: 'Invalid 4-digit security PIN. Use 1234.' });
    }

    return sendJSON(res, 200, {
      success: true,
      message: `Authenticated as ${user.name} (${user.role.toUpperCase()})`,
      token: `SWST-${Date.now()}-${Math.random().toString(36).substring(2, 8)}`,
      user: {
        id: user.id,
        name: user.name,
        role: user.role,
        phone: user.phone,
        verificationCode: user.verificationCode,
        facilityOrVillage: user.facilityOrVillage,
        associatedPatientId: user.associatedPatientId,
      },
    });
  }

  // 3. Patients (GET & POST /api/patients)
  if (pathname === '/api/patients') {
    const db = readDB();
    if (method === 'GET') {
      return sendJSON(res, 200, { success: true, count: db.patients.length, data: db.patients });
    }

    if (method === 'POST') {
      const body = await parseBody(req);
      if (!body.name || !body.village) {
        return sendJSON(res, 400, { success: false, message: 'Patient name and village are required.' });
      }

      const id = `PAT-${Math.floor(1000 + Math.random() * 9000)}`;
      const newPatient = {
        ...body,
        id,
        registeredAt: new Date().toISOString().split('T')[0],
        syncStatus: 'synced',
      };

      db.patients.unshift(newPatient);
      saveDB(db);

      return sendJSON(res, 201, { success: true, message: 'Patient registered successfully.', patient: newPatient });
    }
  }

  // 4. Consultations (GET & POST /api/consultations)
  if (pathname === '/api/consultations') {
    const db = readDB();
    if (method === 'GET') {
      const patientId = reqUrl.searchParams.get('patientId');
      const data = patientId
        ? db.consultations.filter((c) => c.patientId === patientId)
        : db.consultations;
      return sendJSON(res, 200, { success: true, count: data.length, data });
    }

    if (method === 'POST') {
      const body = await parseBody(req);
      if (!body.patientId || !body.chiefComplaint) {
        return sendJSON(res, 400, { success: false, message: 'Patient ID and chief complaint are required.' });
      }

      const newConsultation = {
        ...body,
        id: `CNS-${Math.floor(2000 + Math.random() * 8000)}`,
        date: new Date().toISOString().split('T')[0],
        syncStatus: 'synced',
      };

      db.consultations.unshift(newConsultation);
      saveDB(db);

      return sendJSON(res, 201, { success: true, message: 'Consultation recorded.', consultation: newConsultation });
    }
  }

  // 5. Offline Cloud Synchronization Vault (POST /api/sync)
  if (pathname === '/api/sync' && method === 'POST') {
    const body = await parseBody(req);
    const syncItems = Array.isArray(body.items) ? body.items : [];
    const db = readDB();

    console.log(`[Sync Engine] Received ${syncItems.length} queued records from offline field client.`);

    return sendJSON(res, 200, {
      success: true,
      message: `Cloud synchronization successful. Processed ${syncItems.length} offline vault records.`,
      syncedAt: new Date().toISOString(),
      processedCount: syncItems.length,
    });
  }

  // 6. Hospitals Directory (GET /api/hospitals)
  if (pathname === '/api/hospitals' && method === 'GET') {
    const db = readDB();
    return sendJSON(res, 200, { success: true, count: db.hospitals.length, data: db.hospitals });
  }

  // 7. Doctors Directory (GET /api/doctors)
  if (pathname === '/api/doctors' && method === 'GET') {
    const db = readDB();
    return sendJSON(res, 200, { success: true, count: db.doctors.length, data: db.doctors });
  }

  // 8. Appointments (GET & POST /api/appointments)
  if (pathname === '/api/appointments') {
    const db = readDB();
    if (method === 'GET') {
      const patientId = reqUrl.searchParams.get('patientId');
      const data = patientId
        ? db.appointments.filter((a) => a.patientId === patientId)
        : db.appointments;
      return sendJSON(res, 200, { success: true, count: data.length, data });
    }

    if (method === 'POST') {
      const body = await parseBody(req);
      const newApt = {
        ...body,
        id: `APT-${Math.floor(300 + Math.random() * 700)}`,
        status: 'scheduled',
      };

      db.appointments.unshift(newApt);
      saveDB(db);

      return sendJSON(res, 201, { success: true, message: 'Appointment booked successfully.', appointment: newApt });
    }
  }

  // 9. Community Outbreak Surveillance (GET & POST /api/surveillance)
  if (pathname === '/api/surveillance') {
    const db = readDB();
    if (method === 'GET') {
      return sendJSON(res, 200, { success: true, count: db.surveillance.length, data: db.surveillance });
    }

    if (method === 'POST') {
      const body = await parseBody(req);
      const newCluster = {
        ...body,
        id: `SURV-${Date.now()}`,
        status: 'flagged',
        lastReported: new Date().toISOString().split('T')[0],
      };

      db.surveillance.unshift(newCluster);
      saveDB(db);

      return sendJSON(res, 201, {
        success: true,
        message: 'Outbreak cluster logged and flagged for Public Health review.',
        cluster: newCluster,
      });
    }
  }

  // Fallback 404
  return sendJSON(res, 404, { success: false, message: `Route ${method} ${pathname} not found.` });
});

server.listen(PORT, () => {
  console.log(`=======================================================`);
  console.log(`  SwasthyaSetu Backend API Server Started`);
  console.log(`  URL: http://localhost:${PORT}`);
  console.log(`  Health Check: http://localhost:${PORT}/api/health`);
  console.log(`  Database File: ${DB_FILE}`);
  console.log(`=======================================================`);
});
